//const OsUrlObj = new URL(window.location.href);
//const OsBaseUrl = OsUrlObj.origin + OsUrlObj.pathname.replace(/\/$/, '');

class OsStorageManager {
  constructor(appName, instanceId = '') {
  	
//const appName=`Os_${window.btoa(OsBaseUrl)}`

    this.prefix = `${appName}${instanceId ? '_' + instanceId : ''}_`;
  }

  _getKey(key) {
    return this.prefix + key;
  }

  set(key, value) {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(this._getKey(key), serialized);
    } catch (e) {
      console.error('Storage set error:', e);
    }
  }

  get(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(this._getKey(key));
      return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
      console.error('Storage get error:', e);
      return defaultValue;
    }
  }

  remove(key) {
    try {
      localStorage.removeItem(this._getKey(key));
    } catch (e) {
      console.error('Storage remove error:', e);
    }
  }

  clearAppData() {
    try {
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k.startsWith(this.prefix)) keysToRemove.push(k);
      }
      keysToRemove.forEach(k => localStorage.removeItem(k));
    } catch (e) {
      console.error('Storage clearAppData error:', e);
    }
  }
}

class OsNetwork {
	
	fetch(options){

	 const page=options.page;
     const GetData=options.data||{};
     const siteId=options.siteId||'abcde';
     const url= options.url||`${OsBaseUrl}/api/${page}`
     const token=options.token||osStorage.get("token")||"";
    const contentType=GetData.contentType||'application/json';

     //sessionStorage.getItem('OsPaystackLocal')||"https://www.oshobby.com.ng/ecommerce/api";

  GetData['token']=token;
  GetData['site_id']=siteId;

   options.init && options.init();
 
$.ajax({
        url: url,
        method: 'GET',
        contentType: contentType,
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
       data: GetData
       }).done(function(data) {             	
      // alert( JSON.stringify(data))
           options.always && options.always();
 
 if( typeof data==='string'){
 	options.done && options.done(data);
 return;
 }
 
 
	if( data.loginRequired ){
		if( options.login && options.login(data) ){
			return;
		}
		
	if(typeof loginForm==='function'){	    
   return loginForm();
		}
 	   location.href=OsBaseUrl + '/login.php';
 return;
 }
 
  if ( data.success || data.status){
   options.done && options.done(data);
   return;
 }
 options.error && options.error( data, data.message||data.error);
	
   }).fail( function(e, txt, xhr) {
   const errorJson	= e.responseJSON?.error||'';
   const errorText	= e.responseText||'';
   const errorMsg=errorJson||errorText||"Check your internet connection";
  
   options.fail && options.fail(e, errorMsg);
   options.always && options.always();
       });
}


	post(options){

     const page=options.page;
     const PostData=options.data||{};
     const isUpload= options.isUpload;
     const siteId=options.siteId||'abcde';
     const url= options.url||`${OsBaseUrl}/api/${page}`
     const token=options.token||osStorage.get("token")||"";    
 
  //sessionStorage.getItem('OsPaystackLocal')||"https://www.oshobby.com.ng/ecommerce/api";

  PostData['token']=token;
  PostData['site_id']=siteId;
  
   options.init && options.init();
  
const p_options={
        url: url,
        method: 'POST',
        contentType: isUpload?false: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
        data: isUpload?PostData:JSON.stringify(PostData)
       };

if( isUpload){
	p_options['processData']= false;
	}

$.ajax(p_options).done(function(data) {      
       options.always && options.always(data);
      
if( data.loginRequired ){
		if( options.login && options.login(data) ){
			return;
		}
if(typeof loginForm==='function'){	    
   return loginForm();
		}		
 	   location.href=OsBaseUrl + '/login.php';
 return;
 }
	
	if( data.success|| data.status){
   options.done && options.done(data);
   return;
 }
 options.error && options.error( data, data.message||data.error||'Check your internet connection');

   }).fail( function(e, txt, xhr) {  	
   const errorJson	= e.responseJSON?.error||'';
   const errorText	= e.responseText||'';
   const errorMsg=errorJson||errorText||"Check your internet connection";
      
        options.fail && options.fail(e, errorMsg, txt, xhr);
   options.always && options.always();

       })
  }  
}

	
class CommerceHero {
  constructor(selector, options = {}) {
    this.container = document.querySelector(selector);
    this.slides = options.slides || [];
    this.interval = options.interval || 5000;

    if (!this.container) {
      console.error("CommerceHero: container not found");
      return;
    }

    this.init();
  }

 escapeHtml(text) {
    return $('<div>').text(text).html();
}

  init() {
    const id = "hero_" + Math.random().toString(36).substr(2, 9);

    this.container.innerHTML = `
      <div id="${id}" class="carousel slide carousel-fade hero-commerce" data-bs-ride="carousel">
        
        <div class="carousel-inner">
          ${this.renderSlides()}
        </div>

      </div>
    `;

    new bootstrap.Carousel(`#${id}`, {
      interval: this.interval,
      pause: "hover",
      wrap: true
    });
  }

renderSlides() {
  return this.slides.map((slide, i) => {
    //   alert( JSON.stringify( slide))
      
	const image=slide.product_images?slide.product_images.split('||')[0].split('|')[1]:'';    
        
return `
      <div class="carousel-item ${i === 0 ? "active" : ""}">
        
        
        <div class="hero-slide">

          <!-- Background -->
        
<img src="${productImage(image)||'https://dummyimage.com/500x500/999/fff&text=' + escapeHtml(slide.name[0])}" class="hero-img">

          <div class="hero-overlay"></div>

          <!-- Content -->
          <div class="hero-content container">

            <!-- Text Side -->
            <div class="hero-text">
              <h2>${escapeHtml(slide.name || "")}</h2>
              <p>${escapeHtml(slide.description || "")}</p>
              ${slide.button ? `
                <a href="${escapeHtml(slide.button.link)}" class="btn btn-warning">
                  ${escapeHtml(slide.button.label)}
                </a>
              ` : ""}
            </div>

            <!-- Product Card -->
            ${this.renderProductCard(slide)}

          </div>

        </div>

      </div>
    `}).join("");
    
  }

  renderProductCard(product) {
  	const image=product.product_images?product.product_images.split('||')[0].split('|')[1]:'';    
  
    return `
      <div class="hero-product-card">

    <img src="${productImage(image)||'https://dummyimage.com/500x500/999/fff&text=' + escapeHtml(product.name[0])}" class="lazylazy-load img-fluid object-fit-cover" alt="${this.escapeHtml(product.name)}">
        <div class="product-info w-100">
          <h5 class="w-100 text-truncate">${escapeHtml(product.name)}</h5>
          <div class="price">₦${escapeHtml(product.sale_price||product.price)}</div>

          ${product.sale_price ? `
            <div class="old-price">₦${escapeHtml(product.price)}</div>
          ` : ""}

          <button class="btn btn-sm btn-dark w-100 mt-2" onclick="previewProduct(${escapeHtml(product.id)});">
            View Product
          </button>
        </div>

      </div>
    `;
  }
}

//helper
function fetchData(page, GetData={}, callback){
	
  const loaderType=GetData.loaderType||'';
  
    $(`#ajax-loader-container${loaderType}`).css('visibility','visible');
  
	
	Os.fetch({
		url: page.match(/^http/i)?page:'',
		page: page,
		data: GetData,
		done: function(data){
			callback(data);
			},
	fail: function(e, msg){
		callback('', msg, e);
		},
	error: function(data, msg){
		callback('', msg, data);
		},
		login: function(){
			logOut( false);
			},
	always: function(){
		$(`#ajax-loader-container${loaderType}`).css('visibility','hidden');
	}
	});
}


function postData(page, PostData={}, callback, isUpload){
	
	const loaderType=PostData.loaderType||'';
  
    $(`#ajax-loader-container${loaderType}`).css('visibility','visible');
  
  	
	Os.post({
		url: page.match(/^http/i)?page:'',
		page: page,
		data: PostData,
		isUpload: isUpload,
		done: function(data){
			callback(data);
			},
		error: function(data, msg){
			callback('', msg, data);
			},
	fail: function(e, msg){
		callback('', msg, e);
		},
	always: function(data){
    $(`#ajax-loader-container${loaderType}`).css('visibility','hidden');

  		}
	});
}

function showToast(message, type = "error") {
    var bg = "#d32f2f"; // error (red)

    if (type === "success") bg = "#2e7d32";
    if (type === "info")    bg = "#1976d2";
    if (type === "warning")    bg = "#f57c00";

    var toast = $('<div class="custom-toast"></div>').text(message);

    toast.css({
        position: "fixed",
        bottom: "15vh",
        left: "50%",
        width: "90%",
        maxWidth: "280px",
        transform: "translateX(-50%)",
        background: bg,
        color: "#fff",
        padding: "10px 18px",
        borderRadius: "6px",
        zIndex: 9999999,
        display: "none",
        fontSize: "14px",
        boxShadow: "0 4px 10px rgba(0,0,0,.2)"
    });

    $("body").append(toast);

    toast.fadeIn(200).delay(3000).fadeOut(300, function () {
        $(this).remove();
    });
}

function escapeHtml(text) {
    return $('<div>').text(text).html();
}

function nigeriaStates() {
 return [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
  "FCT - Abuja"
];
}

// Suppose your app is called "ShopX" and installed in folder "store1"
const osStorage = new OsStorageManager('Os-shop','store1');

// Save token
//osStorage.set('token', 'USER_TOKEN_HERE');
// Retrieve token
//const token = osStorage.get('token');

// Remove token
//osStorage.remove('token');
// Clear all data for this app instance
//osStorage.clearAppData();

const Os=new OsNetwork();
let configs={};
let products=[]
let categories=[];
let cart =[];

const baseUrl=location.href;
const __siteUnique=window.btoa(baseUrl);

 
$.getScript(`config.js?i=${Date.now()}`)
    .then(function () {
        return $.getScript(`products.js?i=${Date.now()}`);
    })
    .then(function () {
        cart=JSON.parse(localStorage.getItem(`${config.storageKeys.cart}`)) || [];

    categories=getCategories();
    populateBusinessInfo();
	renderProducts(products);
    renderCart();
    renderCategories();
    populateNigeriaStates();
    
$('#loader-container').fadeOut();
    })
    .catch(function (e, txt, xhr) {
showToast(`Error loading dependencies: ${xhr}`);
    });

function toast(msg) {
  $('#toast').text(msg).fadeIn().delay(1500).fadeOut();
}

function populateBusinessInfo(){
	$('.business-name').text(config.app.name);
	$('#logo-container').html(`<img src="logo.png?i=${Date.now()}" alt="Logo">`);
	populateContactPage();
}
	
function populateNigeriaStates(){
  try{
 const states=nigeriaStates();
   const el=  $('.nigeria-states');
   
   states.forEach( val=>{
el.append(`<option>${val}</option>`);
});
}catch(e){ alert(e); }
 }
 
function renderProducts(list) {
  $('#products').html('');
  
  list.forEach(p => {
    $('#products').append(`
    <div class="col-6 col-md-3 add-to-cart" data-id="${p.id}">
<div class="card mb-2" id="product-card-${p.id}">
        
<div class="product-img-container">
<img data-src="${p.image}" class="lazy lazyload">
         </div>
 <div class="card-body text-left py-0 px-1 pt-1">
            <h6 class="product-name">${p.name}</h6>
            <p class="mb-1"><span class="product-price">₦ ${p.price}</span> ${p.price<p.regularPrice?`<sup class="product-regular-price text-muted text-decoration-line-through">₦ ${p.regularPrice}</sup>`:''}</p>
            <button class="btn btn-dark d-none add-to-cart" data-id="${p.id}">
              <i class="fa fa-cart-plus"></i>
            </button>
          </div>
        </div>
      </div>

`);
  });
 
cart.forEach(c => { 
  $(`#product-card-${c.id}`).addClass('item-selected');
  });
}

function renderCart(elementId) {
  $('#cartItems').html('');
  let total = 0;

  cart.forEach(c => {
    total += c.price * c.qty;
//alert( JSON.stringify(c))
    $('#cartItems').append(`
      <div>
         <div class="d-flex align-items-center mb-2">
    <div class="ratio ratio-1x1" style="width: 60px;">
  <img data-src="${c.image}" class="img-fluid rounded object-fit-cover lazy lazyload" alt="${c.name}">
</div>
        <div class="ms-2"><b>${c.name} x ${c.qty}<br>₦ <span id="cart-product-price-${c.id}">${c.price*c.qty}</span></b></div>
      </div>
       <div class="d-flex align-items-center">
<button class="qty-btn minus me-2" data-id="${c.id}">-</button>
       <span class="d-block text-center" style="width: 50px;"><input id="qty-input-${c.id}" type="text" inputmode="numeric" min="1" step="1" class="qty-input form-control text-center rounded" data-id="${c.id}" value="${c.qty}"></span>
 <button class="qty-btn plus ms-2" data-id="${c.id}">+</button>
        <a href="javascript: void(0);" class="ms-5 text-dark text-decoration-none remove" data-id="${c.id}">
          <i class="fa fa-trash"></i> remove
        </a>
        </div>
        <hr>
      </div>`);
      
  $(`#product-card-${c.id}`).addClass('item-selected');
  });

if( elementId){
 const input=$('#qty-input-' + elementId)[0];
input.focus();

//setTimeout(()=>{
input.setSelectionRange(input.value.length, input.value.length);
 //}, 0);
}

  $('.cart-total').text(total);
  $('.cartCount').text(cart.length);
  localStorage.setItem(`${config.storageKeys.cart}`, JSON.stringify(cart));
  
   if( cart.length) $('#cart-btn').addClass('attention');
   else $('#cart-btn').removeClass('attention');
}

function renderCategories(){
	const el=$('#menu-categories');
	const productCats=$('.products-categories');
	productCats.html('<option>All</option>');
	 let li='';
	categories.forEach((c)=>{
		li+=`<li class="px-0"><small><i class="fas fa-star"></i></small> ${c.category}</i>`;
		productCats.append(`<option value="${c.category}">${c.category}</option>`);
		});
	el.html( li);
	}

function getCategories(products__=products, options = {}) {
  const {
    sortBy = 'name',   // 'name' | 'total'
    order = 'asc',     // 'asc' | 'desc'
    includeAll = false
  } = options;

  // Step 1: Count categories
  let categories = Object.entries(
    products__.reduce((acc, product) => {
      acc[product.category] = (acc[product.category] || 0) + 1;
      return acc;
    }, {})
  ).map(([category, total]) => ({ category, total }));

  // Step 2: Sort
  categories.sort((a, b) => {
    if (sortBy === 'total') {
      return order === 'asc'
        ? a.total - b.total
        : b.total - a.total;
    }

    // default: sort by name
    return order === 'asc'
      ? a.category.localeCompare(b.category)
      : b.category.localeCompare(a.category);
  });

  // Step 3: Add "All" category
  if (includeAll) {
    const totalProducts = products.length;
    categories.unshift({ category: 'all', total: totalProducts });
  }
  return categories;
}
	
$(document).on('click','.add-to-cart', function(){
  const id = $(this).data('id');
  let item = cart.find(i => i.id == id);

  if(item){
  	  cart = cart.filter(i=>i.id!=id);
  $(this).find('.card').removeClass("item-selected");
  renderCart();
  return;
// item.qty++;
 }
  else {
    let p = products.find(x=>x.id==id);
    cart.push({...p, qty:1});
    $(this).find('.card').addClass("item-selected");
  }

  renderCart();
  showToast('Added to cart', 'info');
});

$(document).on('keyup','.qty-input', function(e){
	const this_=$(this);
  const id = this_.data('id');
  let value=Number(this_.val());
  let item = cart.find(i=>i.id==id);
  if( value<1) {
  	this_.val(1);
value=1;
}
  item.qty=value;
  renderCart(id);
});

$(document).on('click','.plus', function(){
  const id = $(this).data('id');
  let item = cart.find(i=>i.id==id);
  item.qty++;
  renderCart();
});

$(document).on('click','.minus', function(){
  const id = $(this).data('id');
  let item = cart.find(i=>i.id==id);
  if(item.qty > 1) item.qty--;
  renderCart();
});

$(document).on('click','.remove', function(){
  const id = $(this).data('id');
  const item=cart.find( c=>c.id==id);
  	if(!confirm(`Remove ${item.name}?`) ) return;
  
  cart = cart.filter(i=>i.id!=id);
  $(`#product-card-${id}`).removeClass('item-selected');
  renderCart();
  
  if( cart.length<1 ){
		history.go(-1);
		}
});

$('#search-products').on('input', function(){
  let val = $(this).val().toLowerCase();
  renderProducts(products.filter(p=>p.name.toLowerCase().includes(val)));
});

$('#filter').on('change', function(){
  let val = $(this).val().toLowerCase();
  if(val=='all') renderProducts(products);
  else {
renderProducts(products.filter(p=>p.category.toLowerCase()==val));
}
});

function appendUserInfo(){
	if( cart.length<1 ){
		history.go(-1);
	setTimeout(()=>showToast(`Your cart is empty. Add items to view them here.`) ,1000);
		}
	const userData=  JSON.parse( localStorage.getItem(`${config.storageKeys.user}`)||'{}');
	
	$('.customer-name').text( userData.name);
    $('.customer-phone').text( userData.phone);
    $('.customer-address').text( userData.address);	
	}
	
function openRegistrationForm(t){
   const this_=$(t);
   
  const userData=  JSON.parse( localStorage.getItem(`${config.storageKeys.user}`)||'{}');

const form= document.getElementById('registerForm');
 
  	$('#customer-form-title').text(userData.name?`Update your info`:`Fill in your details`);

 hydrateForm(form, userData);
 togglePage('sectionCustomerForm');
}
	
function confirmCart(t){
	const userData= JSON.parse( localStorage.getItem(`${config.storageKeys.user}`)||'{}');
	
 ['name','address','phone','email','state'].forEach(( val, ind)=>{
 	if(!userData[val] )  {
openRegistrationForm();
   throw new Error("Fill customer info");
   }
 });
  
 try{
  checkoutInfo();
  }catch(e){
  	alert(e);
  }
}
	
function checkoutInfo(){
	let totalAmount=0;
	
cart.forEach(c => {
    totalAmount += c.price * c.qty;
 });
	
const customer= JSON.parse( localStorage.getItem(`${config.storageKeys.user}`)||'{}');
 	
	App.showModal({
        title: 'Confirm Order',
        icon: 'fa-solid fa-cart-shopping text-success',
        size: 'modal-lg',
        body: `
            <div class="mb-3">
                <h5 class="fw-bold">Order Summary</h5>
                <p class="mb-1">Total Amount:</p>
                <h3 class="text-primary">₦${Number(totalAmount).toLocaleString()}</h3>
            </div>

            <div class="alert alert-info d-flex">
                <i class="fas fa-info-circle me-2 fs-4"></i>
      <div id="online-payment-info" class="check-out-info">
        After successful payment, please stay on the payment page until you are redirected to our WhatsApp customer representative for a faster response.
                </div>
    
<div id="pod-info" class="check-out-info d-none">
Pay on Delivery (POD) means you pay for your order when it is delivered to your address. No upfront payment is required. Please have your payment ready in cash or mobile payment when the delivery arrives. Delivery times may vary depending on your location.
</div>                                        
            </div>

            <div class="alert alert-warning mb-3">
                <i class="fa-solid fa-truck me-2"></i>
                Delivery may take up to <strong>${config.shipping.maxDate} days</strong> depending on your location.
            </div>

<div id="confirmError" class="text-danger d-none">
                Please confirm before proceeding.
            </div>

            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="confirmCheckbox">
                <label class="form-check-label" for="confirmCheckbox">
                    I understand and agree to proceed
                </label>
            </div>

<div class="form-check mt-3 ${!config.payment.enablePod?'d-none':''}">
                <input class="form-check-input" type="checkbox" id="podCheckbox" onchange="togglePodInfo(this);">
                <label class="form-check-label" for="podCheckbox">
               Pay on delivery
                </label>
            </div>            
        `,
        buttons: [
            {
                text: 'Cancel',
                class: 'btn-secondary modal-close-btn',
                action: 'close'
            },
           {
           	text: 'Place Order',
                class: 'btn-primary send-order-btn d-none',
                onClick: function(){
                	
              const isChecked = $('#confirmCheckbox').is(':checked');

  $('#confirmError').addClass('d-none');
                    if (!isChecked) {
                        $('#confirmError').removeClass('d-none');
                        return;
                    }
           
    const message = formatCartForWhatsApp(cart, customer);

     sendToWhatsApp(message);
     
                }
           },
           
            {
                text: 'Pay Now',
                class: 'btn-success pay-now-btn',
                onClick: function (modal) {
                    const isChecked = $('#confirmCheckbox').is(':checked');
    $('#confirmError').addClass('d-none');
                    if (!isChecked) {
                        $('#confirmError').removeClass('d-none');
                        return;
                    }

const message = formatCartForWhatsApp(cart, customer, true);
 
   const p={
   fullname: customer.name,
   email: customer.email,
   amount: totalAmount,
   plain: '[[REF]]' + message,
   order: message.replace(/[\r\n]/g,'<br>').replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>')
   }
   
  payNow( p);
               //  modal.hide();
                }
            }
        ]
    });
	}

function togglePodInfo(t){
	$('.check-out-info, .send-order-btn, .pay-now-btn').toggleClass('d-none');
}

	
function payNow(metadata){

try{
	if(typeof metadata!=='object') throw new Error("Invalid payment configuration");

if( !metadata.email||!metadata.amount )
throw new Error("Enter email & Amount");

     const email = metadata.email||'';
     const amount = Number( metadata.amount||0);
           
            if (!email) {
                this.fail(form, "Enter a valid email address", btn);
                return;
            }

            if (amount < 50) {
                this.fail(form, `Amount must be at least ${config.currency.symbol}50`, btn);
                return;
            }

 const message=metadata.plain;

delete metadata.email;
delete metadata.amount;
delete metadata.plain;

const popup=new OsPay(config.payment.publicKey);

  const btn=$('.pay-now-btn');
	
	btn.prop('disabled', true).append(`<i class="fas fa-spin fa-spinner text-light"></i>`);
	
            popup.checkout({
                email,
                amount,
                metadata,
                onClose: (reference) => {         
      popup.toast('Payment closed','info');
         },
      onSuccess: (reference) => {
      const msg=message.replace('[[REF]]',`*Transaction Reference:*\n${reference}\n\n`);
      
         sendToWhatsApp(msg);
    },

                onFail: (reference, msg) => {
              },
               onError: (error) => {
                    showToast(error)
                },
              always: () => {
                    btn.prop('disabled', false).find('i').remove();
                }
            });

        } catch (e) {
         alert(e)            
        }

	}


$(function(){
	
const form = document.getElementById('registerForm');

  form.addEventListener('submit', function (event) {
  	
  	event.preventDefault();
    
    if (!form.checkValidity()) {      
    	form.classList.add('was-validated');
      return;
    } 
            
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());

    form.classList.add('was-validated');
    
     localStorage.setItem(`${config.storageKeys.user}`,  JSON.stringify( data));
     appendUserInfo();
     showToast('Saved', 'success');    
  });    
})


function hydrateForm(form, data) {
  const $form = $(form);

  Object.keys(data).forEach(key => {
    const value = data[key];
    const $fields = $form.find(`[name="${key}"]`);

    if (!$fields.length) return;

    const type = ($fields.attr('type') || '').toLowerCase();
    const tag = ($fields.prop('tagName') || '').toLowerCase();

    // RADIO
    if (type === 'radio') {
      $fields.filter(`[value="${value}"]`).prop('checked', true);
    }

    // CHECKBOX
    else if (type === 'checkbox') {
      if (Array.isArray(value)) {
        // multiple checkboxes with same name
        $fields.each(function () {
          $(this).prop('checked', value.includes($(this).val()));
        });
      } else {
        // single checkbox
        $fields.prop('checked', Boolean(value));
      }
    }

    // SELECT (single or multiple)
    else if (tag === 'select') {
      $fields.val(value);
    }

    // INPUT, TEXTAREA, etc.
    else {
      $fields.val(value);
    }
  });
}	

function companyInfo(){
	 let b={}
	b.companyName='Ayo-Ola Trading Stores';
	b.logo='logo.png';
	
	$('.company-name').text( escapeHtml( b.companyName) );
	$('.company-logo').text( escapeHtml(b.logo) );
	
}
	

function toggleMenu(t, close){
	let el=$('#header-menu-container');
    let menuBtn=$('#header-menu-btn');
    
 if(!close) _pushState({
    element: '#header-ul',
    close: 'toggleMenu',
   args: [false, true]
   });
   
if(el.hasClass('menuOpen') ){
	//Close
 	el.removeClass('menuOpen');
   $('body').removeClass('overflow-hidden');
   menuBtn.find("i").css('transform', 'rotate(0deg)')	
  
}else{
	//Open
	el.addClass('menuOpen');
	$('body').addClass('overflow-hidden');
	menuBtn.find("i").css('transform', 'rotate(50deg)')	
  }
}
	
function togglePage(pageId, callback){
	try{
  let page=$('#' + pageId);

page.addClass('showSection');

 page.find('.page-blur').show();
  
  _pushState({
    element: '#' + pageId,
   close: 'closePage',
   args: [pageId]
   });
   if(callback) window[callback]();
	$('body').addClass('overflow-hidden');
}catch(e){ alert(e); }
}

function closePage(page){
	$('body').removeClass('overflow-hidden')
	setTimeout(()=>	$('#' + page).removeClass('showSection'), 300);
}


function formatCartForWhatsApp(cart, customer, forEmail) {
	//const line='-------------------------------------';
	const line='━━━━━━━━━━━━━━';

  let message = "";

 if( !forEmail ) message +="⚠️ DO NOT EDIT THIS MESSAGE.\n_(Any modification will automatically VOID this order)_\n\n";
	
  message += "🛒 *NEW ORDER*\n";

  // Customer Info
  message += "👤 *CUSTOMER DETAILS*\n";
  message += `*Name:* ${customer.name}\n`;
  message += `*Phone:* ${customer.phone}\n`;
  message += `*Email:* ${customer.email}\n`;
  message += `*Address:* ${customer.address}\n`;

  if (customer.note) {
    message += `*Note:* ${customer.note}\n`;
  }

  message += `\n${line}\n\n`;

  // Group by category
  const grouped = {};
  cart.forEach(item => {
    if (!grouped[item.category]) {
      grouped[item.category] = [];
    }
    grouped[item.category].push(item);
  });

  let total = 0;

  // Loop categories
  Object.keys(grouped).forEach(category => {
    message += `📦 *${category.toUpperCase()}*\n\n`;

    grouped[category].forEach((item, index) => {
      const subtotal = item.price * item.qty;

      message += `- *${item.name}*\n`;
      message += `  ₦${item.price.toLocaleString()} x ${item.qty}\n`;

    /*
  if (!item.inStock) {
        message += `  ❌ Out of Stock\n`;
      } else {
     */
        message += `  Subtotal: ₦${subtotal.toLocaleString()}\n`;
        total += subtotal;
  //    }

      message += `\n`;
    });
    message += "\n";
  });

  // Total
  message += `${line}\n`;
  message += `💰 *TOTAL: ₦${total.toLocaleString()}*\n`;
  message += `${line}`;

  return message;
}


function sendToWhatsApp(message, phone) {
  phone=(phone||config.contact.whatsapp).replace(/\+/g, "");

  const encodedMessage = encodeURIComponent(message);
  
  const url = `https://api.whatsapp.com/send/?phone=${phone}&text=${encodedMessage}`;
  window.open(url, "_blank");
}

$(function(){
	
$('body').on('click','.page-blur', function(e){
 	history.go(-1);
 });

$('#createUserForm').on('submit', function (e) {
    e.preventDefault();
const alertBox = $('#alertBox');

let form = this;


   if (!$(this)[0].checkValidity()) {
        $(this).addClass('was-validated');
        return;
    }

    const payload = {
        role: document.getElementById('role').value,
        branch: document.getElementById('user-branch').value.trim(),
        full_name: document.getElementById('full_name').value.trim(),
        username: document.getElementById('username').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        email: document.getElementById('email').value.trim(),
        password: document.getElementById('password').value
    };

  let btn=$(form).find('button');
        btn.prop('disabled', true);
   
  postData('create-user', payload, function(data, error){
  	btn.prop('disabled', false);
       alertBox.removeClass('d-none, alert-success, alert-danger');
        
if( error){
            showToast( error, 'error');  
            alertBox.addClass('alert-danger');
            alertBox.text(error || 'Failed to create user');
            return;
        }

  showToast(data.message || 'User created successfully', 'success');
            alertBox.addClass('alert-success');
            alertBox.text(data.message || 'User created successfully');
            form.reset();
            $(this).removeClass('was-validated');         
            return;      
  });
  
});


});

function showToast(message, type = "error") {
    var bg = "#d32f2f"; // error (red)

    if (type === "success") bg = "#2e7d32";
    if (type === "info")    bg = "#1976d2";
    if (type === "warning")    bg = "#f57c00";

    var toast = $('<div class="custom-toast"></div>').text(message);

    toast.css({
        position: "fixed",
        bottom: "15vh",
        left: "50%",
        width: "90%",
        maxWidth: "280px",
        transform: "translateX(-50%)",
        background: bg,
        color: "#fff",
        padding: "10px 18px",
        borderRadius: "6px",
        zIndex: 9999999,
        display: "none",
        fontSize: "14px",
        boxShadow: "0 4px 10px rgba(0,0,0,.2)"
    });

    $("body").append(toast);

    toast.fadeIn(200).delay(3000).fadeOut(300, function () {
        $(this).remove();
    });
}

function escapeHtml(text) {
    return $('<div>').text(text).html();
}

function logOut(){
	if(!confirm('Confirm you want to logout')) return;
	
	try{
const token=localStorage.getItem('token')||''
	fetchData(`logout?token=${token}`, {} , function(data, error){
   
 if( error){
   showToast( error);
return;
}

localStorage.removeItem('token');
localStorage.removeItem('token_expiry');
localStorage.removeItem('userRole');
location.href=serverUrl + '/login.php';
});
}catch(e){ alert(e);
}
}


/*ANIMATION & CHARTS*/

function animateValue(id, start, end, duration, isAmount=false) {

const el=$("#"+id);


  if( end==0) {
    el.text(isAmount?end.toFixed(2):end)
 return;
}
  
let range = end - start
let current = start
let increment = end > start ? 1 : -1
let stepTime = Math.abs(Math.floor(duration / range));

let timer = setInterval(function(){

current += increment

if( current==200) increment=increment*5000;

if(current >= end){
	current=end;
clearInterval(timer)
}

if( isAmount) {
	 if( current<1000 )
el.text( current.toFixed(2));
 else el.text(current.toLocaleString('en-US') );
 return;
}else{
	el.text(current);
	}

}, stepTime)

}

function salesChart( labels, sales){
const ctx = document.getElementById('salesChart')

new Chart(ctx, {

type:'line',

data:{
labels:labels,
datasets:[{
label:'Sales',
data:sales,
borderWidth:3,
fill:true
}]
},

options:{
responsive:true,
plugins:{
legend:{
display:true
}
}
}

})

}

document.addEventListener("DOMContentLoaded", function(){
document.getElementById("contactForm").addEventListener("submit", function(e) {
  e.preventDefault();

  let name = document.getElementById("name").value.trim();
  let email = document.getElementById("email").value.trim();
  let subject = document.getElementById("subject").value.trim();
  let message = document.getElementById("message").value.trim();

  let valid = true;

  // Reset errors
  document.querySelectorAll("small.text-danger").forEach(el => el.innerText = "");

  // Validation
  if (name === "") {
    document.getElementById("nameError").innerText = "Name is required";
    valid = false;
  }

  if (email && !email.includes("@")) {
    document.getElementById("emailError").innerText = "Enter valid email address";
    valid = false;
  }

  if (subject === "") {
    document.getElementById("subjectError").innerText = "Subject is required";
    valid = false;
  }

  if (message === "") {
    document.getElementById("messageError").innerText = "Message cannot be empty";
    valid = false;
  }

  if (!valid) return;

// WhatsApp Number (CHANGE THIS)
  let phoneNumber = config.contact.whatsapp;

  let text = `Hello!%0A
Name: ${name}%0A
Email: ${email}%0A
Subject: ${subject}%0A%0A
Message: ${message}`;

  let whatsappURL = `https://api.whatsapp.com/send/?phone=${phoneNumber}&text=${text}`;

  window.open(whatsappURL, "_blank");
});

});

function timeAgo(dateString, noFormat){

    let date = new Date(dateString);
    let now = new Date();

    let diff = now - date;
    let oneDay = 1000 * 60 * 60 * 24;

    let days = Math.floor(diff / oneDay);

    let time = date.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

    let fullDate = date.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    }) + " " + time;

if( noFormat)  return fullDate;

    if(days === 0){
        return "Today, " + time;
    }
    else if(days === 1){
        return "1 day ago, " + time;
    }
    else if(days === 2){
        return "2 days ago, " + time;
    }
    else{
        return fullDate;
    }
}

//MODAL
window.App = window.App || {};

App.showModal = function (options = {}) {
  
    const defaults = {
        title: 'Title',
        body: '',
        size: '', // '', 'modal-sm', 'modal-lg', 'modal-xl'
        icon: '', // fontawesome class e.g. 'fa-solid fa-circle-info'
        buttons: [
            {
                text: 'Close',
                class: 'btn-secondary',
                action: 'close'
            }
        ],
        onOpen: null,
        onClose: null
    };

    const settings = {...defaults, ...options};

    const modalId = 'appModal';

    // Remove existing modal (reuse pattern)
    $('#' + modalId).remove();

    const iconHtml = settings.icon 
        ? `<i class="${settings.icon} me-2"></i>` 
        : '';

    const buttonsHtml = settings.buttons.map((btn, index) => {
        return `
            <button type="button" 
                class="btn ${btn.class}" 
                data-index="${index}">
                ${btn.text}
            </button>
        `;
    }).join('');

    const modalHtml = `
    <div class="modal fade" id="${modalId}" tabindex="-1">
        <div class="modal-dialog ${settings.size}">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        ${iconHtml}${settings.title}
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ${settings.body}
                </div>
                <div class="modal-footer">
                    ${buttonsHtml}
                </div>
            </div>
        </div>
    </div>
    `;

    $('#appModalContainer').html(modalHtml);

    const modalEl = document.getElementById(modalId);
    const modal = new bootstrap.Modal(modalEl);

_pushState({
   close: 'closeModal',
   args: [true]
   });


    // Button actions
    $(modalEl).on('click', '.modal-footer button', function () {
        const index = $(this).data('index');
        const btn = settings.buttons[index];

        if (btn.action === 'close') {
            modal.hide();
            
        }

        if (typeof btn.onClick === 'function') {
            btn.onClick(modal);
        }
    });

    // Events
    if (typeof settings.onOpen === 'function') {
        modalEl.addEventListener('shown.bs.modal', settings.onOpen);
    }

modalEl.addEventListener('shown.bs.modal', function(){
  App.modalOpened=true;
});

    if (typeof settings.onClose === 'function') {
        modalEl.addEventListener('hidden.bs.modal', settings.onClose);
    }

modalEl.addEventListener('hidden.bs.modal', function(){
	
	if( App.modalOpened) {	
     App.modalOpened=false;
          history.go(-1);
        }
});

    modal.show();
};

function closeModal(backBtn){
	if( backBtn ){
		App.modalOpened=false;
		const modalEl = document.getElementById('appModal');
	
const modal = bootstrap.Modal.getInstance(modalEl) 
            || new bootstrap.Modal(modalEl);

modal.hide();
return;
	}
}
	
function populateContactPage(){
	$('#business-contact-info').html(`<i class="fa fa-map-marker-alt me-2"></i> ${config.contact.address}</p>
      <p><i class="fa fa-phone me-2"></i> ${config.contact.phone}</p>
      <p><i class="fa fa-envelope me-2"></i> ${config.contact.email}
      
      <h5 class="mt-4">Business Hours</h5>
      <p>${config.business_days.open}</p>
      <p>${config.business_days.close}</p>

      <!-- Google Map -->
      <div class="mt-4">
        <iframe 
          src="https://maps.google.com/maps?q=${encodeURIComponent(`${config.contact.map}`)}&t=&z=13&ie=UTF8&iwloc=&output=embed"
          width="100%" 
          height="250" 
          style="border:0; border-radius:10px;" 
          allowfullscreen="" 
          loading="lazy">
        </iframe>
      </div>`);
      
	}
	
function nigeriaStates() {
 return [
  "Abia",
  "Adamawa",
  "Akwa Ibom",
  "Anambra",
  "Bauchi",
  "Bayelsa",
  "Benue",
  "Borno",
  "Cross River",
  "Delta",
  "Ebonyi",
  "Edo",
  "Ekiti",
  "Enugu",
  "Gombe",
  "Imo",
  "Jigawa",
  "Kaduna",
  "Kano",
  "Katsina",
  "Kebbi",
  "Kogi",
  "Kwara",
  "Lagos",
  "Nasarawa",
  "Niger",
  "Ogun",
  "Ondo",
  "Osun",
  "Oyo",
  "Plateau",
  "Rivers",
  "Sokoto",
  "Taraba",
  "Yobe",
  "Zamfara",
  "FCT - Abuja"
];
}


// Optional: detect changes
window.addEventListener('resize', () => {
    //console.log('Updated viewport width:', window.innerWidth);
    
    let el=$('#header-menu-container');
   
if(el.hasClass('menuOpen') ){
	//toggleMenu(false, true);
}
    
});
const __siteId='abcde';

(function () {
    const params = new URLSearchParams(window.location.search);
const data = params.get("rtr");

if (data) {
    const d = JSON.parse(atob(data.replace(/-/g, '+').replace(/_/g, '/')));
   
        osStorage.set("token", d.token);
    
        window.history.replaceState({}, document.title, window.location.pathname);
    }
    
})();

let products=[];
let cart =[];
let __recentlyViewedProducts = JSON.parse(localStorage.getItem('recently-viewed-products')) || [];
let newCartData={};

const urlObj = new URL(window.location.href);
const baseUrl = urlObj.origin + urlObj.pathname.replace(/\/$/, '');
const __siteUnique=window.btoa(baseUrl);


$(function(){
  try{
     renderUserMenu();
    const data=START__;
	
	 //alert( JSON.stringify(data))
	
if(data.success){	
 
  if( data.user.success){	
osStorage.set(`${__siteId}_user`, JSON.stringify(data.user) );
  }
    products=[];
    const topDeals=data.topDeals||[];
    const bestSellers=data.bestSellers||[];
    
    cart=JSON.parse(osStorage.get(`cart`)) || [];

  //  categories=data.categories||[]
//getCategories();
    populateBusinessInfo();
   
	renderProducts(data.newProducts||[] , 'scroll');
	renderProducts(data.trending||[] ,'row', '#home-trending-products' ,'col-md-3');
	renderProducts(topDeals ,'scroll', '#products-top-deals');
	renderProducts(bestSellers ,'scroll', '#products-best-sellers');
	
	renderRecentlyViewProducts('#recently-viewed-products');	
	
//	let nodes = buildCatzTree(categories);
//	let catz=renderCategories(nodes);
//	$('#menu-categories').html(catz);
	
    renderCart();
    
   if( data.product){
		previewProduct(null, data.product);
	}
else if( data.categoryProducts){	
	const slug = Object.keys(data.categoryProducts)[0];
    loadProductsByCategories(null, slug);
	}else if( data.page ){
		const slug = Object.keys(data.page)[0];
		loadPage( null, slug)
		}
else{
		resolveLastSection();
    }
	
    populateNigeriaStates();
    
  if( data.featured && data.featured.success){
  new CommerceHero("#hero-commerce",{
  slides: data.featured.data
});
}
    
$('#loader-container').fadeOut();  
}
	}catch(e) {
showToast(`${e.message}`);
}
});    


function toast(msg) {
  $('#toast').text(msg).fadeIn().delay(1500).fadeOut();
}

function buildUrl(slug){
	return `${OsBaseUrl}${slug?'/' + slug:''}`;
}
	
function populateBusinessInfo(){
	$('.business-name').text(config.app.name);
	
	$('#logo-container').html(`<img src="${config.app.logo||'https://dummyimage.com/1000x500/ffc107/fff&text=' + config.app.name}" alt="${config.app.name}">`);
	populateContactPage();
}
	
function populateNigeriaStates(){
  try{
 const states=nigeriaStates();
   const el=  $('.nigeria-states');
   
   states.forEach( val=>{
el.append(`<option>${val}</option>`);
});
}catch(e){ alert(e); }
 }
 
function productImage(url) {
    if (!url) return '';
   const currentOrigin = window.location.origin;

    try {
        const imageOrigin = new URL(url, currentOrigin).origin;

if (/:8000$/.test(imageOrigin) && !/:8000$/.test(currentOrigin) ){
		const img=url.replace( new RegExp( imageOrigin + '(/ecommerce)?'), OsBaseUrl);
	return img;
	}
	
    } catch (e) {
        // Invalid URL, return as-is
    }
    return url;
}
 
 function productImageLoaded(t){
 	    $(t).addClass('loaded');
    $(t).prev("span").remove();
 }
 
 
const MAX_IMG_RETRIES = 2;

function productImageError(t){
    const $img = $(t);
  
    let retries = parseInt($img.data('retries') || 0, 10);

    if (retries < MAX_IMG_RETRIES) {
        retries++;

        $img.data('retries', retries);

        const originalSrc = $img.data('original-src') || $img.attr('src');

        $img.data('original-src', originalSrc);

        const separator = originalSrc.indexOf('?') > -1 ? '&' : '?';

      //  setTimeout(function () {
            $img.attr(
                'src', originalSrc + separator + '_retry=' + Date.now()
            );
      //  }, retries * 1000); // 1s, then 2s

        return;
    }

const imgName=($img.attr('alt')||'I')[0].toUpperCase();

    $img.attr('src', `https://dummyimage.com/500x500/FFE5D0/fff&text=${imgName}`);
       }
 
 function renderProducts(data, type = 'row', element = '#products', colClass='col-md-3' ) {
  let rows = '';
//alert( JSON.stringify(data))

if( !data||!data.data||!data.data.length){
	$(element).parent('.home-product-container').remove();
	return;
	}

const list=data.data;

  list.forEach(p => {
  	const image=p.product_images?p.product_images.split('||')[0].split('|')[1]:'';
    
    rows += `
   <a href="${buildUrl(`product/${p.slug}`)}" class="product-elem text-decoration-none ${type === 'scroll' ? 'flex-shrink-0 products-horizontal' : `col-6 ${colClass}`}"  style="${type === 'scroll' ? colClass : ''}" data-id="${p.id}">

        <div class="card mb-2 product-card-${p.id}">         
        <div class="product-img-container">
          <span><i class="fas fa-spin fa-spinner"></i></span>
       <img src="${productImage(image)}" loading="lazy" class="product-image" alt="${p.name}" onload="productImageLoaded(this);" onerror="productImageError(this);">
          </div>

          <div class="card-body text-left py-0 px-1 pt-1">
            <h6 class="product-name">${p.name}</h6>
            <p class="mb-1">
              <span class="product-price">₦ ${formatMoney(p.sale_price||p.price, 0)}</span>
              ${
                (+p.sale_price && +p.sale_price < +p.price)
                  ? `<sup class="text-muted text-decoration-line-through">₦ ${formatMoney(p.price, 0)}</sup>`
                  : ''
              }
            </p>
          </div>

        </div>
      </a>
    `;    
  });

  if (type === 'scroll') {
    $(element).html(`
      <div class="d-flex flex-nowrap overflow-auto gap-2 pb-2 scroll-snap">
        ${rows}
      </div>`);
      
  } else {
    $(element).html(`<div class="row">${rows||'<h3 class="text-center">No products  yet</h3>'}</div>`);
  }

$(element).parent().find('.prev,.next').addClass('d-none');

	if( data.next){
		$(element).parent().find('.next').removeClass('d-none').attr('data-page', data.next);
		}
	if( data.prev){
		$(element).parent().find('.prev').removeClass('d-none').attr('data-page', data.prev);
	}


  cart.forEach(c => {
    $(`.product-card-${c.id}`).addClass('item-selected');
  });
}
 
function previewProduct(id, product){
 if( product){
	let p =product.data[0];
	renderRecentlyViewProducts('#sectionProductPreview .recently-viewed-products-2');

	     renderProductPreview(p);
	
	if( !$('#sectionProductPreview').is(':visible')) {
togglePage('sectionProductPreview');
	}
   return;
}

   const btn=$('#save-product-btn');
   btn.prop('disabled', true);

const payload={
 	   id: id,
 preview: true
    }

 fetchData(`get-products__`, payload, function(data, error, e){
    //alert(JSON.stringify(data))	         
	if( error){
	showToast(error);
	return;
	}
	
	btn.prop('disabled', false);
	
  if( data.success){
	      let p =data.data[0]; 
	
renderRecentlyViewProducts('#sectionProductPreview .recently-viewed-products-2');

	     recentlyViewedProducts(p);
	     renderProductPreview(p);
	
	 if( !$('#sectionProductPreview').is(':visible')) {
togglePage('sectionProductPreview');
	}
  }
});
}

function recentlyViewedProducts(p=false){
	if( p===false) return __recentlyViewedProducts;
// remove existing occurrence (avoid duplicates)
__recentlyViewedProducts = __recentlyViewedProducts.filter(item => item.id !== p.id);

// add newest to the beginning
__recentlyViewedProducts.unshift(p);

// limit to 8 items
__recentlyViewedProducts = __recentlyViewedProducts.slice(0, 8);

// save back
localStorage.setItem('recently-viewed-products', JSON.stringify(__recentlyViewedProducts));
}

function renderRecentlyViewProducts(el){	
renderProducts( {data:__recentlyViewedProducts}, 'scroll', el);
}
	
function renderProductPreview(p, type = 'scroll', element = '#product-preview-container' ) {
	//alert( JSON.stringify(p))
	
	newCartData=p;
  let rows = '';

 history.replaceState({}, '', buildUrl(`product/${p.slug}`));
 
   const inCart=cart.find(c=>c.id==p.id);      
          
const images=p.product_images?.split('||')||['|https://dummyimage.com/500x500/FFE5D0/fff&text=' + p.name[0].toUpperCase() ];
    
    images.forEach(imgData=>{
    	const image=imgData.split('|')[1];
    
    rows += `
      <div class="${type === 'scroll' ? 'flex-shrink-0' : 'col-12 col-md-3'}"
           style="${type === 'scroll' ? 'width: 300px;' : ''}" data-id="${p.id}">

        <div class="card mb-2 product-card-${p.id}">         
          <div class="preview product-img-container">
          <span><i class="fas fa-spin fa-spinner"></i></span>
            <img src="${productImage(image)}" loading="lazy" class="product-image" alt="${p.name}" onload="productImageLoaded(this);" onerror="productImageError(this);">
          </div>
        </div>
      </div>
    `;
});

const productInfo=`<div class="card-body text-left py-0 px-1 pt-1">
      <h5 class="product-name">${p.name}</h5>
            <p class="mb-1">
              <span class="product-price">₦ ${formatMoney(p.sale_price||p.price, 0)}</span>
              ${
                (+p.sale_price && +p.sale_price < +p.price)
                  ? `<sup class="text-muted text-decoration-line-through">₦ ${formatMoney(p.price, 0)}</sup>`
                  : ''
              }
            </p>
          ${p.description||''}
          </div>`;

  if (type === 'scroll') {
  	
    $(element).html(`
      <div class="d-flex flex-nowrap overflow-auto gap-2 pb-2 scroll-snap">
        ${rows}
      </div>   
      
 <div class="mb-2">
     ${productInfo}
     </div>    
     `);
     
     
 $('#product-preview-full-desc').html(`<div class="mb-2">
     ${p.full_description}
     </div>`);
$('#product-preview-footer').html(`    
    <div class="d-flex flex-nowrap gap-2 px-2 mb-2">
${config.contact.phone?`<a class="btn btn-outline-warning" href="tel:${config.contact.phone}">`:''}
<i class="fas fa-phone-volume"></i> </a>

${config.contact.whatsapp?`<button class="btn btn-outline-warning" onclick="productInfoRequest(this);">
<i class="fab fa-whatsapp"></i> </button>`:''}
    <button class="btn ${inCart?'btn-success':'btn-warning'} add-to-cart text-truncate" style="width: 100%;" data-id="${p.id}">
<i class="fas fa-shopping-cart"></i> <span>${inCart?'Remove from cart':'Add to cart'}</span></button>

<button class="btn btn-outline-warning" data-url="${buildUrl(`product/${p.slug}`)}" data-title="${escapeHtml(p.name)}" onclick="shareProductLink(this);">
<i class="fas fa-share"></i> </button>
</div>`);
   
  } else {
    $(element).html(`<div class="row">${rows}</div>`);
  }

  cart.forEach(c => {
    $(`.product-card-${c.id}`).addClass('item-selected');
  });
    setLastSection('productInfo', p.id); 
    
    //Load other products in the same category
   
    const payload={
     category: p.category_ids.split(',')?.[0],
     limit: 4
}

fetchData( 'get-products__', payload,  function( data, error, e){
     //alert( JSON.stringify(data))
	 if( error){
	return showToast(error);
 }
		
if(  data.success){	
 	if(!data.data.length ){
 	   return showToast('No products yet');
 }
  renderProducts(data,  'scroll', `#product-preview-related-products` , 'min-width: 35%; max-width: 300px;');
 }

  });
  
}

async function shareProductLink(t){
	const this_=$(t);
	
	const title=this_.attr('data-title')||'';
	
   const url=this_.attr('data-url');
   if( !url) {
   	return showToast('Product link not found');
   }
   
   if (navigator.share) {
        try {
            await navigator.share({
                title: title||document.title,
                url });
        } catch (err) {
            console.log(err);
        }
    } else {
        copyText(url);
        showToast('Link copied to clipboard', 'success');
    }
}
	
function productInfoRequest(t){
const customer= JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');

 ['name','address','phone','email','state'].forEach(( val, ind)=>{
 
	if(!customer[val] )  {
  openRegistrationForm();
  throw new Error("Fill customer info");
   }
});

newCartData.qty=1;

const message = formatCartForWhatsApp( [newCartData]);
     sendToWhatsApp(message);    
}
	
function renderCart(elementId) {
  $('#cartItems').html('');
  let total = 0;
  let totalItems=0;
  
  cart.forEach(c => {
  //	alert( JSON.stringify(c))
  	const image=c.product_images?c.product_images.split('||')[0].split('|')[1]:'';
  
    total +=  (+c.sale_price||c.price) * c.qty;
    totalItems+=c.qty;
    
//alert( JSON.stringify(c))
    $('#cartItems').append(`
      <div>
         <div class="d-flex align-items-center mb-2">
    <div class="ratio ratio-1x1" style="width: 60px;">
  <img data-src="${productImage(image)||'https://dummyimage.com/500x500/999/fff&text=' + c.name[0]}" class="img-fluid rounded object-fit-cover lazy lazyload" alt="${c.name}">
</div>
        <div class="ms-2"><b>${c.name} x ${c.qty}<br>₦ <span id="cart-product-price-${c.id}">${ formatMoney( (+c.sale_price||+c.price)*c.qty)}</span></b></div>
      </div>
       <div class="d-flex align-items-center">
<button class="qty-btn minus me-2" data-id="${c.id}">-</button>
       <span class="d-block text-center" style="width: 50px;"><input id="qty-input-${c.id}" type="text" inputmode="numeric" min="1" step="1" class="qty-input form-control text-center rounded" data-id="${c.id}" value="${c.qty}" style="padding: 2px 8px;"></span>
 <button class="qty-btn plus ms-2" data-id="${c.id}">+</button>
        <a href="javascript: void(0);" class="ms-5 text-dark text-decoration-none remove" data-id="${c.id}">
          <i class="fa fa-trash"></i> Remove
        </a>
        </div>
        <hr>
      </div>`);
      
  $(`.product-card-${c.id}`).addClass('item-selected');
  });

if( elementId){
 const input=$('#qty-input-' + elementId)[0];
input.focus();

//setTimeout(()=>{
input.setSelectionRange(input.value.length, input.value.length);
 //}, 0);
}

  $('.cart-total').text( formatMoney(total));
  $('.cartCount').text(totalItems);
  osStorage.set(`cart`, JSON.stringify(cart));
  
   if( cart.length) $('#cart-btn').addClass('attention');
   else $('#cart-btn').removeClass('attention');
}


function buildCatzTree(data) {
    let map = {};
    let tree = [];

    data.forEach(item => {
        item.children = [];
        map[item.id] = item;
    });

    data.forEach(item => {
        if (item.parent_id) {
            if (map[item.parent_id]) {
                map[item.parent_id].children.push(item);
            }
        } else {
            tree.push(item);
        }
    });

    return tree;
}


function renderCategories(nodes, parentId = "root") {

    let html = `<ul class="list-group" id="group_${parentId}">`;

    nodes.forEach(node => {

        let hasChildren = node.children.length > 0;
        let collapseId = "cat_" + node.id;

        html += `<li class="list-group-item p-0 border-0">`;

        if (hasChildren) {
            html += `
                <div class="d-flex justify-content-between align-items-center"
                   data-bs-toggle="collapse"
                   href="#${collapseId}">
            <a href="${OsBaseUrl}/category/${node.slug}" data-slug="${node.slug}" class="text-dark py-2 w-100 text-decoration-none category-link">
              <b style="font-weight: normal"> <i class="${node.icon||'fas fa-star'}"></i>  ${node.name}</b>
             </a>
       <span class="flex-shrink-0 text-center" style="width: 50px;"><i class="fa-solid fa-chevron-down arrow-icon"></i></span>
                </div>

                <div class="collapse ps-3"
                     id="${collapseId}"
                     data-bs-parent="#group_${parentId}">
                     
                     ${renderCategories(node.children, node.id)}
                </div>
            `;
        } else {
            html += `
                <a href="${OsBaseUrl}/category/${node.slug}" data-slug="${node.slug}" class="d-block text-dark py-2 text-decoration-none category-link">
             <i class="${node.icon||'fas fa-star'}"></i> ${node.name}
                </a>
            `;
        }
        html += `</li>`;
    });

    html += '</ul>';
    return html;
}


function loadAllProducts(t){	
	const this_=$(t||this);		
    const page=this_.attr('data-page')||0;
    
	const thisId=this_.data('section');
	const section=$(`#${thisId}-view-all-container`);
	$('.view-all-section-elem').hide();
	
	if( section.length){
		section.show();
	}
	
togglePage('viewAllSection');
    
const payload={
    section: thisId,
    p: page
}

  if( this_.hasClass('loaded') && page==0)  return;

fetchData( 'view-all__', payload,  function( data, error, e){
   //alert( JSON.stringify(data))
	 if( error){
	return showToast(error);
 }
		
if(  data.success){	
 this_.addClass('loaded');
 
  renderProducts(data,  'row', `#${thisId}-data`, 'col-md-4 col-lg-3' );
 }

});
	
	if( section.length) return;
	
	//Build section
	
$('#view-all-container').append(`<section id="${thisId}-view-all-container" class="view-all-section-elem">
	
	<div id="${thisId}-data"><i>Fetching...</i></div>
	   <!-- Pagination -->
  
      <nav class="text-center my-3">
<button class="prev btn btn-sm btn-warning d-none" data-section="${thisId}" data-page="" onclick="loadAllProducts(this);">Previous</button>
<button class="next ms-2 btn btn-sm btn-warning d-none" data-section="${thisId}" data-page="" onclick="loadAllProducts(this);">Next</button>

</nav>
	</section>`);
}


function loadProductsByCategories(t, slug, link){
	const this_=$(t||this);		
    const page=this_.attr('data-page')||1;
    
 const container=$('#product-catz-container');

const sectionId='sectionProductsInCatz';
 const section=$('#' + sectionId);

   container.attr('data-slug', slug);
  
  slug= slug||container.attr('data-slug');
 
 $('#products-catz-slug').text(`"${slug.replace(/-/g,' ').substring(0,20) + '..."'}`);
 
 if( START__.categoryProducts &&
 START__.categoryProducts[slug] ){
 	
    const prods= START__.categoryProducts[slug];
 	if(  prods.success){	
 
 	if(!prods.data.length ){
 	   return showToast('No products yet');
 }
 
 $('#category-products-description').text( prods.data[0].category_full_desc);
  renderProducts(prods,  'row', `#product-catz-container`, 'col-md-4 col-lg-3');
  START__.categoryProducts=null;
  togglePage( sectionId, null, null, link);
   return;
   }
 }
  
const payload={
     category: slug,
     p: page,
}

fetchData( 'get-products__', payload,  function( data, error, e){
   //  alert( JSON.stringify(data))
	 if( error){
	return showToast(error);
 }
		
if(  data.success){	
 	if(!data.data.length ){
 	   return showToast('No products yet');
 }
  renderProducts(data,  'row', `#product-catz-container` ,'col-md-4 col-lg-3');
  togglePage( sectionId, null, null, link);
 }

  });
}
	

function loadPage(t, slug, link){
	const this_=$(t||this);		
    const page=this_.attr('data-page')||1;
    
 const container=$('#pages-data-container');

const sectionId='sectionPages';
 const section=$('#' + sectionId);

   container.attr('data-slug', slug);
  
  slug= slug||container.attr('data-slug');

 if( START__.page &&
 START__.page[slug] ){
 	
    const result= START__.page[slug];
   
 	if(  result.success){	
 
 $('#section-pages-title').text( result.data.title.replace(/&amp;/g,'&') );
 $('#pages-data-container').html( result.data.content);
  
  START__.page=null;
  togglePage( sectionId, null, null, link);
   return;
   }
 }
 
 
const payload={
     slug: slug,
     p: page,
}

fetchData( 'get-page__', payload,  function( data, error, e){
   //alert( JSON.stringify(data))
	 if( error){
	return showToast(error);
 }
		
if(  data.success){	
$('#section-pages-title').text( data.data.title);
$('#pages-data-container').html( data.data.content);
  
  togglePage( sectionId, null, null, link);
 }

 });
}


//Load Orders
function loadOrders(t, id='') {

	let this_=$(t||this);
    let p=this_.attr('data-page')||1;
 
  const s = document.getElementById('orders-search').value;
  const status = document.getElementById('orders-status').value;
  const from = document.getElementById('orders-from').value;
  const to = document.getElementById('orders-to').value;

   const payload={
    id: id,
    s,
    status,
    from,
    to,
    p,
    limit: 5
    }


 fetchData(`get-orders__`, payload, function(data, error, e){
     //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
        renderOrders(data);
	 }
  });
}


function renderOrders(data, element='#sectionUserOrders') {
  const tbody = $(element).find('tbody')[0];
//document.getElementById(el);
  tbody.innerHTML = '';

  if (!data.data.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center">No orders found</td></tr>`;
    return;
  }

//alert( JSON.stringify( data.data))
  data.data.forEach((o, index) => {
  	
    tbody.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>₦${formatMoney(o.total_amount)}</td>
        <td>${statusBadge(o.expired||o.status)}</td>
        <td style="min-width: 200px">

<div class="d-flex justify-content-between">
<div>

${statusBadge(o.payment_status)} ${o.status=='pending' && o.payment_status!=='paid'?`<button class="btn btn-sm btn-primary" onclick="payPendingOrder(this, '${o.id}','${o.order_uid}');">Pay</button>`:''}
</div><div>
 <button class="btn btn-sm btn-outline-success" onclick="sendToWhatsApp('*ORDER UID:* ${o.order_uid}----*Payment Status:* ${o.payment_status}');"><i class="fab fa-whatsapp fa-lg text-success"></i></button> <a class="btn btn-sm btn-outline-dark" href="tel:${config.contact.phone}">
<i class="fas fa-phone-volume"></i> </a>
</div>
</div>
</td>
        <td>${o.total_items}</td>
        <td>${timeAgo(o.created_at)}</td>
        <td>
          <button class="btn btn-sm btn-outline-dark" onclick="viewOrder(this, ${o.id})">
            View
          </button>
          
  <div class="dropdown d-inline-block">
       <button class="btn btn-light border btn-sm" data-bs-toggle="dropdown">
        <i class="fas fa-ellipsis-v"></i>
    </button>
<ul class="dropdown-menu dropdown-menu-end">
  <li><hr class="dropdown-divider"></li>
  
<li class="${$.inArray( o.status, ['pending','processing'] )<0 || o.payment_status=='paid' || o.expired ?'d-none': ''}"><button class="dropdown-item text-danger" onclick="cancelOrder(this, '${o.id}','₦${formatMoney(o.total_amount)}');"><i class="fas fa-times"></i>  Cancel Order</button></li>
                        </ul>
                    </div>
          
        </td>
      </tr>
    `;
  });
  
  
  $(element).find('.prev,.next').addClass('d-none');

	if( data.next){
		$(element).find('.next').removeClass('d-none').attr('data-page', data.next);
		}
	if( data.prev){
		$(element).find('.prev').removeClass('d-none').attr('data-page', data.prev);
	}
}


function viewOrder(t, id) {
  $this_=$(t);
try{
  const payload={
    id: id 
}

 fetchData(`get-order-details`, payload, function(data, error, e){
    //alert(JSON.stringify(e))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
        renderOrderDetails(data);        
      togglePage('sectionOrderItemsList');
        
	 }
  });
  
  }catch(e){
  	alert(e)
  }
}

function renderOrderDetails(data){
	
	const order = data.order;
    const items = data.items;

// alert( JSON.stringify( data))

  let html = `
    <div class="mb-3">
      <div><strong>Order UID:</strong> ${order.order_uid}</div>
      <div><strong>Status:</strong> ${statusBadge(order.status)}</div>
      <div><strong>Payment Status:</strong> ${statusBadge(order.payment_status) }</div>
      <div><strong>Payment Method:</strong> ${order.payment_method=='pod'?'Pay On Delivery':order.payment_method}</div>
      <div><strong>Total:</strong> ₦${formatMoney(order.total_amount)}</div>
      <div><strong>Order By:</strong> ${order.fullname}</div>
      <div><strong>Phone:</strong> ${order.phone}</div>
      <div><strong>Email:</strong> ${order.email}</div>
      <div><strong>State:</strong> ${order.state||''}</div>
      <div><strong>Address:</strong> ${order.address}</div>
      
      <div><strong>Date:</strong> ${timeAgo(order.created_at, true)}</div>
    </div>

    <div class="table-responsive">
      <table class="table table-sm table-bordered" style="min-width: 500px;">
        <thead>
          <tr>
            <th>Product</th>
            <th width="80">Qty</th>
            <th width="120">Price</th>
            <th width="120">Total</th>
          </tr>
        </thead>
        <tbody>
  `;

  items.forEach(item => {
  	const imgSrc = item.images?.[0]?.url 
    || `https://dummyimage.com/50x50/999/fff&text=${encodeURIComponent(item.name?.slice(0,2).toUpperCase() || '?')}`;
  
    html += `
      <tr>
        <td>
          <div class="d-flex align-items-center gap-2">
            <img src="${productImage(imgSrc)}" width="40" height="40" style="object-fit:cover;">
            ${item.name}
          </div>
        </td>
        <td>${item.quantity}</td>
        <td>₦${formatMoney(item.price)}</td>
        <td>₦${formatMoney(item.total)}</td>
      </tr>
    `;
  });

  html += `
        </tbody>
      </table>
    </div>
  `;

  $('#orderDetails').html(html)
	}


function cancelOrder( t,orderId, amount){	
	if(!confirm(`Cancel order?\nTotal Amount: ${amount}`) ) return;

const payload={   id: orderId }
	
	postData(`cancel-order`, payload, function(data, error, e){
 	//  alert(JSON.stringify(e))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
    $(t).remove();
         showToast( data.message||'Cancelled', 'info');
	 }
  }); 
}
	

function statusBadge(status) {
  const map = {
    pending: 'warning',
    paid: 'success',
    failed: 'danger',
    delivered: 'success',
    processing: 'info',
    shipped: 'primary',
    cancelled: 'danger',
    expired: 'dark',
    returned: 'secondary',
    refunded: 'primary',
    pertially_refunded: 'info'
  };

  return `<span class="badge bg-${map[status] || 'secondary'}" style="text-transform: capitalize;">${status}</span>`;
}

	
$(document).on('click','.add-to-cart', function(){
  const id = $(this).data('id');
  
  let item = cart.find(i => i.id == id);

  if(item){
  	  cart = cart.filter(i=>i.id!=id);
  $(this).removeClass('btn-success').addClass('btn-warning').find('span').text('Add to cart')
  
    $(`.product-card-${id}`).removeClass('item-selected');
 
  renderCart();
  showToast('Removed from cart', 'warning');
  return;
 }
  else {
  	
  if( cart.length >= +config.orders.maxOrderItems) return showToast(`You have reached the maximum number (${config.orders.maxOrderItems}) of items you can order at a time`);
  
 cart.push({...newCartData, qty:1})
   $(this).removeClass('btn-warning').addClass('btn-success').find('span').text('Remove from cart');
  }

  renderCart();
  showToast('Added to cart', 'info');
});

$(document).on('keyup','.qty-input', function(e){
	const this_=$(this);
  const id = this_.data('id');
  let value=Number(this_.val());
  let item = cart.find(i=>i.id==id);
  if( value<1) {
  	this_.val(1);
value=1;
}
  item.qty=value;
  renderCart(id);
});

$(document).on('click','.plus', function(){
  const id = $(this).data('id');
  let item = cart.find(i=>i.id==id);
  item.qty++;
  renderCart();
});

$(document).on('click','.minus', function(){
  const id = $(this).data('id');
  let item = cart.find(i=>i.id==id);
  if(item.qty > 1) item.qty--;
  renderCart();
});

$(document).on('click','.remove', function(){
  const id = $(this).data('id');
  const item=cart.find( c=>c.id==id);
  	if(!confirm(`Remove ${item.name}?`) ) return;
  
  cart = cart.filter(i=>i.id!=id);
  $(`.product-card-${id}`).removeClass('item-selected');
  renderCart();
  
  if( cart.length<1 ){
		showToast(`Your cart is now empty.`);
	}
});

/*
$('#search-products').on('input', function(){
  let val = $(this).val().toLowerCase();
  renderProducts(products.filter(p=>p.name.toLowerCase().includes(val)));
});
*/

$('#filter').on('change', function(){
  let val = $(this).val().toLowerCase();
  if(val=='all') renderProducts(products);
  else {
renderProducts(products.filter(p=>p.category.toLowerCase()==val));
}
});

function openCart(t){
		if( cart.length<1 ){
	showToast(`Your cart is empty. Add items to view them here.`);
	return;
		}
	togglePage('cart','appendUserInfo');
	setLastSection('cart', 1);
}


function appendUserInfo(return_){
	const userData=  JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');
	
 const custName=userData.name||'';
 const custPhone=userData.phone||'';
 const custEmail=userData.email||'';
 const custAddr=userData.address||'';
 
if( return_ ){
return `<strong><span class="customer-name">${custName}</span></strong> - 
   <small>
<span class="text-muted"> <i class="fa fa-location-dot text-danger"></i> <span class="customer-address">${custAddr}</span> <i class="fas fa-phone"></i> <span class="customer-phone">${custPhone}</span></span>
   </small> <a href="javascript: void(0);" class="text-decoration-none" onclick="openRegistrationForm(this)">Edit</a>`;
}
	
	$('.customer-name').text( custName);
    $('.customer-phone').text( custPhone);
    $('.customer-email').text( custEmail);
    $('.customer-address').text(custAddr);
}
	
function openRegistrationForm(t){
   const this_=$(t);
   
  const userData=  JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');

const form= document.getElementById('profileForm');
 
  	$('#customer-form-title').text(userData.name?`Update your info`:`Fill in your details`);

 hydrateForm(form, userData);
 
$('.user-form').addClass('d-none');

 if(userData.name ){
   $('#profile-form-title').text(`Enter your delivery info`);
 $('.user-form').addClass('d-none'); 
 $('.profile-form').removeClass('d-none');
  }else{
  $('.login-form').removeClass('d-none');
  }
 
 showToast('Please wait...', 'info');
 
 setTimeout(()=>{  
 
  if ($('#appModal').hasClass('show')) {
  	goBack();
  }
  },100);
  
  setTimeout(()=>{  togglePage('sectionCustomerForm');
},1000);
}
	
let trueAmount=0;

function checkOut(t){
	
	let this_=$(t);
	const userData= JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');
	
 ['name','address','phone','email','state'].forEach(( val, ind)=>{
 
	if(!userData[val] )  {
openRegistrationForm();
   throw new Error("Fill customer info");
   }
 });

  this_.prop('disabled', true).append(`<i class="fas fa-spin fa-spinner text-light"></i>`);

try{
let totalAmount=0;
let totalItems=0;

cart.forEach(c => {
    totalAmount +=(+c.sale_price||+c.price) * c.qty;
      totalItems+=c.qty;  
 });
 
const payload={
	cart: cart,
	totalAmount: totalAmount||0,
	totalItems: totalItems
}

 postData('checkout__', payload, function(data, error, e){
 	//alert( JSON.stringify(data))

 	this_.find('i').remove();
this_.prop('disabled', false)
		 
  if( error){
      if(e && e.missing_products){
    	const mp=e.missing_products;
    const totalMp=mp.total;
     //Get product names of missing products
    	let missingProducts='';
    	
   mp.forEach((pid, i)=>{
        	const prodName=cart.find(c=>c.id==pid).name;
        missingProducts+=prodName;
        if( (i+1) < totalMp ) missingProducts+=', ';
        });
       
    return showToast(`The following products are not available: ${missingProducts}`);
    }
  
  showToast(error);
   return
 }
 
const trueAmount=data.totalAmount;
  checkoutInfo(trueAmount, totalItems);      
 
  if( trueAmount!==totalAmount){
  	
  	data.orderItems.forEach( item=>{
  	 const pid=item.productId;
       const salePrice=item.salePrice;
 	  const newPrice=item.price;
    let itm=cart.find(s=>s.id==pid);
    itm.price=newPrice;
    itm.sale_price=salePrice;
  });
  
  renderCart();
    
 showToast(`Total amount updated: ${data.totalAmount}`, 'info');
  }

  });
  
  }catch(e){
  	alert(e);
  }
}
	
function checkoutInfo(totalAmount, totalItems){
		
const customer= JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');
 	
	App.showModal({
        title: 'Place your order',
        icon: 'fa-solid fa-cart-shopping text-success',
        size: 'modal-lg',
        body: `
        <p><small>A WhatsApp-enabled number is preferable to receive faster delivery updates and support. You can tap “<a href="javascript: void(0);" class="text-decoration-none" onclick="openRegistrationForm(this)">here</a>” to update your number before checkout.</small></p>
      
      <div class="mb-2">
                <h5 class="fw-bold">Order Summary</h5>       
     <div class="container d-flex justify-content-between flex-wrap">
     <p class="mb-1 w-50">Item's total (${totalItems})</p>         <p class="text-primary"><b>₦${Number(totalAmount).toLocaleString()}</b></p>
         <p class="mb-1 w-50"><b>Total Amount</b></p>         <p class="text-primary"><b>₦${Number(totalAmount).toLocaleString()}</b></p>
         </div>
        </div>
<div class="alert alert-secondary py-2 my-0 mt-0">
<small>Customer Address (For faster delivery & communication, please use a phone number active on WhatsApp.)</small>
</div>
<div id="checkout-customer-info" class="mb-2"></div>

            <div class="alert alert-info d-flex d-none">
                <i class="fas fa-info-circle me-2 fs-4"></i>
      <div id="online-payment-info" class="check-out-info">
        After successful payment, please stay on the payment page until you are redirected to our WhatsApp customer representative for a faster response.
                </div>
    
<div id="pod-info" class="check-out-info">
Pay on Delivery (POD) means you pay for your order when it is delivered to you. No upfront payment is required. Please have your payment ready in cash or mobile payment when the delivery arrives.
</div>                                        
            </div>

            <div class="alert alert-warning mb-3">
                <i class="fa-solid fa-truck me-2"></i>
                Delivery may take up to <strong>${config.shipping.maxDate} days</strong> depending on your location.
            </div>

<div id="confirmError" class="text-danger d-none">
                Please confirm before proceeding.
            </div>

            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="confirmCheckbox">
                <label class="form-check-label" for="confirmCheckbox">
                    I understand and agree to proceed
                </label>
            </div>

<div class="form-check mt-3 ${!config.payment.enablePod?'d-none':''}">
                <input class="form-check-input" type="checkbox" id="podCheckbox" onchange="togglePodInfo(this);">
                <label class="form-check-label" for="podCheckbox">
               Pay on delivery
                </label>
            </div>            
        `,
        buttons: [
            {
                text: 'Cancel',
                class: 'btn-secondary modal-close-btn',
                action: 'close'
            },
           {
           	text: 'Place Order',
                class: 'btn-primary send-order-btn d-none',
                onClick: function(){
                	
              const isChecked = $('#confirmCheckbox').is(':checked');

  $('#confirmError').addClass('d-none');
                    if (!isChecked) {
                        $('#confirmError').removeClass('d-none');
                        return;
                    }
   
placeOrder('pod'); 
                }
           },
           
            {
                text: 'Pay Now',
                class: 'btn-success pay-now-btn',
                onClick: function (modal) {
                    const isChecked = $('#confirmCheckbox').is(':checked');
    $('#confirmError').addClass('d-none');
                    if (!isChecked) {
                        $('#confirmError').removeClass('d-none');
                        return;
                    }
    
   placeOrder( 'online'); 
               //  modal.hide();
                }
            }
        ]
    });
 
 $('#checkout-customer-info').html(appendUserInfo(true));
 
}

function placeOrder( paymentMethod='pod'){
	const userData= JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');
	
let totalAmount=0;
	
cart.forEach(c => {
    totalAmount +=(+c.sale_price||+c.price) * c.qty;
 });
 
const payload={
	cart: cart,
	totalAmount: totalAmount||0,
	name: userData.name||'',
	phone: userData.phone||'',
	email: userData.email||'',
	address: userData.address||'',
	state: userData.state,
	payment_method: paymentMethod
}

 postData('place-order__', payload, function(data, error, e){
   //	alert( JSON.stringify(e))
		 
  if( error){
  	if(e && e.invalid_session){
  	showToast('Session expired! Click on the checkout button');
    setTimeout(()=>{
    	goBack();
    }, 100);
  return
  }
  
      if(e && e.missing_products){
    	const mp=e.missing_products;
    const totalMp=mp.total;
     //Get product names of missing products
    	let missingProducts='';
    	
   mp.forEach((pid, i)=>{
        	const prodName=cart.find(c=>c.id==pid).name;
        missingProducts+=prodName;
        if( (i+1) < totalMp ) missingProducts+=', ';
        });
       
    return showToast(`The following products are not available: ${missingProducts}. Remove them from cart`);
    }

  showToast(error);
   return
 }
  
 if( !data ||!data.success ){
 	 return showToast('Unknown error');
 }
 
  if( data.totalAmount!==totalAmount){
  	showToast(`Total amount adjusted: ${data.totalAmount}`, 'info');
  }
  
  const trueAmount=data.totalAmount;
  const orderUid=data.orderUid;
  const customReference=data.reference;
 
	const message = formatCartForWhatsApp( cart, (paymentMethod=='online'?true:false), orderUid);
  
 if( paymentMethod=='online'){
 	
const p={
   fullname: userData.name,
   email: userData.email,
   amount: trueAmount,
   reference: customReference,
   plain: '[[REF]]' + message,
   orderUid : orderUid,
   order: message.replace(/[\r\n]/g,'<br>').replace(/\*(.+?)\*/g, '<b>$1</b>').replace(/_(.+?)_/g, '<i>$1</i>')
   }

payNow( p);
return;
 }
  
  $('#order-filter-form')[0].reset();
clearCheckout();
 // sendToWhatsApp(message); 
  });
}
	
	
	
function togglePodInfo(t){
	$('.check-out-info, .send-order-btn, .pay-now-btn').toggleClass('d-none');
}

	
function payPendingOrder(t,orderId, orderUid){
 const btn=$(t);
 
	const userData= JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');

const payload={
	id: orderId,
	newReference: true
}

 btn.prop('disabled', true);
btn.addClass('pay-this-now');

	fetchData(`get-order-details`, payload, function(data, error, e){
    //alert(JSON.stringify(data))
    btn.prop('disabled', false);
    
	if( error){
	return showToast(error);
	}
	
const order=data.order;

if( order.payment_status=='paid'){
	return showToast('You already made payment. We are processing your order');
	}
	
	const p={
   fullname: userData.name,
   email: userData.email,
   amount: order.total_amount,
   reference: order.new_reference,
   orderUid : orderUid,
   }

payNow( p);
   });
}
	
function payNow(metadata){

try{
	if(typeof metadata!=='object') throw new Error("Invalid payment configuration");

if( !metadata.email||!metadata.amount )
throw new Error("Enter email & Amount");

     const email = metadata.email||'';
     const amount = Number( metadata.amount||0);
           
            if (!email) {
                this.fail(form, "Enter a valid email address", btn);
                return;
            }

            if (amount < 150) {
                this.fail(form, `Amount must be at least ${config.currency.symbol}150`, btn);
                return;
            }

 const message=metadata.plain;
 const orderUid=metadata.orderUid;

delete metadata.email;
delete metadata.amount;
delete metadata.plain;

const popup=new OsPay(config.payment.publicKey);

  const btn=$('.pay-now-btn, .pay-this-now');
	
	btn.prop('disabled', true).append(`<i class="fas fa-spin fa-spinner text-light"></i>`);
	
            popup.checkout({
                email,
                amount,
                reference: metadata.reference,
                webhook_url: OsBaseUrl + '/api/webhook',
                metadata,
                onClose: (reference) => {     
    popup.toast('Payment closed. Try again!','info');
    clearCheckout();
   },
      onSuccess: (reference) => {
      	paymentSuccessful(reference, orderUid);
     // const msg=message.replace('[[REF]]',`*#PAID _(Verify payment)_*\n*Transaction Reference:*\n${reference}\n\n`);    
    //     sendToWhatsApp(msg);
    },
      onFail: (reference, msg) => {
      	showToast(msg);
      clearCheckout();
      },
               onError: (error) => {
                    showToast(error);
                },
              always: () => {
              	btn.removeClass('pay-this-now');
                    btn.prop('disabled', false).find('i').remove();
                }
            });

        } catch (e) {
         alert(e)            
        }
	}


function paymentSuccessful( reference, ){
	if( !reference ) {
		return showToast( 'Reference error');
	}
	
const payload={
		reference: reference
	}
	
	postData( 'payment-successful__', payload, function(data, error, e){
  //alert( JSON.stringify( data))

	if( error) {
		showToast(error)
		return;
		}

   clearCheckout();
	showToast(data.message, 'success');	
});
}
	
function clearCheckout(){
 //Clear cart
  cart=[];
  osStorage.remove(`cart`);
  renderCart();
  goBack();
      //Load orders page
    setTimeout( function(){  togglePage('sectionUserOrders', 'loadOrders');
}, 1000);
}	
	
	
$(function(){
	
document.getElementById('searchProductForm2').addEventListener('submit', function (event) {
  	  const form=this;
  	event.preventDefault();
    
    if (!form.checkValidity()) {      
    	form.classList.add('was-validated');
      return;
    } 
            
    const formData = new FormData(form);
    const searchData = Object.fromEntries(formData.entries());

  if( searchData.s.length<3 ){
  	return showToast('Enter at least 3 characters');
  }
  
    form.classList.add('was-validated');     
     searchProduct();    
  });	
  
	
	//LOGIN
	document.getElementById('loginForm').addEventListener('submit', function (event) {
  	
  const form=this;
  	event.preventDefault();
    
    if (!form.checkValidity()) {      
    	form.classList.add('was-validated');
      return;
    } 
            
    const formData = new FormData(form);
    const userData = Object.fromEntries(formData.entries());

    form.classList.add('was-validated');
 
postData( 'login', userData, function(data, error, e){
  	//alert( JSON.stringify( data))
	if( error) {
		showToast(error)
		return;
		}

     osStorage.set(`${__siteId}_user`,  JSON.stringify( data.user));
    
     osStorage.set('token', data.token);
     renderUserMenu();
     appendUserInfo();
     goBack();
     setTimeout(()=>{
     showToast(data.message, 'success');  
},500);  
     });     
  });    
  
  
 $('body').on('click', '#userProfileMenu a', function(e){
 	e.preventDefault();
 
 });
  	
	//REGISTER
	document.getElementById('registerForm').addEventListener('submit', function (event) {
  	
  const form=this;
  	event.preventDefault();
    
    if (!form.checkValidity()) {      
    	form.classList.add('was-validated');
      return;
    } 
            
    const formData = new FormData(form);
    const userData = Object.fromEntries(formData.entries());

    form.classList.add('was-validated');
    
    userData['type']='register';
    
postData( 'save-user__', userData, function(data, error, e){
  //	alert( JSON.stringify( e))
	if( error) {
		showToast(error)
		return;
		}
     osStorage.set(`${__siteId}_user`,  JSON.stringify( userData));
     appendUserInfo();
     osStorage.set('token', data.token);
     showToast(data.message, 'success');
     renderUserMenu();
  goBack();
     });
     
  });    
  
  
  document.getElementById('profileForm').addEventListener('submit', function (event) {
  	
  const form=this;
  	event.preventDefault();
    
    if (!form.checkValidity()) {      
    	form.classList.add('was-validated');
      return;
    } 
            
    const formData = new FormData(form);
    const userData = Object.fromEntries(formData.entries());

    form.classList.add('was-validated');
    
    userData['type']='profile';
    
postData( 'save-user__', userData, function(data, error, e){
  //	alert( JSON.stringify( e))
	if( error) {
		showToast(error)
		return;
		}
     osStorage.set(`${__siteId}_user`,  JSON.stringify( userData));
     appendUserInfo();
     goBack();
     showToast('Updated', 'success');    
     });
     
  });    
})

function searchProduct( t){
	const this_=$(t||this);
	const page=this_.attr('data-page')||1;
	
 const text=	$('#searchProductForm2').find('[name="s"]').val();
 
 const payload={
     s: text,
    //  limit: 1,
      p: page
}	
		
 fetchData('search__', payload, function(data, error, e){
      //alert( JSON.stringify(data))
		if( error){
	return showToast(error);
		}		
if( data.success){
 if(!data.data.length){
 	 $('#product-search-container').html('<h4 class="text-center">No product found for your search term</h4>');
 return;
 }
  renderProducts(data,  'row', `#product-search-container`, 'col-md-4 col-lg-3');
   }
});   
} 


function hydrateForm(form, data) {
  const $form = $(form);

  Object.keys(data).forEach(key => {
    const value = data[key];
    const $fields = $form.find(`[name="${key}"]`);

    if (!$fields.length) return;

    const type = ($fields.attr('type') || '').toLowerCase();
    const tag = ($fields.prop('tagName') || '').toLowerCase();

    // RADIO
    if (type === 'radio') {
      $fields.filter(`[value="${value}"]`).prop('checked', true);
    }

    // CHECKBOX
    else if (type === 'checkbox') {
      if (Array.isArray(value)) {
        // multiple checkboxes with same name
        $fields.each(function () {
          $(this).prop('checked', value.includes($(this).val()));
        });
      } else {
        // single checkbox
        $fields.prop('checked', Boolean(value));
      }
    }

    // SELECT (single or multiple)
    else if (tag === 'select') {
      $fields.val(value);
    }

    // INPUT, TEXTAREA, etc.
    else {
      $fields.val(value);
    }
  });
}	

function companyInfo(){
	 let b={}
	b.companyName='Ayo-Ola Trading Stores';
	b.logo='logo.png';
	
	$('.company-name').text( escapeHtml( b.companyName) );
	$('.company-logo').text( escapeHtml(b.logo) );
	
}
	

function toggleMenu(t, close){
	let el=$('#header-menu-container');
    let menuBtn=$('#header-menu-btn');
    
 if(!close) _pushState({
    element: '#header-ul',
    close: 'toggleMenu',
   args: [false, true]
   });
   
if(el.hasClass('menuOpen') ){
	//Close
 	el.removeClass('menuOpen');
   $('body').removeClass('overflow-hidden');
   menuBtn.find("i").css('transform', 'rotate(0deg)')	
  
}else{
	//Open
	el.addClass('menuOpen');
	$('body').addClass('overflow-hidden');
	menuBtn.find("i").css('transform', 'rotate(50deg)')	
  }
}
	
function togglePage(pageId, callback, onClose='', addressBar=''){

  let page=$('#' + pageId);

page.addClass('showSection');

 page.find('.page-blur').show();
  
  _pushState({
    element: '#' + pageId,
   close: 'closePage',
   args: [pageId, onClose]
   }, addressBar);
   
   if(callback) window[callback]();
	$('body').addClass('overflow-hidden');
}

function closePage(page, onClose){
	if(onClose) window[onClose]();
	sessionStorage.removeItem('trigger-section');
	
	$('body').removeClass('overflow-hidden');
	
	setTimeout(()=>{
		if( $('.showSection').length<2){
			history.replaceState({}, '', buildUrl());
			}
$('#' + page).removeClass('showSection');

}, 100);
 
}

function setLastSection(section, data){
	const keep_=new Object();
	keep_.section=section;
	keep_.data=data;
	
	sessionStorage.setItem('trigger-section', JSON.stringify( keep_));
	
}

function getLastSection(){
	const data=sessionStorage.getItem('trigger-section')||'';
	
	if(!data) return false;
	sessionStorage.removeItem('trigger-section')||'';
	return JSON.parse(data);
}

function resolveLastSection(){
const last=getLastSection();

if( !last) return;
  let section=last.section;
  
if( section=='productInfo'){
	 $('<div>')
  .addClass('product-elem')
  .attr('data-id', last.data)
  .on('click', function () {
      previewProduct($(this).data('id'));
  }).click();
	}else if( section=='cart'){
		openCart();
		}
}


	
function goBack(t){
	$(t).prop('disabled', true);
	history.go(-1);
	setTimeout(()=>{
		$(t).prop('disabled', false);
 }, 300);
}
	

function formatCartForWhatsApp( cart, forEmail, orderUid='Product Details Request') {
	const customer= JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');

//const line='-------------------------------------';
	const line='━━━━━━━━━━━━━━';

  let message = "";

 if( !forEmail ) message +="⚠️ DO NOT EDIT THIS MESSAGE.\n_(Any modification will automatically VOID this order)_\n\n";
	
  message += "🛒 *NEW ORDER*\n";
  message += `*Order ID* ${orderUid}\n\n`;
  // Customer Info
  message += "👤 *CUSTOMER DETAILS*\n";
  message += `*Name:* ${customer.name||'NA'}\n`;
  message += `*Phone:* ${customer.phone||'NA'}\n`;
  message += `*Email:* ${customer.email||'NA'}\n`;
  message += `*Address:* ${customer.address||'NA'}\n`;

  if (customer.note) {
    message += `*Note:* ${customer.note}\n`;
  }

  message += `\n${line}\n\n`;

  // Group by category
  const grouped = {};
  cart.forEach(item => {
    if (!grouped[item.categories]) {
      grouped[item.categories] = [];
    }
    grouped[item.categories].push(item);
  });

  let total = 0;

  // Loop categories
  Object.keys(grouped).forEach(category => {
    message += `📦 *${category.toUpperCase()}*\n\n`;

    grouped[category].forEach((item, index) => {
      const subtotal = ( item.sale_price||item.price) * item.qty;

      message += `- *${item.name}*\n`;
      message += `  ₦${(item.sale_price||item.price).toLocaleString()} x ${item.qty}\n`;

        message += `  Subtotal: ₦${subtotal.toLocaleString()}\n`;
        total += subtotal;
  
      message += `\n`;
    });
    message += "\n";
  });

  // Total
  message += `${line}\n`;
  message += `💰 *TOTAL: ₦${total.toLocaleString()}*\n`;
  message += `${line}`;

  return message;
}


function sendToWhatsApp(message, phone) {
	message=message.replace('----','\n');
	try{
  phone=("" +(phone||config.contact.whatsapp) ).replace(/\+/g, "");

  const encodedMessage = encodeURIComponent(message);

  const url = `https://api.whatsapp.com/send/?phone=${phone}&text=${encodedMessage}`;
  window.open(url, "_blank");
  }catch(e){
  	alert(e)
  }
}

$(function(){
	
$('body').on('click','.page-blur', function(e){
 	history.go(-1);
 });
 
 $('body').on('click','.product-elem', function(e){
 	e.preventDefault();
 	const id=$(this).data('id');
 	previewProduct(id);
 });
 
 $('body').on('click','.category-link', function(e){	
 	e.preventDefault();
 const link=$(this).attr('href');
 
 	const slug=link.split('/').pop();

loadProductsByCategories(null, slug, link);
});

$('body').on('click','.ajax-page-link', function(e){	
 	e.preventDefault();
 const link=$(this).attr('href'); 
 const slug=link.split('/').pop();
loadPage(null, slug, link);
});

$('#createUserFormX').on('submit', function (e) {
	
    e.preventDefault();
const alertBox = $('#alertBox');

let form = this;

   if (!$(this)[0].checkValidity()) {
        $(this).addClass('was-validated');
        return;
    }

    const payload = {
        role: document.getElementById('role').value,
        branch: document.getElementById('user-branch').value.trim(),
        full_name: document.getElementById('full_name').value.trim(),
        username: document.getElementById('username').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        email: document.getElementById('email').value.trim(),
        password: document.getElementById('password').value
    };

  let btn=$(form).find('button');
        btn.prop('disabled', true);
   
  postData('create-user', payload, function(data, error){
  	btn.prop('disabled', false);
       alertBox.removeClass('d-none, alert-success, alert-danger');
        
if( error){
            showToast( error, 'error');  
            alertBox.addClass('alert-danger');
            alertBox.text(error || 'Failed to create user');
            return;
        }

  showToast(data.message || 'User created successfully', 'success');
            alertBox.addClass('alert-success');
            alertBox.text(data.message || 'User created successfully');
            form.reset();
            $(this).removeClass('was-validated');         
            return;      
  });
  
});


});


function openUserProfile(){
	const userData=  JSON.parse( osStorage.get(`${__siteId}_user`)||'{}');
	
	$('.profile-user-name').text( userData.name||'');
    $('.profile-user-email').text( userData.email||'');
    $('.profile-user-address').text( userData.address||'');	
  $('.profile-user-avatar').attr('src', userData.avatar||'https://dummyimage.com/50x50/ffc107/fff&text=' + (userData.name[0]||'u'));
  
  loadUserProfile();
}
	
function loadUserProfile(){
		fetchData(`user-profile`, {}, function(data, error, e){
	//	alert(  JSON.stringify( data));
	
 if( error){
   showToast( error);
return;
}

renderUserProfile(data);
togglePage('sectionUserProfile');
 });
}
	
function renderUserProfile(data){
  	//alert(  JSON.stringify( data));
 
  //Stats
  const stats=data.stats;
  
$('.user-stat-total-orders').text(stats.total_orders);
$('.user-stat-total-pending-delivery').text( stats.pending_delivery);
$('.user-stat-total-delivered').text( stats.delivered);

renderOrders(data.orders, '#user-orders-summary');
}
	
	
function renderUserMenu(){
	const container=$('#user-menu-items');

	if( osStorage.get('token') ){
		container.html(`<li><button class="dropdown-item" type="button" onclick="openUserProfile(this);">
  <i class="fa-solid fa-user-gear me-2"></i> Profile
</button></li>
<li><button class="dropdown-item text-danger" type="button" onclick="logOut();">
  <i class="fa-solid fa-power-off me-2"></i>Logout
</button></li>`);
    return;
		}
	
 container.html(`<li><a role="button" tabindex="0" class="dropdown-item text-danger" onclick="loginForm(this);"><i class="fas fa-sign-in-alt"></i> Login</a></li>`);
}

function loginForm(){
	$('.user-form').addClass('d-none');
	$('.login-form').removeClass('d-none');
	togglePage('sectionCustomerForm');
}
	
function loggedIn(){
	return osStorage.get('token');
}

function logOut(c=true){

	if(c ){
if( !confirm('Confirm you want to logout')) return;
}
	
const token=osStorage.get('token')||'';

	fetchData(`logout`, {token: token} , function(data, error){
	//	alert(  JSON.stringify( data));
	
 if( error){
   showToast( error);
return;
}

osStorage.remove(`${__siteId}_user`);
osStorage.remove('token');
renderUserMenu();
showToast('Logged out!', 'info');
   //location.href=serverUrl + '/login.php';
  });
   
}


/*ANIMATION & CHARTS*/

function animateValue(id, start, end, duration, isAmount=false) {

const el=$("#"+id);


  if( end==0) {
    el.text(isAmount?end.toFixed(2):end)
 return;
}
  
let range = end - start
let current = start
let increment = end > start ? 1 : -1
let stepTime = Math.abs(Math.floor(duration / range));

let timer = setInterval(function(){

current += increment

if( current==200) increment=increment*5000;

if(current >= end){
	current=end;
clearInterval(timer)
}

if( isAmount) {
	 if( current<1000 )
el.text( current.toFixed(2));
 else el.text(current.toLocaleString('en-US') );
 return;
}else{
	el.text(current);
	}

}, stepTime)

}

function salesChart( labels, sales){
const ctx = document.getElementById('salesChart')

new Chart(ctx, {

type:'line',

data:{
labels:labels,
datasets:[{
label:'Sales',
data:sales,
borderWidth:3,
fill:true
}]
},

options:{
responsive:true,
plugins:{
legend:{
display:true
}
}
}

})

}

$(function(){
	
$('body').on('submit','#contactForm',  function(e) {
  e.preventDefault();

  let name = document.getElementById("name").value.trim();
  let email = document.getElementById("email").value.trim();
  let subject = document.getElementById("subject").value.trim();
  let message = document.getElementById("message").value.trim();

  let valid = true;

  // Reset errors
  document.querySelectorAll("small.text-danger").forEach(el => el.innerText = "");

  // Validation
  if (name === "") {
    document.getElementById("nameError").innerText = "Name is required";
    valid = false;
  }

  if (email && !email.includes("@")) {
    document.getElementById("emailError").innerText = "Enter valid email address";
    valid = false;
  }

  if (subject === "") {
    document.getElementById("subjectError").innerText = "Subject is required";
    valid = false;
  }

  if (message === "") {
    document.getElementById("messageError").innerText = "Message cannot be empty";
    valid = false;
  }

  if (!valid) return;

  let phoneNumber = config.contact.whatsapp;
alert( phoneNumber)
  let text = `Hello!%0A
Name: ${name}%0A
Email: ${email}%0A
Subject: ${subject}%0A%0A
Message: ${message}`;

  let whatsappURL = `https://api.whatsapp.com/send/?phone=${phoneNumber}&text=${text}`;

  window.open(whatsappURL, "_blank");
});


 $('#forgot-password-form').on('submit', function (e) {
     e.preventDefault();

        let form = $(this);
        let valid = true;

        form.find('.is-invalid').removeClass('is-invalid');

        // Email
        const email = $('#forgot-email').val().trim();

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {

            $('#forgot-email').addClass('is-invalid');

            valid = false;
        }

        if (!valid) {
            return;
        }

        // Loading
        $('#forgot-btn')
            .prop('disabled', true)
            .html(`
                <span class="spinner-border spinner-border-sm me-2"></span>
                Sending...
            `);

const formData= new FormData(form[0]);
    const payload = Object.fromEntries(formData.entries());

postData( `forgot-password`, payload, function(data, error, e){
	$('#forgot-btn').prop('disabled', false).text('Send Reset Link');
                    
	if( error) {
		showToast(error)
		return;
		}
		goBack();
  showToast(data.message, 'success');  
       });
   });


});

function formatMoney(amount, deci=2) {
  return Number(amount).toLocaleString('en-US', {
    minimumFractionDigits: deci,
    maximumFractionDigits: deci
  });
}

function timeAgo(dateString, noFormat){

    let date = new Date(dateString);
    let now = new Date();

    let diff = now - date;
    let oneDay = 1000 * 60 * 60 * 24;

    let days = Math.floor(diff / oneDay);

    let time = date.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

    let fullDate = date.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    }) + " " + time;

if( noFormat)  return fullDate;

    if(days === 0){
        return "Today, " + time;
    }
    else if(days === 1){
        return "1 day ago, " + time;
    }
    else if(days === 2){
        return "2 days ago, " + time;
    }
    else{
        return fullDate;
    }
}

//MODAL
window.App = window.App || {};

App.showModal = function (options = {}) {
  
    const defaults = {
        title: 'Title',
        body: '',
        size: '', // '', 'modal-sm', 'modal-lg', 'modal-xl'
        icon: '', // fontawesome class e.g. 'fa-solid fa-circle-info'
        buttons: [
            {
                text: 'Close',
                class: 'btn-secondary',
                action: 'close'
            }
        ],
        onOpen: null,
        onClose: null
    };

    const settings = {...defaults, ...options};

    const modalId = 'appModal';

    // Remove existing modal (reuse pattern)
    $('#' + modalId).remove();

    const iconHtml = settings.icon 
        ? `<i class="${settings.icon} me-2"></i>` 
        : '';

    const buttonsHtml = settings.buttons.map((btn, index) => {
        return `
            <button type="button" 
                class="btn ${btn.class}" 
                data-index="${index}">
                ${btn.text}
            </button>
        `;
    }).join('');

    const modalHtml = `
    <div class="modal fade" id="${modalId}" tabindex="-1">
        <div class="modal-dialog ${settings.size}">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        ${iconHtml}${settings.title}
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    ${settings.body}
                </div>
                <div class="modal-footer">
                    ${buttonsHtml}
                </div>
            </div>
        </div>
    </div>
    `;

    $('#appModalContainer').html(modalHtml);

    const modalEl = document.getElementById(modalId);
    const modal = new bootstrap.Modal(modalEl);

_pushState({
   close: 'closeModal',
   args: [true]
   });


    // Button actions
    $(modalEl).on('click', '.modal-footer button', function () {
        const index = $(this).data('index');
        const btn = settings.buttons[index];

        if (btn.action === 'close') {
            modal.hide();           
        }

        if (typeof btn.onClick === 'function') {
            btn.onClick(modal);
        }
    });

    // Events
    if (typeof settings.onOpen === 'function') {
        modalEl.addEventListener('shown.bs.modal', settings.onOpen);
    }

modalEl.addEventListener('shown.bs.modal', function(){
  App.modalOpened=true;
});

    if (typeof settings.onClose === 'function') {
        modalEl.addEventListener('hidden.bs.modal', settings.onClose);
    }

modalEl.addEventListener('hidden.bs.modal', function(){
	
	if( App.modalOpened) {	
     App.modalOpened=false;
          history.go(-1);
        }
});

    modal.show();
};

function closeModal(backBtn){
	if( backBtn ){
		App.modalOpened=false;
		const modalEl = document.getElementById('appModal');
	
const modal = bootstrap.Modal.getInstance(modalEl) 
            || new bootstrap.Modal(modalEl);

modal.hide();
return;
	}
}
	
function populateContactPage(){
	$('#business-contact-info').html(`<i class="fa fa-map-marker-alt me-2"></i> ${config.contact.address}</p>
      <p><i class="fa fa-phone me-2"></i> ${config.contact.phone}</p>
      <p><i class="fa fa-envelope me-2"></i> ${config.contact.email}
      
      <h5 class="mt-4">Business Hours</h5>
      <p>${config.business_days.open}</p>
      <p>${config.business_days.close}</p>

      <!-- Google Map -->
      <div class="mt-4">
        <iframe 
          src="https://maps.google.com/maps?q=${encodeURIComponent(`${config.contact.map}`)}&t=&z=13&ie=UTF8&iwloc=&output=embed"
          width="100%" 
          height="250" 
          style="border:0; border-radius:10px;" 
          allowfullscreen="" 
          loading="lazy">
        </iframe>
      </div>`);
      
	}
	

$(document).on('show.bs.collapse', '.collapse', function () {
    $(this).prev().find('span').html('<i class="fa-solid fa-chevron-up arrow-icon"></i>');
});

$(document).on('hide.bs.collapse', '.collapse', function () {
    $(this).prev().find('span').html('<i class="fa-solid fa-chevron-down arrow-icon"></i>');
});



function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
    }

    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();

    try {
        document.execCommand('copy');
    } finally {
        document.body.removeChild(textarea);
    }

    return Promise.resolve();
}

// Optional: detect changes
window.addEventListener('resize', () => {
    //console.log('Updated viewport width:', window.innerWidth);
    
    let el=$('#header-menu-container');
   
if(el.hasClass('menuOpen') ){
	//toggleMenu(false, true);
}
    
});
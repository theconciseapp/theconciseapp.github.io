<?php class FrontendApi extends ProjectAPI {    
    public $singleProductPage=false;
    
public function start__(){
  
  $s =       $this->segments;
  $count=count( $this->segments);
  $meta=array();

$meta['site_name']=htmlspecialchars($this->AppSettings['app']['name']);
$meta['title']=htmlspecialchars($this->AppSettings['app']['title']);
$meta['description']=htmlspecialchars($this->AppSettings['app']['description']);
$meta['canonical']=htmlspecialchars($this->site_url());
$meta['images']="1|" . htmlspecialchars($this->AppSettings['app']['logo']); 
  
$results = [];

$results["success"] = true;
$results["featured"] = $this->getFeaturedProducts();

if( !$this->isBot() ){
$results["newProducts"] = $this->getNewArrivals();
$results["bestSellers"] = $this->getBestSellers();
$results["topDeals"] = $this->getTopDeals();
$results["trending"] = $this->getTrendingProducts();
}

if( $count> 0 ){
    switch( $s[0]){
   case 'product':
 
if( empty($s['1']) ) break;
$product=$this->getProducts( ['slug'=>$s[1] ]);
 
 if( $product['success']){
 $this->singleProductPage=true;
 $prod=$product['data'][0]??[]; 
    
$meta['type']="product";
$meta['title']=htmlspecialchars($prod['name']??'');    $meta['description']=htmlspecialchars($prod['description']??'');
$meta['full_description']=htmlspecialchars($prod['full_description']??'');
$meta['images']=$prod['product_images'];   $meta['price'] = !empty($prod['sale_price']) ? $prod['sale_price'] : $prod['price'];

$meta['canonical']=$this->site_url() . '/product/' . $prod['slug']??'';      
 }
 
 $results['product']=$product;
 break;
 case 'category':
 if( empty($s[1] ) ) break;
 
 $category=$s[1];
 
 $catzProducts=$this->getProducts( ['category'=>$category] );
 
 if( $catzProducts['success']){
 	
 $firstProd=$catzProducts['data'][0]??[]; 
 
$meta['type']="product";
$meta['title']=htmlspecialchars($firstProd['category_title']??'');
$meta['description']=htmlspecialchars($firstProd['category_desc']??'');
$meta['full_description']=htmlspecialchars($firstProd['category_full_desc']??'');
$meta['images']=$firstProd['product_images'];   
$meta['canonical']=$this->site_url() . '/category/' . $s[1];      
 }
 
 $results['categoryProducts'][$category]=$catzProducts;
 break;
 case 'page':
 if( empty($s[1] ) ) break;
 
 $page=$s[1];
 
 $pageData=$this->getPage(['slug'=>$page]);
 
 if( $pageData['success']){
 	
 $firstProd=$pageData['data']??[]; 
 
$meta['type']="page";
$meta['title']=htmlspecialchars($firstProd['title']??'');
$meta['description']=htmlspecialchars($firstProd['description']??'');
$meta['images']=$firstProd['image']??'';   
$meta['canonical']=$this->site_url() . '/page/' . $s[1];      
 }
 
 $results['page'][$page]=$pageData;
 break;
 
     }
  }
  
  $results['meta']=$meta;
  
return $results;
}

public function userProfile(){
	
	return [
	    'success'=>true,
	    'stats'=>$this->getUserOrderCounts(),
	    'orders'=>$this->getOrders( ['frontend'=>true, 'limit'=>3] )
	];
}
   
public function getUserOrderCounts(int $userId=0): array{
	
if( $this->admin() && !empty( $userId) ){
   $userId=$data['id'];
}	else{
	$userId=$this->userId;
	}
	
    $sql = "
        SELECT
            COUNT(id) AS total_orders,
            SUM(
    CASE
        WHEN status IN ('pending', 'processing', 'shipped')
        THEN 1
        ELSE 0
    END
) AS pending_delivery,
            SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS delivered
        FROM orders
        WHERE user_id = ?
    ";

    $stmt = $this->db->prepare($sql);
    $stmt->execute([$userId]);

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return [
        'total_orders'     => (int) ($result['total_orders'] ?? 0),
        'pending_delivery' => (int) ($result['pending_delivery'] ?? 0),
        'delivered'        => (int) ($result['delivered'] ?? 0),
    ];
}
  
public function getProducts($options = []) {
 
    $req = $this->input();

    // Merge: request data overrides options
    $data = array_merge($req, $options);


   $id = intval($data['id']??0);
   $slug = $data['slug']??'';
   $preview = $data['preview']??false;
    $page  =  intval($data['p']??1);
    $limit = intval($data['limit']??20);
       
    $search = trim($data['s'] ?? '');
    $categoryId=$data['category']??'';

    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;
     
      $wheres[] = " p.site_id= ?";
      $params[] = $this->siteId;
      
    $wheres = [ "p.status=? "];
    $params = [ "active" ];
    
     if($id){     	
        $wheres[] = " p.id= ?";
        $params[] = $id;
    }else if( $slug) {
    	$wheres[] = " p.slug= ?";
        $params[] = $slug;
    }

    // 🔎 search by product name
    if(!$id && !$slug && $search != ""){
        $wheres[] = "MATCH(p.name) AGAINST (? IN BOOLEAN MODE)";
$params[] = $search . '*'; // allows prefix matching
    }

    // 🔎 search by category id
    if( !$id && !$slug && !empty( $categoryId ) ){
    	
    if( is_numeric( $categoryId ) ){
    	$wheres[] = " c.id =?";
        $params[] = $categoryId;
    }else{
        $wheres[] = " c.slug =?";
        $params[] = $categoryId;
       }
    }

  $where="";
  
if( !empty($wheres) ){
	$where=" WHERE " . implode(" AND " , $wheres);
	}

    $limitInc=$limit+1;

$select  = [];
$join    = [];
$selects = '';
$joins   = '';

/* -------------------------
   DYNAMIC PRODUCT DETAILS
--------------------------*/
if ($id||$slug||$categoryId) {

    // Product description
  if( $id||$slug)   $select[] = "p.description, p.full_description ";

    // Categories
    $select[] = "GROUP_CONCAT(DISTINCT c.name ORDER BY c.name SEPARATOR ', ') AS categories, c.name AS category_title, c.description AS category_desc, c.full_description AS category_full_desc ";
    $select[] = "GROUP_CONCAT(DISTINCT c.id ORDER BY c.id SEPARATOR ',') AS category_ids";

    // Joins
    $join[] = "LEFT JOIN product_categories pcat ON p.id = pcat.product_id";
    $join[] = "LEFT JOIN categories c ON pcat.category_id = c.id AND c.status = 1";

}

/* -------------------------
   BUILD STRINGS
--------------------------*/
$selects = $select ? ', ' . implode(', ', $select) : '';
$joins   = implode(' ', $join);

/* -------------------------
   MAIN QUERY
--------------------------*/

$sql = "
SELECT 
    p.id,
    p.name,
    p.slug,
    p.price,
    p.sale_price,
    p.cost_price,
    p.stock_quantity,
  
    GROUP_CONCAT(
  DISTINCT CONCAT(m.id, '|', m.url)
  ORDER BY m.id ASC
  SEPARATOR '||'
) AS product_images,

    COALESCE(p.sale_price, p.price) AS final_price,

    CASE 
        WHEN p.stock_quantity > 0 THEN 'in_stock'
        ELSE 'out_of_stock'
    END AS stock_status

    $selects

FROM products p

LEFT JOIN product_images pi ON p.id = pi.product_id
LEFT JOIN media_images m ON pi.media_id = m.id

$joins
$where

GROUP BY 
    p.id
 --   , p.name,
 --    p.slug,
 --    p.price,
 --    p.sale_price,
 --    p.cost_price,
 --   p.stock_quantity,

ORDER BY p.id DESC
LIMIT $limitInc OFFSET $offset
";

$rows="";

$key = "{$this->siteId}_get_products_catz_{$categoryId}_{$page}_{$limitInc}_{$offset}";

  if( $categoryId) {
       $rows = $this->cache->get($key, ['namespace'=>'products'] );
      }

if (!$rows) {
    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
    
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if( $categoryId) {  
  $this->cache->set($key, $rows, ['namespace'=>'products', 'tags'=>['category_products'], 'ttl'=>(60*35) ]);
  
}
}
    $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

$data=[];

foreach( $rows AS $row){
    	$i++;
    
   if( $limit>$i ) {
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}
   
//Stop bots from populating product views

   $userAgent = $_SERVER['HTTP_USER_AGENT'];
$bots = ['bot', 'crawl', 'slurp', 'spider', 'mediapartners'];

foreach ($bots as $bot) {
    if (strpos(strtolower($userAgent), $bot) !== false) {
        // It's a bot! Skip the database insert.
        $preview=false;
    }
}

   if( $id && $preview){   
// Proceed with INSERT...
   
try{	
$stmt = $this->db->prepare("
INSERT INTO product_views (
  product_id,
  user_id,
  session_id,
  ip_address,
  created_at
)
SELECT ?, ?, ?, ?, NOW()
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1 FROM product_views
  WHERE product_id = ?
  AND (
      ( ? IS NOT NULL AND user_id = ? )
      OR
      ( ? IS NULL AND session_id = ? )
  )
  AND created_at >= NOW() - INTERVAL 30 MINUTE
)");

$sessionId = session_id();

$stmt->execute([
    $id,
    $this->userId, 
    $sessionId,
    $this->userIp,
    $id,
    $this->userId, 
    $this->userId, 
    $this->userId, 
    $sessionId
]);

}catch(PDOException $e){
	
	  }
   }
   
  
   $total=0; //Currently not in use

    return [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "total"=>$total,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Succesful"
    ];
  
}


public function getFeaturedProducts() {
   
    $sql = "
        SELECT 
            p.id,
            p.name,
            p.slug,
            p.price,
            p.sale_price,
            p.stock_quantity,
            p.description,
          GROUP_CONCAT(  DISTINCT CONCAT(m.id, '|', m.url) ORDER BY m.id ASC  SEPARATOR '||' ) AS product_images,

            COALESCE(p.sale_price, p.price) AS final_price
        --    , p.created_at
        FROM products p
        
      LEFT JOIN product_images pi ON p.id = pi.product_id
LEFT JOIN media_images m ON pi.media_id = m.id  
        
        WHERE p.status = 'active'
       AND p.stock_quantity > 0
        AND p.featured_rank > 0
        GROUP BY 
    p.id
        ORDER BY p.featured_rank DESC
        LIMIT 10
    ";


$key = "{$this->siteId}_featured_products";
$rows = $this->cache->get($key, ['namespace'=>'products'] );

if (!$rows) {
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);
    $this->cache->set($key, $rows, ['namespace'=>'products', 'tags'=>['featured_products'], 'ttl'=>60*15 ]);
    }
    
        return [
        "success"=>true,
        "data"=>$rows,
        "message"=>"Successful"
    ];
}

public function getNewArrivals($days = 50) {
   
   $page  =  intval($_GET['p']??1);
   $limit = intval($_GET['limit']??8);
    
    
    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;
   
   $limitInc=$limit+1;
  
    $sql = "
        SELECT 
            p.id,
            p.name,
            p.slug,
            p.price,
            p.sale_price,
            p.stock_quantity,
          GROUP_CONCAT(  DISTINCT CONCAT(m.id, '|', m.url) ORDER BY m.id ASC  SEPARATOR '||' ) AS product_images,

            COALESCE(p.sale_price, p.price) AS final_price
        --    , p.created_at
        FROM products p
        
      LEFT JOIN product_images pi ON p.id = pi.product_id
LEFT JOIN media_images m ON pi.media_id = m.id  
        
        WHERE p.status = 'active'
      AND p.stock_quantity > 0
        AND p.created_at >= NOW() - INTERVAL ? DAY
        GROUP BY 
    p.id
        ORDER BY p.created_at DESC
        LIMIT $limitInc OFFSET $offset  
    ";

$key = "{$this->siteId}_new_arrival_{$page}_{$limit}_{$offset}_{$days}";

$rows = $this->cache->get($key, ['namespace'=>'new_arrival'] );

if(!$rows) {
    $stmt = $this->db->prepare($sql);
    $stmt->execute([(int)$days] );

    $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);
    $this->cache->set($key, $rows, ['namespace'=>'new_arrival', 'tags'=>['new_arrival'], 'ttl'=>60*60*48 ]);

    
    }
    
        $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

    $data=[];

foreach( $rows AS $row){
    	$i++;
    
   if( $limit>$i ) {
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}

        return [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Successful"
    ];
}

public function getBestSellers($days = 30) {
   
   $page  =  intval($_GET['p']??1);
   $limit = intval($_GET['limit']??8);
       
    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 10;

    $offset = ($page - 1) * $limit;
  
   $limitInc=$limit+1;
     
    $sql = "
        SELECT 
    p.id,
    p.name,
    p.slug,
    p.price,
    p.sale_price,
    p.stock_quantity,
    GROUP_CONCAT(
  DISTINCT CONCAT(m.id, '|', m.url)
  ORDER BY m.id ASC
  SEPARATOR '||'
) AS product_images,

    COALESCE(p.sale_price, p.price) AS final_price,
    
    SUM(oi.quantity) AS total_sold
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    JOIN orders o ON oi.order_id = o.id
    LEFT JOIN product_images pi ON p.id = pi.product_id
    LEFT JOIN media_images m ON pi.media_id = m.id
    WHERE 
    p.status = 'active'
     AND o.payment_status = 'paid' 
    AND p.stock_quantity > 0
      AND o.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
    GROUP BY p.id, p.name, p.price
ORDER BY total_sold DESC
        LIMIT $limitInc OFFSET $offset  ";
    
  
$key = "{$this->siteId}_best_sellers_{$page}_{$limit}_{$offset}_{$days}";

$rows = $this->cache->get($key, ['namespace'=>'products'] );

if( !$rows) {
    $stmt = $this->db->prepare($sql);
    $stmt->execute([(int)$days] );

    $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);
    $this->cache->set($key, $rows, ['namespace'=>'products', 'tags'=>['best_sellers'], 'ttl'=>60*60*4 ]);

    }
    
        $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

    $data=[];

foreach( $rows AS $row){
    	$i++;
    
   if( $limit>$i ) {
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}

        return [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Successful"
    ];
    
     }
  

public function getTopDeals() {
   
   $page  =  intval($_GET['p']??1);
   $limit = intval($_GET['limit']??8);
    
    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;
   
   $limitInc=$limit+1;
  
    $sql = "
        SELECT 
            p.id,
            p.name,
            p.slug,
            p.price,
            p.sale_price,
            p.stock_quantity,
            p.image,
            COALESCE(p.sale_price, p.price) AS final_price,
            GROUP_CONCAT(
  DISTINCT CONCAT(m.id, '|', m.url)
  ORDER BY m.id ASC
  SEPARATOR '||'
) AS product_images,

            p.created_at
        FROM products p
        LEFT JOIN product_images pi ON p.id = pi.product_id
LEFT JOIN media_images m ON pi.media_id = m.id
        WHERE p.status = 'active'
        AND p.stock_quantity > 0
        AND p.has_discount=1
        GROUP BY 
    p.id
        ORDER BY p.created_at DESC
        LIMIT $limitInc OFFSET $offset  
    ";

$key = "{$this->siteId}_top_deals_{$page}_{$limit}_{$offset}";

$rows = $this->cache->get($key, ['namespace'=>'products'] );

if( !$rows) {
    $stmt = $this->db->prepare($sql);
    $stmt->execute();

    $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);
    $this->cache->set($key, $rows, ['namespace'=>'products', 'tags'=>['top_deals'], 'ttl'=>60*60 ]);
  }
        $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

    $data=[];

foreach( $rows AS $row){
    	$i++;
    
   if( $limit>$i ) {
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}

        return [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Successful"
    ];
    
}


public function getTrendingProducts(){
    $page  = intval($_GET['p'] ?? 1);
    $limit = intval($_GET['limit'] ?? 8);

    if ($page < 1) $page = 1;
    if ($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;

    $sql = "
    SELECT 
        p.id,
        p.name,
        p.slug,
        p.price,
        p.sale_price,
        p.stock_quantity,

        -- Fetch pre-calculated count from sidecar
        COALESCE(pp.view_count, 0) AS view_count,

        COALESCE(p.sale_price, p.price) AS final_price,

        GROUP_CONCAT(
            DISTINCT CONCAT(m.id, '|', m.url)
            ORDER BY m.id ASC
            SEPARATOR '||'
        ) AS product_images

    FROM products p

    -- Join to our sidecar instead of the massive views log
    LEFT JOIN product_popularity pp ON p.id = pp.product_id

    LEFT JOIN product_images pi ON p.id = pi.product_id
    LEFT JOIN media_images m ON pi.media_id = m.id

    WHERE p.status = 'active'
    AND p.stock_quantity > 0

    GROUP BY p.id
    ORDER BY view_count DESC, p.created_at DESC
    LIMIT ? OFFSET ?
";

$key = "{$this->siteId}_trending_{$page}_{$limit}_{$offset}";

$rows = $this->cache->get($key, ['namespace'=>'products'] );

if(!$rows){
    $stmt = $this->db->prepare($sql);
    $stmt->execute([ $limit, $offset]);
 
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
$this->cache->set($key, $rows, ['namespace'=>'products', 'tags'=>['trending'], 'ttl'=>60*25 ]);

}

    $data = [];
    $nextPage = 0;
    $prevPage = ($page > 1) ? $page - 1 : 0;

    foreach ($rows as $i => $row) {
        if ($i < $limit) {
            $data[] = $row;
        } else {
            $nextPage = $page + 1;
        }
    }

    return [
        "success" => true,
        "page" => $page,
        "limit" => $limit,
        "next" => $nextPage,
        "prev" => $prevPage,
        "data" => $data,
        "message" => "Successful"
    ];
}

   
 public function generateOrderUID($prefix = 'OSWS') {
   return strtoupper($prefix . '-' . bin2hex(random_bytes(6)));
}


public function checkout() {
  $data=$this->input();
  
$cart=$data['cart']??'';

  $uTotalAmount=$data['totalAmount']??0;
  $sessionId=bin2hex(random_bytes(16));
 
  if (!is_array($cart) || empty($cart)) {
        $this->json([
         "success"=>false,
         "message"=>"Cart is empty"
         ]);
    }
  
  $settings=$this->AppSettings;
    $maxOrderItems=$settings['orders']['maxOrderItems']??20;

if( count( $cart) >= $maxOrderItems ){
	$this->json([
         "success"=>false,
         "message"=>"You have reached the maximum number ({$maxOrderItems}) of items you can order at a time"
         ]);
	}
  
  // ✅ Normalize cart (merge duplicates)
  $normalized = [];
    foreach ($cart as $item) {
        $id = (int)$item['id'];
        $qty = (int)$item['qty'];

        if ($id <= 0 || $qty <= 0) {
            $this->json([
         "success"=>false,
         "message"=>"Invalid cart data"
         ]);
        }

   if (!isset($normalized[$id])) {
            $normalized[$id] = 0;
        }
        $normalized[$id] += $qty;
    }
  
  //Maximum products is 20
      $productIds = array_slice(array_keys($normalized), 0, 20);          
   // ✅ Fetch products from DB
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));

    $stmt = $this->db->prepare("
        SELECT id, name, price, sale_price, stock_quantity 
        FROM products 
        WHERE id IN ($placeholders)
    ");
    $stmt->execute($productIds);

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$dbProductIds = array_column($products, 'id');

// find missing IDs
$missingIds = array_diff($productIds, $dbProductIds);

if (!empty($missingIds)) {
	
	$this->json([
         "success"=>false,
         "missing_products"=>array_values($missingIds),
         "message"=>"Some products not found"
         ]);    
}

    // Index products by ID
    $dbProducts = [];
    foreach ($products as $p) {
        $dbProducts[$p['id']] = $p;
    }

    // ✅ Validate + calculate total
    $totalAmount = 0;
    $orderItems = [];

    foreach ($normalized as $productId => $qty) {
        $product = $dbProducts[$productId];
        $salePrice =$product['sale_price'] ?? $product['price'];
        $price = $product['price'];

        if ($product['stock_quantity'] < $qty) {
        	$this->json([
         "success"=>false,
         "message"=>"{$product['name']} is out of stock"
         ]);
        }

        $itemTotal = $salePrice * $qty;
        $totalAmount += $itemTotal;

        $orderItems[] = [
            'productId' => $productId,
            'qty' => $qty,
            'salePrice'=>$salePrice,
            'price' => $price,
            'total' => $itemTotal
        ];
    }

$_SESSION['checkout-expiry']=time() + 600; //10 minutes

        $this->json( [
            'success' => true,
            'orderItems'=>$orderItems,
            'totalAmount' => $totalAmount,
            'message'=>'Successful'
        ]);
}    
    
    
    
public function placeOrder() {
 	
if( empty( $_SESSION['checkout-expiry'] )||
$_SESSION['checkout-expiry']< time() ){
	$this->json([
         "success"=>false,
         "invalid_session"=>true,
         "message"=>"Invalid session or expired"
         ]);
	}
  
$data=$this->input();
  
$cart=$data['cart']??'';
$custName=$data['name']??'';
$custPhone=$data['phone']??'';
$custEmail=$data['email']??'';
$custAddr=$data['address']??'';
$paymentMethod=$data['payment_method']??'';

  $uTotalAmount=$data['totalAmount']??0;
  $sessionId=bin2hex(random_bytes(16));
  
  $orderUid=$this->generateOrderUID();
  
  $userId=$this->userId;
  
  if( empty( $userId) ){
  	 if( empty($custName) ||
  empty($custEmail) ||
  empty($custPhone) ||
  empty($custAddr)  ){
  	$this->json([
         "success"=>false,
         "message"=>"Enter your details"
         ]);
     }
  }
  
  if (empty($cart)) {
        $this->json([
         "success"=>false,
         "message"=>"Cart is empty"
         ]);
    }
  
  if (empty($paymentMethod)) {
        $this->json([
         "success"=>false,
         "message"=>"Select payment method"
         ]);
    }
  // ✅ Normalize cart (merge duplicates)
  $normalized = [];
    foreach ($cart as $item) {
        $id = (int)$item['id'];
        $qty = (int)$item['qty'];

        if ($id <= 0 || $qty <= 0) {
            $this->json([
         "success"=>false,
         "message"=>"Invalid cart data"
         ]);
        }

        if (!isset($normalized[$id])) {
            $normalized[$id] = 0;
        }

        $normalized[$id] += $qty;
    }
  
  //Maximum products is 20
      $productIds = array_slice(array_keys($normalized), 0, 20);
      
      
   // ✅ Fetch products from DB
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));

    $stmt = $this->db->prepare("
        SELECT id, name, price, sale_price, stock_quantity 
        FROM products 
        WHERE id IN ($placeholders)
    ");
    $stmt->execute($productIds);

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$dbProductIds = array_column($products, 'id');

// find missing IDs
$missingIds = array_diff($productIds, $dbProductIds);

if (!empty($missingIds)) {
	
	$this->json([
         "success"=>false,
         "missing_products"=>array_values($missingIds),
         "message"=>"Some products not found"
         ]);    
}

    // Index products by ID
    $dbProducts = [];
    foreach ($products as $p) {
        $dbProducts[$p['id']] = $p;
    }

    // ✅ Validate + calculate total
    $totalAmount = 0;
    $orderItems = [];

    foreach ($normalized as $productId => $qty) {
        $product = $dbProducts[$productId];

        $price = $product['sale_price'] ?? $product['price'];

        if ($product['stock_quantity'] < $qty) {
        	
        	$this->json([
         "success"=>false,
         "message"=>"{$product['name']} is out of stock"
         ]);
        }

        $itemTotal = $price * $qty;
        $totalAmount += $itemTotal;

        $orderItems[] = [
            'product_id' => $productId,
            'qty' => $qty,
            'price' => $price,
            'total' => $itemTotal
        ];
    }

//Payment reference
$customReference=$this->generateReference( 'OSR');

    try {
        $this->db->beginTransaction();

        // ✅ Insert order
        $stmt = $this->db->prepare("
            INSERT INTO orders (site_id, user_id, customer_name, customer_phone, customer_email, customer_address, total_amount, order_uid, payment_reference, payment_method, status,   created_at, updated_at)
            VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,  'pending', NOW(), NOW())
        ");
        $stmt->execute([
            $this->siteId,
            $userId,
            $custName,
            $custPhone,
            $custEmail,
            $custAddr,
            $totalAmount,
            $orderUid,
            $customReference,
            $paymentMethod
        ]);

        $orderId = $this->db->lastInsertId();

        // ✅ Insert order items
        $stmt = $this->db->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price, total)
            VALUES (?, ?, ?, ?, ?)
        ");

        foreach ($orderItems as $item) {
            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['qty'],
                $item['price'],
                $item['total']
            ]);
        }

        // ✅ Reduce stock (important)
        $stmt = $this->db->prepare("
            UPDATE products 
            SET stock_quantity = stock_quantity - ? 
            WHERE id = ?
        ");

        foreach ($orderItems as $item) {
            $stmt->execute([
                $item['qty'],
                $item['product_id']
            ]);
        }

        $this->db->commit();

$metadata=[];
$metadata['customer']['name']=$custName;
$metadata['customer']['email']=$custEmail;
$metadata['customer']['phone']=$custPhone;
$metadata['customer']['addr']=$custAddr;
$metadata['amount']=$totalAmount;
$metadata['orderUid']=$orderUid;


$msg=$this->buildOrderEmail($cart, $metadata);

  /*
$this->queue->push('email', [
    'to' => $custEmail,
    'subject' => $msg['subject'], 
    'body' => $msg['message']
]);
*/

        $this->json( [
            'success' => true,
            'orderId' => $orderId,
            'orderUid'=>$orderUid,
            'reference'=>$customReference,
            'totalAmount' => $totalAmount,
            'message'=>'Successful'
        ]);

    } catch (Exception $e) {
        $this->db->rollBack();   
error_log( $e->getMessage());    
        $this->json([
         "success"=>false,
         "message"=>"Please try again"
         ]);
    }
}    


public function paymentSuccessful(){
    $data = $this->input();

    $reference = trim($data['reference'] ?? '');
    
    if (empty($reference)) {
        return $this->json([
            "success" => false,
            "message" => "Reference not found"
        ]);
    }

  
    // Get order
    $stmt = $this->db->prepare("
        SELECT customer_name, total_amount, payment_status, currency FROM orders WHERE payment_reference = ? LIMIT 1");

    $stmt->execute([$reference]);

    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        return $this->json([
            "success" => false,
            "message" => "Order not found"
        ]);
    }

    // Prevent duplicate processing
    if ($order['payment_status'] === 'paid') {
        return $this->json([
            "success" => true,
            "message" => "Order paid"
        ]);
    }

    // Verify payment from Paystack
    
$payment = $this->verifyPayment($reference);

    if (   !isset($payment['success']) || $payment['success'] !== true ) {

        return $this->json([
            "success" => false,
            "message" => $payment['message']??"Payment verification in progress"
        ]);
    }

    $payData = $payment['data'];

$orderAmount = (int) round($order['total_amount'] * 100);
$paidAmount  = (int) ($payData['amount'] ?? 0);

 $custName=$order['customer_name']??'';

if (  $paidAmount < $orderAmount ||
    strtolower($payData['currency'] ?? '') !== strtolower($order['currency'])
) {
    error_log("Payment mismatch for {$reference} by {$custName}");
   
        return $this->json([
            "success" => false,
            "message" => "Payment amount mismatch"
        ]);
    }

    // Save payment
    
   if( $this->markOrderAsPaid($reference) ){
   
    return $this->json([
        "success" => true,
        "message" => "Payment successful"
   ]);   
  }
}    

public function markOrderAsPaid($reference){
    if (empty($reference)) {
        return false;
    }

    $stmt = $this->db->prepare("
        UPDATE orders
        SET status='processing',  payment_status = 'paid',
            paid_at = NOW()
        WHERE payment_reference = ?
        LIMIT 1
    ");

    $stmt->execute([$reference]);
    return $stmt->rowCount() > 0;
}

public function markOrderAsFailed($reference){
    if (empty($reference)) {
        return false;
    }

    $stmt = $this->db->prepare("
        UPDATE orders
        SET payment_status = 'failed'
        WHERE payment_reference = ?
        LIMIT 1
    ");

    $stmt->execute([$reference]);

    return $stmt->rowCount() > 0;
}
	
public function verifyPayment($reference){
    $url = "https://www.oshobby.com.ng/paystack/api/verify?reference=" . urlencode($reference);

    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            "Cache-Control: no-cache",
        ],
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {

        $error = curl_error($ch);
        curl_close($ch);

        return [
            'success' => false,
            'message' => $error
        ];
    }

    curl_close($ch);

    $result = json_decode($response, true);

    if (!is_array($result)) {
        return [
            'success' => false,
            'message' => 'Invalid JSON response'
        ];
    }

    // API request failed
    if (($result['success'] ?? false) !== true) {
        return [
            'success' => false,
            'message' => $result['message'] ?? 'Verification failed'
        ];
    }

    $data = $result['data'] ?? [];

    // Payment not successful
    if (($data['status'] ?? '') !== 'success') {
        return [
            'success' => false,
            'message' => 'Payment not successful',
            'status'  => $data['status'] ?? null
        ];
    }

    return [
        'success' => true,
        'data'    => $data
    ];
}
  
// [ Test 
   /*
$reference='TXN_1779276272_d33e4e3dc3197b';
        
    $event = $this->verifyPayment($reference);

    if (   !isset($event['success']) || $event['success'] !== true ) {
      http_response_code(500);
        	exit;
    }
    
    $event['event']='charge.success';
   */ 
    // end test ]
    
public function webhook(){
   try{  
     if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SERVER['HTTP_X_OSPAYSTACK_SIGNATURE'])) {
    http_response_code(400);
    exit("Invalid request");
}
  
  $payload = file_get_contents("php://input");
 
   $signature = $_SERVER['HTTP_X_OSPAYSTACK_SIGNATURE'] ?? '';
   
    $settings=$this->AppSettings;
    $publicKey=$settings['payment']['publicKey'];
    
    $expected_signature = hash_hmac('sha512', $payload, $publicKey);

if ( $signature !== $expected_signature) {
    // Silent exit or log fraud attempt to protect server signature mapping
    http_response_code(401);
    exit("Signature verification failed");
    }

    $event = json_decode($payload, true);
   
if (!is_array($event)) {
    http_response_code(400);
    exit;
}
     
   $eventType = $event['event'] ?? '';
    $data = $event['data'] ?? [];
    $reference = $data['reference'] ?? '';
    
         
    if (!$reference) {
        http_response_code(200);
        exit;
    }

$q = $this->db->prepare( "SELECT total_amount, payment_status, currency FROM orders WHERE payment_reference = ? LIMIT 1");

            $q->execute([$reference]);         

            $order = $q->fetch(PDO::FETCH_ASSOC);

     if (!$order) {           	
                http_response_code(200);
                exit;
            }

$orderAmount = (int) round($order['total_amount'] * 100);
$paidAmount  = (int) ($data['amount'] ?? 0);

if (
    $paidAmount < $orderAmount ||
    strtolower($data['currency'] ?? '') !== strtolower($order['currency'])
) {
    error_log("Payment mismatch for {$reference}");
    http_response_code(200);
    exit;
}

    switch ($eventType) {
        case 'charge.success':       
                      
if ( $order['payment_status'] == 'paid'){        
 http_response_code(200);
     exit;
}

      $updated = $this->markOrderAsPaid($reference);
   
      if (!$updated) {
                http_response_code(500);
                exit;
    }

http_response_code(200);
     exit;
        case 'charge.failed':

$updated = $this->markOrderAsFailed($reference);

http_response_code(200);
exit;
 }
 
 http_response_code(200);
    exit;
    
 } catch (Throwable $e) {
    // log error
    error_log($e->getMessage());
    http_response_code(500);
   }
}
     
public function buildOrderEmail($cart, $metadata){
    $logoUrl = "https://yourdomain.com/assets/logo.png"; // replace with your logo URL

$siteName=$this->AppSettings['app']['name']??'Null';  
 $custName=$metadata['customer']['name'];
$custEmail= $metadata['customer']['email']??'N/A';
$custPhone= $metadata['customer']['phone']??'N/A';
$custAddr= $metadata['customer']['addr']??'N/A';

$orderUid=$metadata['orderUid'];
$totalAmount=(float)($metadata['amount']??0);
$currency= $metadata['currency']??'NGN';

$subject = "{$siteName} - Your Order Details - {$orderUid}";
 
// Format the date in a readable format
$date= date('l, d F Y, h:i A'); 
// Output: Tuesday, 30 March 2026, 01:31 PM

    // Start HTML email
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Order Notification</title>
        <style>
            body { font-family: Arial, sans-serif; background-color: #f9f9f9; margin: 0; padding: 0; }
            .container { width: 100%; max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 0 10px rgba(0,0,0,0.1);}
            .header { background: #4CAF50; color: white; padding: 20px; text-align: center;}
            .header img { max-height: 50px; margin-bottom: 10px; }
            .content { padding: 20px; color: #333333; line-height: 1.5; }
            .content h3 { margin-top: 0; }
            .content p { margin: 5px 0; }
            .content .metadata { background: #f1f1f1; padding: 10px; border-radius: 4px; margin-top: 10px; }
            .footer { text-align: center; padding: 15px; font-size: 12px; color: #777777; background: #f9f9f9; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <!--<img srcx="'. $logoUrl .'" alt="Company Logo">-->
                <h2>Order Details</h2>
            </div>
            <div class="content">
                
              <p>  Hi ' . $custName . ',</p>
<p>
Thank you for shopping on '. $siteName. ', your order ' . $orderUid . ' has been confirmed!
</p>
<p>
We will notify you once it is ready.
</p>
                <p><strong>Order Id:</strong> '. $orderUid.'</p>
                <p><strong>Total Amount:</strong> '. $totalAmount .' '. $currency .'</p>
                <p><strong>Status:</strong> Pending</p>
                <p><strong>Date:</strong> '. $date .'</p>

                <h4>Personal Info</h4>
                <p><strong>Email:</strong> '. $custEmail .'</p>
                <p><strong>Phone:</strong> '. $custPhone .'</p>
                
                '. (!empty($metadata) ? '<div class="metadata"><h4>Additional Info</h4>' : '');

$allowed_tags = '<br><b><div><strong><i><em><p><ul><ol><li>';

    // Append metadata dynamically
    if(!empty($cart)){	    
    
        $message .= $this->stringifyCart($cart );
    }

    $message .= '
            </div>
            <div class="footer">
                &copy; '. date("Y") .' OsHobby All rights reserved.
            </div>
        </div>
    </body>
    </html>
    ';

    return [
        'subject' => $subject,
        'message' => $message
    ];
}

public function stringifyCart($cart=[] ) {

// $line = '-------------------------------------';
    $line = '━━━━━━━━━━━━━━';

    $message = "";
    
    // Group by category
    $grouped = [];

    foreach ($cart as $item) {

        $category = $item['categories'] ?? 'Uncategorized';

        if (!isset($grouped[$category])) {
            $grouped[$category] = [];
        }

        $grouped[$category][] = $item;
    }

    $total = 0;

    // Loop categories
    foreach ($grouped as $category => $items) {

        $message .= "📦 *" . strtoupper($category) . "*<br><br>";

        foreach ($items as $index => $item) {

            $price = (float) ($item['sale_price'] ?? $item['price'] );
            $qty   = (int) ($item['qty'] ?? 0);
            $subtotal = $price * $qty;

            $message .= "- *{$item['name']}*<br>";
            $message .= "  ₦" . number_format($price) . " x {$qty}<br>";

            $message .= "  Subtotal: ₦" . number_format($subtotal) . "<br>";

            $total += $subtotal;
            $message .= "<br>";
        }

        $message .= "<br>";
    }

    // Total
    $message .= "{$line}<br>";
    $message .= "💰 *TOTAL: ₦" . number_format($total) . "*<br>";
    $message .= "{$line}";

    return $message;
}
    
public function getPage($options=[])
{
	$data=$this->input();
	$data=array_merge( $options, $data);
	
	$pageId=$data['id']??'';
	$slug=$data['slug']??'';
	
    if (empty($pageId ) && empty( $slug) ) {
        return [
            'success' => false,
            'message' => 'Page id not found'
        ];
    }

    $where  = ["site_id = ?", "status = ?"];
    $params = [$this->siteId, 'published'];

    if (!empty($pageId)) {
        $where[]  = "id = ?";
        $params[] = $pageId;
    } else {
        $where[]  = "slug = ?";
        $params[] = strtolower( $slug);
    }

    $wheres = "WHERE " . implode(' AND ', $where);

    $q = $this->db->prepare("
        SELECT id, title, slug, content, icon, description, updated_at
        FROM pages
        {$wheres}
        LIMIT 1
    ");

    $q->execute($params);
    $result = $q->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        return [
            'success' => false,
            'message' => 'Page not found'
        ];
    }

    return [
        'success' => true,
        'data' => $result,
        'message' => 'Successful'
    ];
}
     
   public function updateUserProfile()
{
	
	   $this->verifyToken();
   
    $data = $this->input();

    $userId = $this->userId ?? null;

    if (!$userId) {
        return $this->json([
            'success' => false,
            'message' => 'Unauthorized request'
        ], 401);
    }

    // Extract fields
    $full_name = trim($data['name'] ?? '');
    $email     = trim($data['email'] ?? '');
    $phone     = trim($data['phone'] ?? '');
    $state     = trim($data['state'] ?? '');
    $address   = trim($data['address'] ?? '');

    // Validation
    $errors = [];

    if ($full_name === '' || strlen($full_name) < 2) {
        $errors[] = "Full name is required and must be at least 2 characters.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if ($phone !== '' && !preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        $errors[] = "Invalid phone number format.";
    }

    if (!empty($errors)) {
        return $this->json([
            'success' => false,
            'message' => 'Validation failed',
            'errors'  => $errors
        ], 422);
    }

    // Optional: check email uniqueness (recommended)
    $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $stmt->execute([$email, $userId]);

    if ($stmt->fetch()) {
        return $this->json([
            'success' => false,
            'message' => 'Email already in use'
        ], 409);
    }

    // Update query (safe prepared statement)
    $stmt = $this->db->prepare("
        UPDATE users 
        SET name = ?, email = ?, phone = ?, state = ?, address = ?, updated_at = NOW()
        WHERE id = ?
    ");

    $result = $stmt->execute([
        $full_name,
        $email,
        $phone,
        $state,
        $address,
        $userId
    ]);

    if (!$result) {
        $this->json([
            'success' => false,
            'message' => 'Failed to update profile'
        ], 500);
    }

   $this->json([
        'success' => true,
        'message' => 'Profile updated successfully'
    ]);
}


//Password reset

public function forgotPassword() {
  $data=$this->input();
        // Validate email
        if (
            empty($data['email']) ||
            !filter_var(
                trim($data['email']),
                FILTER_VALIDATE_EMAIL
            )
        ) {

            return [
                'success' => false,
                'message' => 'Invalid email address'
            ];
        }

        $email = trim($data['email']);

        // Find developer
        $stmt = $this->db->prepare("
            SELECT id, name, email FROM users WHERE email = ? LIMIT 1
        ");

        $stmt->execute([$email]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Always return success message
        // Prevent email enumeration
        if (!$user) {

            return [
                'success' => true,
                'message' => 'If the email exists, a reset link has been sent. You may also check your email spam folder'
            ];
        }

        // Generate token
        $token = bin2hex(random_bytes(32));

        // Hash token before storing
        $tokenHash = password_hash(
            $token,
            PASSWORD_DEFAULT
        );

        // Expiry time (1 hour)
        $expiresAt = date(
            'Y-m-d H:i:s',
            strtotime('+1 hour')
        );

        // Delete old reset requests
        $stmt = $this->db->prepare("
            DELETE FROM password_resets
            WHERE user_id = ?
        ");

        $stmt->execute([
            $user['id']
        ]);

        // Insert new reset token
        $stmt = $this->db->prepare("
            INSERT INTO password_resets (
                user_id,
                token_hash,
                expires_at,
                created_at
            )
            VALUES (
                ?, ?, ?, NOW()
            )
        ");

        $stmt->execute([
            $user['id'],
            $tokenHash,
            $expiresAt
        ]);

        // Reset URL
        $resetUrl =
            $this->site_url() . '/reset-password.php?token=' .
            urlencode($token);

        // Email content
        $subject = 'Reset Your Password';

        $message = 'Hello ' . htmlspecialchars($user['name']) . ',
  
           <p> Click the link below to reset your password:</p>

            ' . $resetUrl . '
            
       <p>     This link expires in 1 hour.
            If you did not request this, ignore this email.</p>
        ';

  //SEND EMAIL HERE

        $this->queue->push('email', [
    'to' => $user["email"],
    'subject' => $subject,
    'body' => $message
]); 

        return [
            'success' => true,
            'message' => 'If the email exists, a reset link has been sent. You may also check your email spam folder',
            'redirect'=>$this->site_url() . '/login.php'
        ];
    }
    
    
//Reset Password

public function resetPassword(){

$data=$this->input();

        // Validate token
        if (
            empty($data['reset_token']) ||
            strlen($data['reset_token']) < 20
        ) {

            return [
                'success' => false,
                'message' => 'Invalid reset token'
            ];
        }

        // Validate password
        if (empty($data['password'])) {

            return [
                'success' => false,
                'message' => 'Password is required'
            ];
        }

        // Password length
        if (strlen($data['password']) < 8) {

            return [
                'success' => false,
                'message' => 'Password must be at least 8 characters'
            ];
        }

        // Confirm password
        if (
            empty($data['confirm_password']) ||
            $data['password'] !== $data['confirm_password']
        ) {

            return [
                'success' => false,
                'message' => 'Passwords do not match'
            ];
        }

        $token = trim( $data['reset_token']);

        // Fetch active reset requests
        $stmt = $this->db->prepare("
            SELECT
                id,
                user_id,
                token_hash,
                expires_at
            FROM password_resets
            WHERE expires_at > NOW()
            ORDER BY id DESC
        ");

        $stmt->execute();
 
        $resetRequest = null;

        // Verify token
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
   
            if (   password_verify( $token,  $row['token_hash'] ) ) {
                $resetRequest = $row;
                break;
            }
        }

        // Invalid token
    if (!$resetRequest) {
            return [
                'success' => false,
                'message' => 'Invalid or expired reset token'
            ];
        }

        // Hash new password
        $passwordHash = password_hash(
            $data['password'],
            PASSWORD_DEFAULT
        );

try{
	
$this->db->beginTransaction();

        // Update password
        $stmt = $this->db->prepare("
            UPDATE users
            SET
                password = ?,
                updated_at = NOW()
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([

            $passwordHash,

            $resetRequest['user_id']
        ]);

        // Delete used reset tokens
        $stmt = $this->db->prepare("
            DELETE FROM password_resets
            WHERE user_id = ?
        ");

        $stmt->execute([
            $resetRequest['user_id']
        ]);

      $this->db->commit();

        return [
            'success' => true,
            'message' => 'Password reset successful',
            'redirect'=>$this->site_url()
        ];
           
} catch (\Throwable $e) {
    	$this->db->rollBack();
        return [
        "success"=>false,
        "message"=>"Failed",
        //  "error"=>$e->getMessage()
        ];
    }
  }
  

//Verify Developer Email
public function verifyDeveloperEmail(){
		$data=$this->input();
		$uid=$data['id']??'';
		$code=$data['code']??'';
		
    try {

        if (empty($code) || empty($uid) ) {
            return [
                "success" => false,
                "message" => "Invalid verification link"
            ];
        }

        // Decode UID
        $user_id = base64_decode($uid, true);

        if (!$user_id) {
            return [
                "success" => false,
                "message" => "Invalid identifier"
            ];
        }

        // Fetch record
        $stmt = $this->db->prepare("
            SELECT id, name, email_verified
            FROM users 
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $user_id
        ]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            return [
                "success" => false,
                "message" => "Invalid or expired verification link"
            ];
        }

        // Already verified check (optional)
        if ((int)$user['email_verified'] === 1) {
            return [
                "success" => true,
                "message" => "Email already verified"
            ];
        }

 if( $code!==$user['email_verified']  ){
 	return [
                "success" => true,
                "message" => "Invalid verification link"
            ];
 }
 
  $devName=$user['name'];
 
        // Update verification
$update = $this->db->prepare("
    UPDATE users 
    SET email_verified = 1 
    WHERE id = ?
    LIMIT 1
");

$updated = $update->execute([$user_id]);

if (!$updated) {
    return [
        "success" => false,
        "message" => "Failed to verify email"
    ];
}

if ($update->rowCount() < 1) {
    return [
        "success" => false,
        "message" => "Could not verified"
    ];
}


return [
    "success" => true,
    "message" => "Email verified successfully."
];

    } catch (Exception $e) {
        return [
            "success" => false,
            "message" => "An error occured!"
        ];
    }
}

}
<?php

class CloudFlare {

     private $accountId;
    private $bucket;
    private $r2;
    private $publicUrl;

 public function __construct($accountId, $accessKey, $secretKey, $bucket, $endpoint, $publicUrl='')
    {
        require_once $this->site_dir() .'/os-third-party/aws/aws-autoloader.php';

  $this->accountId=$accountId;
  $this->bucket=$bucket;
  $this->publicUrl=$publicUrl;
  
        $this->r2 = new Aws\S3\S3Client([
            'version' => 'latest',
            'region'  => 'auto',
            'endpoint' => $endpoint,
            'use_path_style_endpoint'=>true,
            'credentials' => [
                'key' => $accessKey,
                'secret' => $secretKey
            ]
        ]);
    }
    
    public function upload($localFile, $remoteFile)
{
    try {

        $result = $this->r2->putObject([
            'Bucket'     => $this->bucket,
            'Key'        => $remoteFile,
            'SourceFile' => $localFile
        ]);

        return [
            'success' => true,
            'key'     => $remoteFile,
            'etag'    => $result['ETag'] ?? null,
            'url'     => $this->url( $remoteFile)
        ];

    } catch (Exception $e) {

        return [
            'success' => false,
            'message'   => $e->getMessage()
        ];
    }
}

 public function delete($remoteFile)
{
    try {

        $result = $this->r2->deleteObject([
            'Bucket' => $this->bucket,
            'Key'    => $remoteFile
        ]);

        return [
            'success' => true,
            'message' => 'File deleted',
            'result'  => $result->toArray()
        ];

    } catch (Exception $e) {

        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

public function url($remoteFile){
    	
     if( $this->publicUrl) {
     	return $this->publicUrl . '/' . $remoteFile;
     }
        return 'https://pub-9260dc649fb74a3a95a8aa305fb756f0.r2.dev/' . $remoteFile;
}
    
    
    
    public function site_host() {

    $host = trim($_SERVER['HTTP_HOST'] ?? '');

    // allow localhost with any port
    if (preg_match('/^localhost(:\d+)?$/i', $host)) {
        return $host;
    }

    // remove port before domain validation
    $domain = preg_replace('/:\d+$/', '', $host);

    if (filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        return $host;
    }

    exit('Invalid host value');
}


public function site_protocol(){
return	(!empty($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"] === "on")) ? "https://" : "http://";
	}
	
final public function root_dir(){
 return $_SERVER['DOCUMENT_ROOT'];	
}

public function project_folder()
{
    $documentRoot = str_replace('\\', '/', $this->root_dir());
    $dirName = str_replace('\\', '/', dirname(__DIR__) );
    $dir = str_replace($documentRoot, '', $dirName);

    return $dir === '/' ? '' : $dir;
}

public function project_dir(){
 return $this->root_dir() . $this->project_folder();
	}

public function site_dir(){
 return $this->project_dir();
	}
	
public function site_url($path="", $scheme=null){	
  $url=$this->site_protocol() .  $this->site_host() . $this->project_folder();
  
  if ( $path && is_string( $path ) ) {
		$url .= "/" . ltrim( $path, "/");
	}
	
return $url;
}

}
<?php
class GoogleOAuth
{

public $config=[];

public function __construct($options=[]){
	$default=[
    "clihent_id" => "",
 "client_secret" =>"",
 "redirect_uri" => "",
"auth_url" => "https://accounts.google.com/o/oauth2/v2/auth",
"token_url"=> "https://oauth2.googleapis.com/token",
"userinfo_url"=> "https://www.googleapis.com/oauth2/v2/userinfo"
    ];
	$this->config=array_merge($default, $options);
	}

    /**
     * Build Google authorization URL
     */
    public function getAuthUrl(string $state, array $scopes = []): string
    {
        $defaultScopes = [
            "openid",
            "email",
            "profile"
        ];

        $params = [
            "client_id"     => $this->config['client_id'],
            "redirect_uri"  => $this->config['redirect_uri'],
            "response_type" => "code",
            "scope"         => implode(" ", $scopes ?: $defaultScopes),
            "access_type"   => "online",
            "state"         => $state,
            "prompt"        => "select_account"
        ];

        return $this->config['auth_url'] . "?" . http_build_query($params);
    }

    /**
     * Exchange auth code for access token
     */
    public function fetchAccessToken(string $code): array
    {
        $payload = [
            "code"          => $code,
            "client_id"     => $this->config['client_id'],
            "client_secret" => $this->config['client_secret'],
            "redirect_uri"  => $this->config['redirect_uri'],
            "grant_type"    => "authorization_code"
        ];

        return $this->postForm($this->config['token_url'], $payload);
    }

    /**
     * Get user info from Google
     */
    public function fetchUser(string $accessToken): array
    {
        return $this->get(
            $this->config['userinfo_url'],
            [
                "Authorization: Bearer " . $accessToken
            ]
        );
    }

    /**
     * GET request via cURL
     */
    private function get(string $url, array $headers = []): array
    {
        return $this->curlRequest("GET", $url, null, $headers);
    }

    /**
     * POST form request via cURL
     */
    private function postForm(string $url, array $data): array
    {
        return $this->curlRequest("POST", $url, http_build_query($data), [
            "Content-Type: application/x-www-form-urlencoded"
        ]);
    }

    /**
     * Core cURL handler
     */
    private function curlRequest(string $method, string $url, $body = null, array $headers = []): array
    {
        $ch = curl_init($url);

        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_HTTPHEADER => $headers
        ];

        if ($method === "POST") {
            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = $body;
        }

        curl_setopt_array($ch, $options);

        $response = curl_exec($ch);
        $error = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        curl_close($ch);

        if ($response === false) {
            return [
                "success" => false,
                "error" => $error,
                "data" => null
            ];
        }

        $json = json_decode($response, true);

        return [
            "success" => $httpCode >= 200 && $httpCode < 300,
            "http_code" => $httpCode,
            "error" => json_last_error() ? json_last_error_msg() : null,
            "data" => $json ?? $response
        ];
    }
}
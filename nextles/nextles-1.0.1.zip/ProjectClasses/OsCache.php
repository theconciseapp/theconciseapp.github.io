<?php class OsCache{
	private $cacheBusy=0;
	private $cacheDir;
    private $tagDir;
    protected $db;
	
	public function __construct() {
        global $conn;
        
        $this->db = $conn;
      
  $this->cacheDir = $this->site_dir() . '/.cache/';
  $this->tagDir   = $this->cacheDir . 'tags/';
}	
	
public function site_host() {

    $host = trim($_SERVER['HTTP_HOST'] ?? '');

    // allow localhost with any port
    if (preg_match('/^localhost(:\d+)?$/i', $host)) {
        return $host;
    }

    // remove port before domain validation
    $domain = preg_replace('/:\d+$/', '', $host);

    if (filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        return $host;
    }

    exit('Invalid host value');
}


public function site_protocol(){
return	(!empty($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"] === "on")) ? "https://" : "http://";
	}
	
final public function root_dir(){
 return $_SERVER['DOCUMENT_ROOT'];	
}

public function project_folder()
{
    $documentRoot = str_replace('\\', '/', $this->root_dir());
    $dirName = str_replace('\\', '/', dirname(__DIR__) );
    $dir = str_replace($documentRoot, '', $dirName);

    return $dir === '/' ? '' : $dir;
}

public function project_dir(){
 return $this->root_dir() . $this->project_folder();
	}

public function site_dir(){
 return $this->project_dir();
	}
	
public function site_url($path="", $scheme=null){	
  $url=$this->site_protocol() .  $this->site_host() . $this->project_folder();
  
  if ( $path && is_string( $path ) ) {
		$url .= "/" . ltrim( $path, "/");
	}
	
return $url;
}

public function json($data, int $code = 200) {
        //http_response_code($code);        
        echo json_encode($data);
        exit;
    }

    public function input() {
        $body= json_decode(file_get_contents("php://input"), true) ?? [];
        
        // Merge with GET parameters
    return array_merge($_GET, $body);
    }
	
 //BEGIN CACHE

    private function resolveOptions(array $options = []) {
        return [
            'ttl'       => $options['ttl'] ?? 600,
            'namespace' => $options['namespace'] ?? 'default',
            'tags'      => $options['tags'] ?? [],
        ];
    }

    private function resolveGetOptions(array $options = []) {
        return [
            'namespace' => $options['namespace'] ?? 'default',
        ];
    }

    /* =========================
       PATH HELPERS
    ========================= */

    private function getFile($key, $namespace = 'default') {
        $dir = $this->cacheDir . $namespace . '/';

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        return $dir . md5($key) . '.cache';
    }

    private function getTagFile($tag, $namespace = 'default') {
        $dir = $this->tagDir . $namespace . '/';

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        return $dir . md5($tag) . '.tag';
    }

    private function getAllNamespaces() {
        $namespaces = [];

        if (!is_dir($this->tagDir)) return $namespaces;

        foreach (scandir($this->tagDir) as $dir) {
            if ($dir === '.' || $dir === '..') continue;

            $path = $this->tagDir . $dir;
            if (is_dir($path)) {
                $namespaces[] = $dir;
            }
        }

        return $namespaces;
    }

    /* =========================
       ATOMIC WRITE
    ========================= */

    private function atomicWrite($file, $data) {
        $dir = dirname($file);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        $tmp = tempnam($dir, 'cache_');
        if ($tmp === false) return false;

        $fp = fopen($tmp, 'wb');
        if (!$fp) {
            @unlink($tmp);
            return false;
        }

        fwrite($fp, $data);
        fflush($fp);

        if (function_exists('fsync')) {
            @fsync($fp);
        }

        fclose($fp);

        if (!rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }

        return true;
    }

    /* =========================
       CACHE METHODS
    ========================= */

    public function get($key, array $options = []) {
        $opts = $this->resolveGetOptions($options);

        $file = $this->getFile($key, $opts['namespace']);

        if (!file_exists($file)) return false;

        $content = @file_get_contents($file);
        if ($content === false) return false;

        $payload = json_decode($content, true);

        if (!is_array($payload) || !isset($payload['expires_at'], $payload['data'])) {
            @unlink($file);
            return false;
        }

        if (time() > $payload['expires_at'] && !$this->cacheBusy  ) {     	
            @unlink($file);
            return false;
        }
    
        return $payload['data'];
    }

    public function set($key, $data, array $options = []) {
        $opts = $this->resolveOptions($options);

        $file = $this->getFile($key, $opts['namespace']);

        $payload = [
            'expires_at' => time() + $opts['ttl'],
            'data'       => $data
        ];

        $this->atomicWrite($file, json_encode($payload));
        $this->cacheBusy++;

        // 🔒 Tag updates (locked)
        foreach ($opts['tags'] as $tag) {
            $tagFile = $this->getTagFile($tag, $opts['namespace']);

            $fp = fopen($tagFile, 'c+');
            if (!$fp) continue;

            flock($fp, LOCK_EX);

            $content = stream_get_contents($fp);
            $keys = $content ? json_decode($content, true) : [];

            if (!is_array($keys)) $keys = [];

            $map = array_fill_keys($keys, true);
            $map[$file] = true;

            ftruncate($fp, 0);
            rewind($fp);

            fwrite($fp, json_encode(array_keys($map)));
            fflush($fp);

            flock($fp, LOCK_UN);
            fclose($fp);
        }
    }

    public function invalidateTag($tag, array $options = []) {
        $namespace = $options['namespace'] ?? 'default';

        // 🌍 Global invalidation
        if ($namespace === '*') {
            foreach ($this->getAllNamespaces() as $ns) {
                $this->invalidateTag($tag, ['namespace' => $ns]);
            }
            return;
        }

        $tagFile = $this->getTagFile($tag, $namespace);

        if (!file_exists($tagFile)) return;

        $fp = fopen($tagFile, 'r+');
        if (!$fp) return;

        flock($fp, LOCK_EX);

        $content = stream_get_contents($fp);
        $files = $content ? json_decode($content, true) : [];

        if (is_array($files)) {
            foreach ($files as $file) {
                if (file_exists($file)) {
                    @unlink($file);
                }
            }
        }

        ftruncate($fp, 0);
        fflush($fp);

        flock($fp, LOCK_UN);
        fclose($fp);

        @unlink($tagFile);
    }

    public function clearAll() {
        // clear cache files
        foreach (glob($this->cacheDir . '*/*.cache') as $file) {
            @unlink($file);
        }

        // clear tag files
        foreach (glob($this->tagDir . '*/*.tag') as $file) {
            @unlink($file);
        }
    }
		
}
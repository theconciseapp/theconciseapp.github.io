<?php  class OsMenu{
  protected $db;
  private $cache;
  public $siteId;

public function __construct() {
        global $conn, $siteId;
        
        $this->siteId=$siteId;
        $this->cache=new OsCache();
        
        $this->db = $conn;
       }

public function site_host() {

    $host = trim($_SERVER['HTTP_HOST'] ?? '');

    // allow localhost with any port
    if (preg_match('/^localhost(:\d+)?$/i', $host)) {
        return $host;
    }

    // remove port before domain validation
    $domain = preg_replace('/:\d+$/', '', $host);

    if (filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        return $host;
    }

    exit('Invalid host value');
}

public function site_protocol(){
return	(!empty($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"] === "on")) ? "https://" : "http://";
	}
	
final public function root_dir(){
 return $_SERVER['DOCUMENT_ROOT'];	
}

public function project_folder()
{
    $documentRoot = str_replace('\\', '/', $this->root_dir());
    $dirName = str_replace('\\', '/', dirname(__DIR__) );
    $dir = str_replace($documentRoot, '', $dirName);

    return $dir === '/' ? '' : $dir;
}

public function project_dir(){
 return $this->root_dir() . $this->project_folder();
	}

public function site_dir(){
 return $this->project_dir();
	}
	
public function site_url($path="", $scheme=null){	
  $url=$this->site_protocol() .  $this->site_host() . $this->project_folder();
  
  if ( $path && is_string( $path ) ) {
		$url .= "/" . ltrim( $path, "/");
	}
	
return $url;
}


public function json($data, int $code = 200) {
        //http_response_code($code);        
        echo json_encode($data);
        exit;
    }

    public function input() {
        $body= json_decode(file_get_contents("php://input"), true) ?? [];
        
        // Merge with GET parameters
    return array_merge($_GET, $body);
    }



public function saveLocationMenus() {

$data=$this->input();
$tree=$data['tree']??[];
$menuKey=$data['menu']??'header';
$edit=$data['edit']??false;

        if (empty($tree)) {
        return ['success' => false, 'message' => 'Empty menu'];
    }

    try {
        $this->db->beginTransaction();

     if( $edit===true){
  // 🔥 delete old items for this menu (optional but recommended)
        $this->db->prepare("DELETE FROM menus WHERE menu_key=?")
                 ->execute([$menuKey]);
 }

        $this->saveMenuTree($tree, null, 0, $menuKey);

        $this->db->commit();

        // clear cache per menu
       $this->cache->invalidateTag("{$this->siteId}_menus", ['namespace'=>'menus']);

        $this->json(  ['success'=>true,'message'=>'Menu saved']);

    } catch (\Exception $e) {

        $this->db->rollBack();

        $this->json( ['success'=>false,'message'=>$e->getMessage()]);
    }
       
    }


private function saveMenuTree(array $tree, $parent = null, $depth = 0, $menuKey = 'header') {

    if ($depth > 3) return;

    $position = 0;

    foreach ($tree as $item) {
        $menu_id = $item['id'] ?? 0;
        
        if(!$menu_id) continue;
        
        $stmt = $this->db->prepare("
            INSERT INTO menus (menu_id, parent_id, position, menu_key, site_id, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ");

        $stmt->execute([
            $menu_id,
            $parent,
            $position,
            $menuKey,
            $this->siteId
        ]);

        $id = $menu_id; $this->db->lastInsertId();

        $position++;

        if (!empty($item['children'])) {
            $this->saveMenuTree($item['children'], $id, $depth + 1, $menuKey);
        }
    }
}

public function createMenu() {

    $data = $this->input();
    $tree = $data['tree'] ?? [];

    if (!is_array($tree) || empty($tree)) {
        return $this->json([
            'success' => false,
            'message' => 'Invalid structure'
        ]);
    }

    try {
        $this->db->beginTransaction();

        $stmt = $this->db->prepare("
            INSERT INTO menu (title, slug, icon, type, ref_id, site_id, admin_only, logged_only,created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");

        foreach ($tree as $item) {

            $ref_id = $item['id'] ?? null;
            $type   = $item['type'] ?? 'custom';

            $title = $item['title'] ?? 'Untitled';
            $url   = $item['url'] ?? '';
            $icon  = $item['icon'] ?? '';
            $adminOnly  = $item['adminOnly'] ?? 0;
            $loggedOnly  = $item['loggedOnly'] ?? 0;

            if ($type !== 'custom') {
                $title = null;
                $url   = null;
                $icon  = null;
            }

            $stmt->execute([
                $title,
                $url,
                $icon,
                $type,
                $ref_id,
                $this->siteId,
                $adminOnly,
                $loggedOnly
            ]);
        }

        $this->db->commit();

        return $this->json([
            'success' => true,
            'message' => 'Created successfully'
        ]);

    } catch (\Exception $e) {

        $this->db->rollBack();

        return $this->json([
            'success' => false,
            'message' => 'Failed to create menu'
        ]);
    }
}

public function updateCustomMenu() {
    $data = $this->input();

    $id    = (int)($data['id'] ?? 0);
    $title = trim($data['title'] ?? '');
    $url   = trim($data['url'] ?? '');
    $icon  = trim($data['icon'] ?? '');

    // Validate
    if ($id <= 0) {
        $this->json([
            'success' => false,
            'message' => 'Invalid menu id'
        ]);
    }

    if ($title === '') {
        $this->json([
            'success' => false,
            'message' => 'Enter menu title'
        ]);
    }

    // Optional: enforce URL only for custom type
    if ($url === '') {
         $this->json([
            'success' => false,
            'message' => 'Enter menu URL'
        ]);
    }

    // Optional: basic URL pattern (align with frontend)
    if (!preg_match('/^[a-z0-9\-\/#:?=&._]+$/i', $url)) {
        $this->json([
            'success' => false,
            'message' => 'Invalid URL format'
        ]);
    }

    // Update
    $stmt = $this->db->prepare("
        UPDATE menu 
        SET title = ?, slug = ?, icon = ? 
        WHERE id = ? AND site_id = ?
    ");

    $stmt->execute([
        $title,
        $url,
        $icon,
        $id,
        $this->siteId
    ]);

    // Check if anything was actually updated
    if ($stmt->rowCount() === 0) {
        return $this->json([
            'success' => false,
            'message' => 'Menu not found or no changes made'
        ]);
    }

    return $this->json([
        'success' => true,
        'message' => 'Updated successfully'
    ]);
}

public function listMenus(){
	    // 🔥 select only needed fields
    $stmt = $this->db->prepare("
        SELECT 
            M.id, COALESCE(NULLIF(TRIM(M.title) , ''), p.title, c.name) AS title, M.slug AS url, M.type,
            p.slug AS page_slug,
            c.slug AS category_slug
            
        FROM menu M
        LEFT JOIN pages p 
    ON M.type = 'page' AND M.ref_id = p.id
LEFT JOIN categories c 
    ON M.type = 'category' AND M.ref_id = c.id
        WHERE M.status = 1
        ORDER BY M.title ASC
    ");

    $stmt->execute();
    
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

 
  return [
     'success'=>true,
     'data'=>$rows
     ];
}
	
public function getMenu($menuKey='header', $type=''): array{

$data=$this->input();
$menuKey=$data['menu']??$menuKey;
$id=$data['id']??'';

$status=1;
  $where=$params=[];
  
  if($id ){
  	$where[]=" M.id =? ";
     $params[]=$id;
}else{
 $where[]="S.menu_key =? ";
 $params[]=$menuKey;
 }
 
 $where[]="M.status =? ";
 $params[]=$status;
 
if( !empty($type ) ) {
	$where[]="M.type =? ";
    $params[]= $type;
 }

 $where[]="M.site_id =? ";
 $params[]=$this->siteId;
 
$wheres=" WHERE " . implode( " AND ", $where);

$cacheKey = "{$this->siteId}_menu_{$menuKey}_{$type}_{$status}";

    // 🔥 safer cache check
    $menu =0;  $id?false: $this->cache->get($cacheKey, ['namespace'=>'menus']);

    if ($menu) {
   return [
'success'=>true,
'data'=> $menu];
    }

if( $id ){
	//Fetch edit data
	$stmt = $this->db->prepare("
        SELECT 
            *
        FROM menu M
        $wheres
      LIMIT 1
    ");
    
    }
    else{
$stmt = $this->db->prepare("
        SELECT 
            M.id, COALESCE(NULLIF(TRIM(M.title) ,''), p.title, c.name) AS title, M.slug AS url, M.type, COALESCE(NULLIF(TRIM(M.icon) ,''), p.icon, c.icon) AS icon , S.parent_id, S.position,
            p.slug AS page_slug,
    c.slug AS category_slug,
    c.name AS category_name    
        FROM menus S
        JOIN menu M ON S.menu_id=M.id
        LEFT JOIN pages p 
    ON M.type = 'page' AND M.ref_id = p.id
LEFT JOIN categories c 
    ON M.type = 'category' AND M.ref_id = c.id
        $wheres
        ORDER BY S.parent_id ASC, S.position ASC
    ");
   }
   
    $stmt->execute($params);
    
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 🔥 normalize types (important)
    foreach ($rows as &$row) {
        $row['id'] = (int)$row['id'];
        $row['parent_id'] = $row['parent_id'] !== null ? (int)$row['parent_id'] : null;
        $row['position'] = (int)$row['position'];
    }

    $menu = $this->buildTree($rows);

    // 🔥 cache even empty result
    $this->cache->set($cacheKey, $menu, [
        'namespace' => 'menus',
        'ttl' => 60*60*24, // optional TTL (1 day)
        'tags'=>["{$this->siteId}_menus"]
    ]);

return [
'success'=>true,
'data'=> $menu];
}

private function buildTree(array $rows): array {

    $items = [];
    $tree = [];

    foreach ($rows as $row) {
        $row['children'] = [];
        $items[$row['id']] = $row;
    }

    foreach ($items as $id => &$item) {
        if ($item['parent_id']) {
            $items[$item['parent_id']]['children'][] = &$item;
        } else {
            $tree[] = &$item;
        }
    }

    return $tree;
}

private function buildMenuUrl($item) {

    $base = rtrim($this->site_url(), '/');

    $slug = function($value, $fallback = '') {
        return !empty($value) ? trim($value, '/') : trim($fallback, '/');
    };

    switch ($item['type']) {

        case 'category':
            return $base . '/category/' . $slug($item['url'], $item['category_slug'] ?? '');

        case 'page':
            return $base . '/page/' . $slug($item['url'], $item['page_slug'] ?? '');

        default:
            // handle external links vs internal slugs
            if (!empty($item['url'])) {
                if (filter_var($item['url'], FILTER_VALIDATE_URL)) {
                    return $item['url']; // full URL
                }
                return $base . '/' . ltrim($item['url'], '/'); // internal path
            }

            return '#';
    }
}

    /* ================= HEADER (Mega / Dropdown) ================= */
  public function headerMenu(array $menu, array $opt = []) {

        $opt = array_merge([
    'layout' => 'tree',
    'container_class' => 'navbar-nav',
    'item_class' => 'nav-item',
    'link_class' => 'nav-link',
], $opt);

      return $this->renderTree($menu, $opt);
    }

    /* ================= SIDEBAR ================= */
    public function sidebarMenu(array $menu, array $opt = []) {

        $opt = array_merge([
            'container_class' => 'nav flex-column',
            'link_class' => 'nav-link',
            'link_icon'=>'<i class="fas fa-star me-1"></i>', 'layout'=>'accordion'
        ], $opt);

  return $this->renderTree($menu, $opt);
    }


    /* ================= FOOTER ================= */
    public function footerMenu(array $menu, array $opt = []) {
    	
    $opt = array_merge([
    'layout' => 'columns',
    'column_class' => 'col-6 col-md-3',
    'title_class' => 'fw-bold mb-3',
    'container_class' => 'list-unstyled',
    'item_class' => 'mb-2',
    'link_class' => 'text-white small'
], $opt);
    
    return $this->renderTree($menu, $opt);
    }

    /* ================= CORE TREE RENDER ================= */
 private function renderTree(array $items, array $options = [], int $depth = 0) {

    if (empty($items)) return '';

    $opt = array_merge([
        // layout modes: tree | columns | inline | accordion
        'layout'            => 'tree',

        // wrappers
        'container_tag'     => 'ul',
        'container_class'   => '',
        'item_tag'          => 'li',
        'item_class'        => '',
        'link_class'        => '',
        'custom_link_class'=>'',
        'link_icon'        => '',

        // footer/column support
        'column_class'      => 'col-md-3',
        'row_class'         => 'row',

        // titles
        'show_titles'       => true,
        'title_tag'         => 'h6',
        'title_class'       => '',

        // behavior
        'max_depth'         => 10,
        'accordion_parent'  => 'menuAccordion',

    ], $options);

    $html = '';

    /* ================= COLUMNS (Footer style) ================= */
    if ($opt['layout'] === 'columns' && $depth === 0) {

        $html .= '<div class="'.$opt['row_class'].'">';

        foreach ($items as $col) {

            $html .= '<div class="'.$opt['column_class'].'">';

        if( empty( $col['children'] ) ){

         $url = $this->buildMenuUrl($col);

            $html .= '<a href="'.$url.'" class="text-decoration-none  me-3 '.$opt['link_class'].' '.$opt['custom_link_class']. '">';
            $html.=(!empty($col['icon']) ? '<i class="' . $item['icon'] . ' me-2"></i>' : ($opt['link_icon'] ?? '')) . ' ';
            $html .= str_replace('&amp;', '&', htmlspecialchars( $col['title']));
            $html .= '</a>';
}

 else   if ($opt['show_titles'] && !empty($col['title'])) {
                $html .= '<'.$opt['title_tag'].' class="'.$opt['title_class'].'">'
                      . htmlspecialchars($col['title']) .
                      '</'.$opt['title_tag'].'>';
            }

            if (!empty($col['children'])) {
                $html .= $this->renderTree($col['children'], array_merge($opt, [
                    'layout' => 'tree'
                ]), $depth + 1);
            }

            $html .= '</div>';
        }

        return $html.'</div>';
    }

    /* ================= ACCORDION (Mobile) ================= */
    if ($opt['layout'] === 'accordion' && $depth === 0) {

        $html .= '<div class="accordion" id="'.$opt['accordion_parent'].'">';

        foreach ($items as $i => $item) {

            $id = $opt['accordion_parent'].'_'. rand(99,999999);
            $url = $this->buildMenuUrl($item);

            $html .= '<div class="accordion-item">';
            $html .= '<h2 class="accordion-header">';
            
            if( empty( $item['children'] ) ){
            	
            	$html .= '<a href="'.$url.'" class="accordion-button arrow-none collapsed text-decoration-none py-3 '.$opt['custom_link_class']. '">' . (!empty($item['icon']) ? '<i class="' . $item['icon'] . ' me-2"></i>' : ($opt['link_icon'] ?? '')) . ' ' . htmlspecialchars($item['title']) . '</a>';
            }else{
            $html .= '<button class="accordion-button collapsed py-3" data-bs-toggle="collapse" data-bs-target="#'.$id.'">';
        
    $html .= (!empty($item['icon']) ? '<i class="' . $item['icon'] . ' me-2"></i>' : ($opt['link_icon'] ?? '')) . ' ';
    $html .= htmlspecialchars($item['title']);
            $html .= '</button></h2>';
 }
            $html .= '<div id="'.$id.'" class="accordion-collapse collapse">';
            $html .= '<div class="accordion-body">';

            if (!empty($item['children'])) {
                $html .= $this->renderTree($item['children'], $opt, $depth + 1);
            } else {
                $html .= '<a href="'.$url.'" class="text-decoration-none  '.$opt['custom_link_class']. '">' . (!empty($item['icon']) ? '<i class="' . $item['icon'] . ' me-2"></i>' : ($opt['link_icon'] ?? '')) . ' ' . htmlspecialchars($item['title']).'</a>';
            }

            $html .= '</div></div></div>';
        }

        return $html.'</div>';
    }

    /* ================= DEFAULT TREE / INLINE ================= */

    $tag = $opt['layout'] === 'inline' ? 'div' : $opt['container_tag'];

    $html .= '<'.$tag.' class="'.$opt['container_class'].'">';

    foreach ($items as $item) {

        $url = $this->buildMenuUrl($item);

        if ($opt['layout'] === 'inline') {

            $html .= '<a href="'.$url.'" class="text-decoration-none  me-3 '.$opt['link_class'].' '.$opt['custom_link_class']. '">';
            $html.=(!empty($item['icon']) ? '<i class="' . $item['icon'] . ' me-2"></i>' : ($opt['link_icon'] ?? '')) . ' ';
            $html .= htmlspecialchars($item['title']);
            $html .= '</a>';

            continue;
        }

        $html .= '<'.$opt['item_tag'].' class="'.$opt['item_class'].'">';

        $html .= '<a href="'.$url.'" class="text-decoration-none  '.$opt['link_class'].' '.$opt['custom_link_class']. '"'
               . (!empty($item['target']) ? ' target="'.$item['target'].'"' : '') . '>';
        $html.=(!empty($item['icon']) ? '<i class="' . $item['icon'] . ' me-2"></i>' : ($opt['link_icon'] ?? '')) . ' ';
        $html .= htmlspecialchars($item['title']);
        $html .= '</a>';

        if (!empty($item['children']) && $depth < $opt['max_depth']) {
            $html .= $this->renderTree($item['children'], $opt, $depth + 1);
        }

        $html .= '</'.$opt['item_tag'].'>';
    }

    return $html.'</'.$tag.'>';
}
  
public function deleteMenu() {
    $data = $this->input();
    $id = (int)($data['id'] ?? 0);

    if ($id <= 0) {
        return $this->json([
            'success' => false,
            'message' => 'Invalid Menu ID'
        ], 422);
    }

    try {
        $this->db->beginTransaction();

        // 1. Delete menu-location mappings (optional relationships)
        $stmt = $this->db->prepare(
            "DELETE FROM menus WHERE menu_id = ? AND site_id = ?"
        );
        $stmt->execute([$id, $this->siteId]);
        // ⚠️ Do NOT check rowCount here — it's optional data

        // 2. Delete the actual menu (source of truth)
        $stmt = $this->db->prepare(
            "DELETE FROM menu WHERE id = ? AND site_id = ?"
        );
        $stmt->execute([$id, $this->siteId]);

        // 3. Validate deletion actually happened
        if ($stmt->rowCount() === 0) {
            $this->db->rollBack();

            return $this->json([
                'success' => false,
                'message' => 'Menu not found or already deleted'
            ], 404);
        }

        $this->db->commit();

        // 4. Invalidate cache AFTER commit
        $tag = "{$this->siteId}_menus";
        $this->cache->invalidateTag($tag, ['namespace' => 'menus']);

        return $this->json([
            'success' => true,
            'message' => 'Menu deleted successfully'
        ]);

    } catch (Throwable $e) {

        if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }

        // Log internally (never expose raw DB errors to client)
        error_log($e->getMessage());

        return $this->json([
            'success' => false,
            'message' => 'Please try again'
        ], 500);
    }
  }
}
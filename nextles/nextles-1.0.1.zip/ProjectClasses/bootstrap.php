<?php 
define('APP_VERSION', '1.0.0');
define('ENV_DIR', __DIR__ . '/../../.env');

function loadEnv($path)
{
    if (!file_exists($path)) {
        return false;
    }

    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {

        $line = trim($line);

        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        if (!str_contains($line, '=')) {
            continue;
        }

        [$key, $value] = explode('=', $line, 2);

        $key = trim($key);
        $value = trim($value, " \t\n\r\0\x0B\"'");

        $_ENV[$key] = $value;
        $_SERVER[$key] = $value;

        putenv("$key=$value");
    }

    return true;
}
	
loadEnv( ENV_DIR . '/.env');

if ( !file_exists(__DIR__ . '/../api/config/config.php') && !file_exists( ENV_DIR . '/ecommerce.config.php') ) {
	header('Location: setup');
	exit;
	}

require_once __DIR__ . '/../os-third-party/PHPMailer/emailer.php';

if( file_exists( ENV_DIR . '/ecommerce.config.php') ){
	
require_once ENV_DIR. '/ecommerce.config.php';

}else{
	
	require_once( __DIR__ . '/../api/config/config.php');
	}
	
require_once __DIR__ . '/../OsQueue/OsQueue.php';

require_once 'CloudFlare.php';
require_once 'OsCache.php';
require_once 'OsMenu.php';
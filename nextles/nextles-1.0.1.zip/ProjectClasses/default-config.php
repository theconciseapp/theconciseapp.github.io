<?php

// you can compute dynamic values here
$baseUrl = $this->site_url(); // change per environment
$siteUnique = "site_"; // or derive from site_id

return [

  "app" => [
    "name" => "Os Shop",
    "title"=> "Os Shop",
    "description"=>"Discover a smarter way to shop. From trending products to everyday essentials, we connect you with what you love—quickly, securely, and effortlessly. Shopping just got better.",
    "logo" => "https://dummyimage.com/500x500/444/fff&text=Os",
    "version" => "1.0.0",
    "environment" => "production", // development | staging | production
  ],

"media"=> [
    "storage"=>"local"
    ],
    
  "payment" => [
    "provider" => "paystack",
    "publicKey" => "1234567890",
    "enablePod" => true,
  ],

  "contact" => [
    "phone" => "+2349064732951",
    "whatsapp" => "2349064732951",
    "email" => "shop-support@gmail.com",
    "address" => "Oke-ilewo, Abeokuta, Ogun, Nigeria",
    "map" => "oke-ilewo abeokuta lafenwa ogun nigeria",
  ],

  "business_days" => [
    "open" => "Mon – Sat: 9:00 AM – 6:00 PM",
    "close" => "Sunday: Closed"
  ],

  "api" => [
    "baseUrl" => $baseUrl,
    "timeout" => 10000,
  ],

  "currency" => [
    "code" => "NGN",
    "symbol" => "₦",
    "locale" => "en-NG",
  ],

"orders" => [
    "maxOrderItems"       => 10,
    "maxOrderPendingDays" => 7,
],
  
  "shipping" => [
    "flatRate" => 0,
    "freeShippingThreshold" => 0,
    "maxDate" => 3,
  ],

  "features" => [
    "enableCoupons" => true,
    "enableWishlist" => true,
    "enableReviews" => false,
  ],

  "storageKeys" => [
    "cart" => $siteUnique . "mystore_cart",
    "user" => $siteUnique . "mystore_user",
  ],
  
  "google"=> ['client'=>'', 'secret'=>'', 'redirect'=> '' ],
  "cloudflare"=>[
    "account_id"=>'',
    "access_key"=>'',
    "secret_key"=>'',
    "bucket"=>'',
    "endpoint"=>'',
    "public_url"=>'',   
    ],
    "dropbox"=>[
    "app_key"=>'',
    "access_token"=>'',
    "app_secret"=>'',
    "refresh_token"=>'',
    "folder"=>'',
    ],
  "email"=> []

];
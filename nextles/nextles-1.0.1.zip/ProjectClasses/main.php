<?php 
class ProjectAPI {
	public $siteName='Os Shop';
	private $cacheBusy=0;
	private $cacheDir;
    private $tagDir;
    public $cache;
    public $menu;
    public $queue;
	public $slugRoute='p';
	public $segments=array();
    private $enableStockCentral=true;
    protected $db;
    public $userId;
    public $siteId='abcde';
    public $username;
    public $userRole;
    public $userIp;
    private $company=array();
   
    private $sizes = [
        "large"  => 1200,
        "medium" => 600,
        "thumb"  => 300
    ];
    private $imgQuality = 75;
    public $AppSettings=array();
        
 public $cookieName='offense_cookie_Ayj63';
 
    public function __construct($pdo='') {
        global $conn;
        
        $this->menu=new OsMenu();
        $this->cache=new OsCache();
        $this->queue=new OsQueue();
        
      $this->userIp=$this->getUserIP();
    	if( $this->isLocalhost() ){
    	error_reporting(E_ALL);
    }
        $this->db = $conn;
        
      $page = $_GET['page'] ?? '';

$this->segments = array_values(array_filter(explode('/', $page)));

$this->AppSettings=$this->settings();
$this->siteName=htmlspecialchars($this->AppSettings['app']['name']);

}
   
  
public function isLocalhost() {
    $localHosts = ['127.0.0.1', '::1', 'localhost'];
    
    return in_array($_SERVER['REMOTE_ADDR'], $localHosts) ||
           in_array($_SERVER['SERVER_ADDR'], $localHosts);
}

public function getHeader($name=''){
  if(empty( $name) ){
  	//Login Token header
	  if( $this->isLocalhost()){
      $name= 'X-Auth-Token';
} else{
	$name= 'Authorization';
   }
}

$data=$this->input();
  
   if( !empty( $data['token'] )){
   	return htmlspecialchars($data['token'] );
   }

    $headers= getallheaders();
    if( isset($headers[$name])){
        return $headers[$name];
}
    
    $serverKey='HTTP_' . strtoupper(str_replace('-', '_', $name));
    
    return $_SERVER[$serverKey]?? null;
}

public function site_host() {

    $host = trim($_SERVER['HTTP_HOST'] ?? '');

    // allow localhost with any port
    if (preg_match('/^localhost(:\d+)?$/i', $host)) {
        return $host;
    }

    // remove port before domain validation
    $domain = preg_replace('/:\d+$/', '', $host);

    if (filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
        return $host;
    }

    exit('Invalid host value');
}


public function site_protocol(){
return	(!empty($_SERVER["HTTPS"]) && strtolower($_SERVER["HTTPS"] === "on")) ? "https://" : "http://";
	}
	
final public function root_dir(){
 return $_SERVER['DOCUMENT_ROOT'];	
}

public function project_folder()
{
    $documentRoot = str_replace('\\', '/', $this->root_dir());
    $dirName = str_replace('\\', '/', dirname(__DIR__) );
    $dir = str_replace($documentRoot, '', $dirName);

    return $dir === '/' ? '' : $dir;
}

public function project_dir(){
 return $this->root_dir() . $this->project_folder();
	}

public function site_dir(){
 return $this->project_dir();
	}
	
public function site_url($path="", $scheme=null){	
  $url=$this->site_protocol() .  $this->site_host() . $this->project_folder();
  
  if ( $path && is_string( $path ) ) {
		$url .= "/" . ltrim( $path, "/");
	}
	
return $url;
}

 public function siteUrl(){

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";//dev.-OS
$host=$_SERVER['HTTP_HOST'];
$basePath=trim( dirname($_SERVER['SCRIPT_NAME']), '/');

return "{$protocol}{$host}" . ($basePath?"/$basePath":"");
	}
	

/* ================================
       HELPERS
    ================================= */
    
   public function assets($type="css", $file="styles.css"){
   return $this->site_url() . "/assets/$type/$file?i=" . time();	
   }
   
    public function json($data, int $code = 200) {
        //http_response_code($code);        
        echo json_encode($data);
        exit;
    }

    public function input() {
        $body= json_decode(file_get_contents("php://input"), true) ?? [];
        
        // Merge with GET parameters
    return array_merge($_GET, $body);
    }


public function
 settings(){
 	
    $key = "{$this->siteId}_site_settings";

    $data = $this->cache->get($key, ['namespace'=>'site_settings'] );

    if ($data !== false) {
      return $data;
  }

$defaultConfig = require "default-config.php";

    $stmt = $this->db->prepare("SELECT settings FROM settings WHERE site_id=? LIMIT 1");
    $stmt->execute( [$this->siteId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $dbConfig = $row ? json_decode($row['settings'], true) : [];

 $data=array_replace_recursive($defaultConfig, $dbConfig);
    
    $this->cache->set($key, $data, ['namespace'=>'site_settings', 'tags'=>[$key], 'ttl'=>60*60*12 ]);
    
    return $data;
}

public function returnSafeSettings($settings)
{
    if (!$this->admin()) {
        unset($settings['email'], $settings['google']);
    }

    return $settings;
}

public function saveSettings($data = []) {

if (!$this->admin()) {
        $this->json([
            "success" => false,
            "message" => "Unauthorised"
        ]);
    }

    $siteId = $this->siteId;

    // validate minimal structure
    if (!isset($data['app']['name'])) {
        return $this->json([
            "success" => false,
            "message" => "Invalid config"
        ]);
    }

    // safe JSON encoding
    $json = json_encode($data);
    if ($json === false) {
        return $this->json([
            "success" => false,
            "message" => "Failed to encode settings"
        ]);
    }

    try {
        $stmt = $this->db->prepare("
            INSERT INTO settings (site_id, settings)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE settings = VALUES(settings)
        ");

        $stmt->execute([$siteId, $json]);

    } catch (Exception $e) {
        return $this->json([
            "success" => false,
            "message" => "Database error"
        ]);
    }

    // 🔥 precise invalidation (per site)
    $this->cache->invalidateTag("{$this->siteId}_site_settings", ['namespace'=>'site_settings'] );

    return $this->json([
        "success" => true
    ]);
}

public function getMenu($menuKey='header', $type=''){
	return $this->menu->getMenu($menuKey, $type);
}

public function headerMenu(array $menu, array $opt = []) {
	return $this->menu->headerMenu($menu, $opt);
	}

public function sidebarMenu(array $menu, array $opt = []) {
	return $this->menu->sidebarMenu($menu, $opt);
	}
	
public function footerMenu(array $menu, array $opt = []) {
	return $this->menu->footerMenu($menu, $opt);
	}
	
public function saveLocationMenus() {
	$this->menu->saveLocationMenus();
	}

public function createMenu() {
$this->menu->createMenu();
}	

public function updateCustomMenu() {
	$this->menu->updateCustomMenu();
	}
	
public function listMenus(){
  return $this->menu->listMenus();
}
	
public function deleteMenu(){
	return $this->menu->deleteMenu();
}
 
public function verifyToken($cookieToken = '', $return = false) {

    // 1️⃣ Get token
    $token = $this->getHeader();

    if (!empty($cookieToken)) {
        $token = $cookieToken;
    }

    if (!$token) {
        $response = [
            'success' => false,
            'message' => 'Missing token',
            'loginRequired' => true
        ];

        return $this->respondAuth($response, 401, $return);
    }

    // 2️⃣ Normalize early (IMPORTANT)
    $token = str_ireplace('Bearer ', '', $token);

$key = "auth_token_" . md5($token);

  $cache=$this->cache->get($key, ['namespace'=>'logins'] );
  
  $user=$cache;
  
  if( !$user) {
    // 3️⃣ Lookup user
    $q = $this->db->prepare("
        SELECT id, name, email, phone, address, state, role, username, avatar, token_expiry
        FROM users
        WHERE login_token = ?
        LIMIT 1
    ");

    $q->execute([$token]);
    $user = $q->fetch(PDO::FETCH_ASSOC);
}

    if (!$user) {
        $response = [
            'success' => false,
            'message' => 'Invalid token',
            'loginRequired' => true
        ];
  
   return $this->respondAuth($response, 401, $return);
    }

    // 4️⃣ Expiry check
    if (strtotime($user['token_expiry']) < time()) {
        $response = [
            'success' => false,
            'message' => 'Token expired',
            'loginRequired' => true
        ];

        return $this->respondAuth($response, 401, $return);
    }

 if(!$cache) {
   $this->cache->set($key, $user, ['namespace'=>'logins', 'tags'=>[$key], 'ttl'=>60*15 ]);
  }
    
    // 5️⃣ Set session context
    $this->username = $user['username'];
    $this->userId   = $user['id'];
    $this->userRole  = $user['role'];

    // 6️⃣ Success response
    $user['success'] = true;
    return $user;
}

private function respondAuth($response, $code, $return) {
    if ($return) return $response;

    $this->json($response, $code);
    exit;
}

public function admin(){	
	return $this->userRole=='administrator';
	}
	
public function manager(){
	return $this->userRole=='manager';
	}
public function canManage(){
	return $this->admin()||$this->manager();
	}
	
    /* ================================
       AUTH  ================================= */
 public function loginUser() {
    $d = $this->input();

    if (empty($d['login']) || empty($d['password'])) {
        $this->json(['success'=>false, 'message' => 'Email/Username and password are required'], 400);
    }

    $login = trim($d['login']);
    $password = $d['password'];

/* ================================
       FETCH USER BY EMAIL OR USERNAME
    ================================= */
    $q = $this->db->prepare(
        "SELECT id, role, name, username,  email, password, phone, address, state, avatar, status
         FROM users
         WHERE (username = ? OR email = ?)
         LIMIT 1"
    );
    
    $q->execute([$login, $login]);
    
    $user = $q->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $this->json(['success'=>false, 'message' => 'Invalid email/username or password'], 401);
    }

    if ((int)$user['status'] !== 1) {
        $this->json(['success'=>false, 'message' => 'Account is disabled'], 403);
    }

    /* ================================
       VERIFY PASSWORD
    ================================= */
    if (!password_verify($password, $user['password'])) {
        $this->json(['success'=>false, 'message' => 'Invalid username or password'], 401);
    }

    /* ================================
       GENERATE SECURE LOGIN TOKEN
       Expires in 24 hours
    ================================= */
    $token = bin2hex(random_bytes(32)); // 64-char secure token
    $expire_timeStamp=strtotime('+12 days');
    $expiry = date('Y-m-d H:i:s', $expire_timeStamp );

    $update = $this->db->prepare(
        "UPDATE users SET login_token = ?, token_expiry = ? WHERE id = ?"
    );
    $update->execute([$token, $expiry, $user['id']]);


    setcookie($this->cookieName, $token, [
    'expires' => $expire_timeStamp, // 1 hour
    'path' => '/',
   // 'secure' => true, // HTTPS only
    'httponly' => true, // prevent JavaScript access
]);

  unset( $user['password']);

    $this->json([
        'success' => true,
        'message'=>'Logged In',
        'user' => $user,
        'token' => $token,
        'token_expiry' => $expiry
    ]);
}


public function googleSignIn($googleId, $email, $name, $avatar=''){
	
	// Check if user exists
$stmt = $this->db->prepare("SELECT id, email, name, address, avatar, role FROM users WHERE google_id = ? OR email = ?");
$stmt->execute([$googleId, $email]);

$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existing) {
    $user_id = $existing['id'];
} else {
    // Create new user
    $stmt = $this->db->prepare("
        INSERT INTO users (email, name, google_id, avatar)
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$email, $name, $googleId, $avatar]);
    
    $user_id = $this->db->lastInsertId();
    
    $existing=[
      'id'=> $user_id,
      'email'=>$email,
      'name'=>$name,
      'role'=>'user',
      'avatar'=>$avatar
      ];
}

/* ================================
       GENERATE SECURE LOGIN TOKEN
       Expires in 24 hours
    ================================= */
    $token = bin2hex(random_bytes(32)); // 64-char secure token
    $expire_timeStamp=strtotime('+12 days');
    $expiry = date('Y-m-d H:i:s', $expire_timeStamp );

    $update = $this->db->prepare(
        "UPDATE users SET login_token = ?, token_expiry = ? WHERE id = ?"
    );
    $update->execute([$token, $expiry, $user_id]);

setcookie($this->cookieName, $token, [
    'expires' => $expire_timeStamp, // 1 hour
    'path' => '/',
   // 'secure' => true, // HTTPS only
    'httponly' => true, // prevent JavaScript access
]);

    return [
        'success' => true,
        'user' => $existing,
        'token' => $token,
        'token_expiry' => $expiry
    ];
}
	
public function logoutUser(){
	$this->verifyToken(null, true);
	
	$userId=$this->userId;
	
	$prevToken=$_GET['token']??'';
   setcookie($this->cookieName, $prevToken, [
    'expires' => time()-3600,
    'path' => '/',
   // 'secure' => true, // HTTPS only
    'httponly' => true, // prevent JavaScript access
]);
   
   $key = "auth_token_" . md5($prevToken);

   $this->cache->invalidateTag($key, ['namespace'=>'logins']);

if( empty( $prevToken) || empty( $userId) ){
   $this->json(['success'=>true, 'message' => 'Successful'], 401);
}	
	
$update = $this->db->prepare(
        "UPDATE users SET login_token = ?, token_expiry = ? WHERE id = ?"
    );
    $token='';
    $expiry=date('Y-m-d H:i:s', strtotime('-2 hours'));
    
    $update->execute([$token, $expiry, $userId]);
    
    $this->json(['success'=>true, 'message' => 'Successful'], 401); 
}


public function generateInvoiceNo($branch_id)
{
    $today = date("Ymd-His");

    // Count today's sales for this branch
    $sql = "SELECT COUNT(id) as total
            FROM sales
            WHERE branch_id = ?
            AND DATE(created_at) = CURDATE()";

    $stmt = $this->db->prepare($sql);
    $stmt->execute([$branch_id]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $nextNumber = $row['total'] + 1;

    // Pad with zeros
    $sequence = str_pad($nextNumber, 5, "0", STR_PAD_LEFT);

    return "INV-" . $today . "-" . $branch_id . "-" . $sequence;
}

public function loadDashboard(){
	$results=['success'=>true];
	
	$results['settings']=$this->returnSafeSettings($this->AppSettings);
    $results['userId']=$this->userId;
    $results['userRole']=$this->userRole;	
//	$results['companyInfo']=$this->company;
    //$results['products']=$this->products();
    $results['orders']=$this->getOrders();
    $results['categories']=$this->listCategories();
    $results['menus']=$this->menu->listMenus();
    $results['pages']=$this->listPages();
    
    $this->updatePopularity(); //Self cron
    
   exit( json_encode( $results));
}


public function listCategories(){
$q = $this->db->prepare("SELECT 
    c.id,
    c.name,
    c.slug,
    c.parent_id,
    c.description,
    c.icon,
    p.name AS parent_name
FROM categories c
LEFT JOIN categories p ON c.parent_id = p.id WHERE c.site_id=? AND c.status=1
ORDER BY c.name");

$q->execute([$this->siteId]);
return $q->fetchAll(PDO::FETCH_ASSOC);
	}


//CREATE CATEGORY

public function createCategory() {
    // 🔐 Verify login token

    // 📥 Get JSON input
    $data = $this->input();

    // 🧹 Sanitize
    $name    = trim($data['name'] ?? '');
    $slug    = trim($data['slug'] ?? '');
    $parent_id    = intval($data['parent_id'] ?? '');
    $description    = trim(strip_tags($data['description'] ?? ''));
    $shortDesc    = trim(strip_tags($data['short_description'] ?? ''));
    $icon    = trim($data['icon'] ?? '');

    // ❌ Required field checks
    if ($name === '') {
        $this->json(['success'=>false, 'message' => 'Category name required'], 422);
    }

    // ❌ Length validation
    if (mb_strlen($description) < 1) {
        $this->json(['success'=>false, 'message' => 'Description too short'], 422);
    }

if( empty( $shortDesc)) {
	$shortDesc=$description;
}

$shortDesc=mb_substr($shortDesc,  0, 255);

 $slug= bin2hex(random_bytes(8)); // 16-char secure token
    // ✅ Insert branch
    $stmt = $this->db->prepare(
        "INSERT INTO categories (name, slug,parent_id, description, short_desc, icon, created_at)
         VALUES (?, ?, ?, ?, ?, ?, NOW())"
    );

    $stmt->execute([$name, $slug, $parent_id, $description, $icon]);

    // 🎉 Success response
    $this->json([
        'success' => true,
        'message' => 'Category created successfully',
        'category'=>(object)[
        'name'=>$name,
        'slug'=>$slug,
        'parent_id'=>$parent_id,
        'description'=>$description,
        'short_desc'=>$shortDesc,
        'id' => (int)$this->db->lastInsertId()
        ]
    ], 201);
}


//EDIT Category
public function editCategory() {
   // 🔒 Role check
   
    // 📥 Read input
    $data = $this->input();
    // 🧹 Sanitize input
    $id      = (int)($data['id'] ?? 0);
        
    $name    = trim($data['name'] ?? '');
    $slug    = trim($data['slug'] ?? '');
    $parent_id    = intval($data['parent_id'] ?? '');
    $description   = trim($data['description'] ?? '');
    $icon    = trim($data['icon'] ?? '');
    
    // ❌ Validate ID
    if ($id <= 0) {
        $this->json(['success'=>false, 'message'  => 'Invalid category ID'], 422);
    }
    
    if ($id ==$parent_id) {
        $this->json(['success'=>false, 'message'  => 'Sorry you cannot make category parent of itself'], 422);
    }

    // ❌ Required fields
    if ($name === '' ) {
        $this->json([ 'success'=>false, 'message' => 'Category name required'], 422);
    }

    // ❌ Length checks
    if (strlen($name) < 3) {
        $this->json([ 'success'=>false, 'message' => 'Category name must be at least 3 characters'], 422);
    }

    // 🔍 Check category exists
    $exists = $this->db->prepare(
        "SELECT id FROM categories WHERE id = ? AND site_id=? LIMIT 1"
    );
    $exists->execute([$id, $this->siteId]);

    if (!$exists->fetch()) {
        $this->json(['success'=>false, 'message'  => 'Category not found'], 404);
    }

    // ✅ Update branch
    $stmt = $this->db->prepare(
        "UPDATE categories
         SET name = ?, slug=?, parent_id=?, description = ?, icon= ?
         WHERE id = ? AND site_id=?"
    );

    $stmt->execute([$name, $slug, $parent_id,  $description, $icon, $id, $this->siteId]);

    // 🎉 Success response
    $this->json([
        'success' => true,
        'message' => 'Category updated successfully',
        'category'=>(object)[
        'user_id'=>$this->userId,
        'name'=>$name,
        'slug'=>$slug,
        'parent_id'=>$parent_id,
        'description'=>$description,
        'icon'=>$icon,
        'id' => $id
        ]
    ]);
}

public function deleteCategory() {

    // 📥 Read input
    $data = $this->input();
    $id = (int)($_GET['id'] ?? 0);

    // ❌ Validate ID
    if ($id <= 0) {
        $this->json(['success'=>false, 'message'  => 'Invalid category ID'], 422);
    }

if( $id==1) {
	$this->json([
            'success'=>false, 'message'  => 'Uncategorised cannot be deleted'
        ], 409);
	}
    // 🔍 Check category exists & not deleted
    $cat = $this->db->prepare(
        "SELECT id FROM categories WHERE id = ? AND status = 1 LIMIT 1"
    );
    $cat->execute([$id]);

    if (!$cat->fetch()) {
        $this->json(['success'=>false, 'message' => 'Category not found or already deleted'], 404);
    }

    // 🔍 Set products category to 1
    
    $prod = $this->db->prepare(
        "UPDATE products SET category_id = 1 WHERE category_id=? AND user_id=?"
    );
        
    $prod->execute([$id, $this->userId]);

    // ✅ Soft delete
    $stmt = $this->db->prepare(
        "UPDATE categories SET status = 0 WHERE id = ? AND user_id=?"
    );
    $stmt->execute([$id, $this->userId]);

    $this->json([
        'success' => true,
        'message' => 'Category deleted successfully'
    ]);
}

//SITE PAGES

public function listPages($status='') {

    $data   = $this->input();
  if( empty($status)  ){
     $status = $data['status'] ?? '';
}
    $id     = isset($data['id']) ? (int)$data['id'] : null;

    $where  = [" site_id=? "];
    $params = [$this->siteId];

    // 🔹 Base SELECT
    $sql = "SELECT id, title, slug, status, created_at, updated_at";
  
    // 🔹 If single page, include full fields
    if ($id) {
        $sql .= ", content, description";
        $where[] = "id = ?";
        $params[] = $id;
    }

    $sql .= " FROM pages";

    // ?? Status filter (whitelist)
    if ($status !== '') {
        $allowedStatus = ['published', 'draft', 'archived','deleted'];
        if (!in_array($status, $allowedStatus, true)) {
        	return [
                'success' => false,
                'message' => 'Invalid status'
            ];
     }
            $where[] = "status = ?";
            $params[] = $status;
     
    }

    // 🔹 WHERE clause
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }

    // 🔹 Order
    $sql .= " ORDER BY title ASC";

    // 🔹 LIMIT (important for production)
    
    
        $limit  = isset($data['limit']) ? (int)$data['limit'] : 20;
        $offset = isset($data['offset']) ? (int)$data['offset'] : 0;

        // hard cap to prevent abuse
        $limit = min($limit, 100);

if (!$id) {
        $sql .= "  LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
    }

$cacheKey="{$this->siteId}_pages_{$status}_{$id}_{$limit}_{$offset}";

$rows=$this->cache->get($cacheKey, ['namespace'=>'pages'] );

if( !$rows) {
    // 🔹 Execute
    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);

    // 🔹 Return single or list
    if ($id) {    	
        $rows= $stmt->fetch(PDO::FETCH_ASSOC);
    }
else{
    $rows= $stmt->fetchAll(PDO::FETCH_ASSOC);    
    }
 
 $tag="{$this->siteId}_pages";
 
   $this->cache->set($cacheKey, $rows, ['namespace'=>'pages', 'tags'=>[$tag], 'ttl'=>60*60*24] );
}   
    
    return [ 'success'=>true,
    'data'=>$rows
    ];
}
	
	//CREATE / EDIT PAGE
	
public function savePage() {
    try {

        $data = $this->input();

        // 🔹 Inputs
        $id      = isset($data['id']) ? (int)$data['id'] : null;
        $title   = trim($data['title'] ?? '');
        $slugIn  = trim($data['slug'] ?? '');
        $content = $data['content'] ?? '';
        $description = $data['description'] ?? '';
        $status  = $data['status'] ?? 'draft';

        // 🔹 Validate
        if ($title === '') {
            return $this->json([
                'success' => false,
                'message' => 'Title is required'
            ]);
        }

        $title = strip_tags($title);

        // 🔹 STATUS whitelist
        $allowedStatus = ['published', 'draft', 'archived'];
        if (!in_array($status, $allowedStatus, true)) {
            $status = 'draft';
        }

        // =========================================================
        // 🔥 SLUG GENERATION + AUTO-INCREMENT (CORE LOGIC)
        // =========================================================

        // Step 1: choose raw source
        $rawSlug = $slugIn !== '' ? $slugIn : $title;

        // Step 2: normalize
        $baseSlug = strtolower($rawSlug);
        $baseSlug = preg_replace('/[^a-z0-9-]+/', '-', $baseSlug);
        $baseSlug = trim($baseSlug, '-');

        // Step 3: fallback
        if ($baseSlug === '') {
            $baseSlug = 'page';
        }

        // Step 4: fetch slugs once
        if ($id) {
            $stmt = $this->db->prepare("
                SELECT slug FROM pages 
                WHERE slug LIKE ? AND id != ?
            ");
            $stmt->execute([$baseSlug . '%', $id]);
        } else {
            $stmt = $this->db->prepare("
                SELECT slug FROM pages 
                WHERE slug LIKE ?
            ");
            $stmt->execute([$baseSlug . '%']);
        }

        $existingSlugs = $stmt->fetchAll(PDO::FETCH_COLUMN);

        // Step 5: compute final slug
        if (!in_array($baseSlug, $existingSlugs, true)) {
            $slug = $baseSlug;
        } else {
            $i = 2;
            do {
                $candidate = $baseSlug . '-' . $i;
                $i++;
            } while (in_array($candidate, $existingSlugs, true));

            $slug = $candidate;
        }

        // =========================================================
        // 🔹 META FALLBACKS
        // =========================================================

        if ($description === '') {
            $plain = trim(strip_tags($content));
            $description = mb_substr($plain, 0, 160);
        }

        // 🔹 META sanitize + enforce SEO limits
        $description = htmlspecialchars($description, ENT_QUOTES, 'UTF-8');

        $description = mb_substr($description, 0, 160);

        // =========================================================
        // 🔹 DB WRITE
        // =========================================================

  $tag="{$this->siteId}_pages";

        if ($id) {

            $stmt = $this->db->prepare("
                UPDATE pages
                SET title = ?, slug = ?, content = ?, status = ?, description = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $title,
                $slug,
                $content,
                $status,
                $description,
                $id
            ]);

$this->cache->invalidateTag($tag, ['namespace'=>'pages'] );


            return $this->json([
                'success' => true,
                'message' => 'Page updated',
                'slug' => $slug,
                'id'=>$id
            ]);

        } else {

            $stmt = $this->db->prepare("
                INSERT INTO pages (site_id, title, slug, content, status, description)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
              $this->siteId,
                $title,
                $slug,
                $content,
                $status,
                $description
            ]);


$this->cache->invalidateTag($tag, ['namespace'=>'pages'] );

            return $this->json([
                'success' => true,
                'message' => 'Page created',
                'slug' => $slug,
                'id'=>$this->db->lastInsertId()
            ]);
        }

    } catch (\Throwable $e) {
    error_log($e->getMessage());
        // 🔹 Do NOT leak internals
        return $this->json([
            'success' => false,
            'message' => 'Something went wrong'
        ]);
    }
}
	
	
	public function deletePage() {

    // 📥 Read input
    $data = $this->input();
    $id = (int)($data['id'] ?? 0);
    $status = $data['status'] ??'';

    // ❌ Validate ID
    if ($id <= 0) {
        $this->json(['success'=>false, 'message'  => 'Invalid Page ID'], 422);
    }

  
    // ✅ Soft delete
   if( $status=='deleted'){
 
   	$stmt = $this->db->prepare(
        "DELETE FROM pages WHERE id = ? AND site_id=?"
    );
   }else{
    $stmt = $this->db->prepare(
        "UPDATE pages SET status = 'deleted' WHERE id = ? AND site_id=?"
    );
   }
    $stmt->execute([$id, $this->siteId]);

$tag="{$this->siteId}_pages";

$this->cache->invalidateTag($tag, ['namespace'=>'pages'] );

    $this->json([
        'success' => true,
        'message' => 'Page deleted successfully'
    ]);
}

//PRODUCT LIST
public function products(){
  
   $id = intval($_GET['id']??0);
    $page  =  intval($_GET['p']??1);
    $limit = intval($_GET['limit']??20);
    
    
    $search = trim($_GET['s'] ?? '');
    $categoryId=intval($_GET['category']??'');

    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;

        $wheres[] = " p.site_id= ?";
        $params[] = $this->siteId;

      if( !$id){
   $wheres = [ "p.status=? "];
         $params = [ "active" ];
         }
    
     if($id){
        $wheres[] = " p.id= ?";
        $params[] = $id;
    }

    // 🔎 search by product name
    if(!$id && $search != ""){
        $wheres[] = " p.name LIKE ?";
        $params[] = "%$search%";
    }

    // 🔎 search by category id
    if( !$id && !empty( $categoryId ) ){
        $wheres[] = " pcat.category_id =?";
        $params[] = $categoryId;
    }

  $where="";
  
if( !empty($wheres) ){
	$where=" WHERE " . implode(" AND " , $wheres);
	}

    $limitInc=$limit+1;

$select  = [];
$join    = [];
$selects = '';
$joins   = '';

/* -------------------------
   DYNAMIC PRODUCT DETAILS
--------------------------*/
if ($id||$categoryId) {

    // Product description
    $select[] = "p.description, p.full_description ";

    // Categories
    $select[] = "GROUP_CONCAT(DISTINCT c.name ORDER BY c.name SEPARATOR ', ') AS categories";
    $select[] = "GROUP_CONCAT(DISTINCT c.id ORDER BY c.id SEPARATOR ',') AS category_ids";
 //   $select[] = "GROUP_CONCAT(DISTINCT pc.name ORDER BY pc.name SEPARATOR ', ') AS parent_categories";

    // Joins
    $join[] = "LEFT JOIN product_categories pcat ON p.id = pcat.product_id";
    $join[] = "LEFT JOIN categories c ON pcat.category_id = c.id AND c.status = 1";
    //$join[] = "LEFT JOIN categories pc ON c.parent_id = pc.id AND pc.status = 1";
}

/* -------------------------
   BUILD STRINGS
--------------------------*/
$selects = $select ? ', ' . implode(', ', $select) : '';
$joins   = implode(' ', $join);

/* -------------------------
   MAIN QUERY
--------------------------*/
$sql = "
SELECT 
    p.id,
    p.name,
    p.slug,
    p.price,
    p.sale_price,
    p.cost_price,
    p.stock_quantity,
    p.status,
    p.featured_rank,
  
    GROUP_CONCAT(
  DISTINCT CONCAT(m.id, '|', m.url)
  ORDER BY m.id ASC
  SEPARATOR '||'
) AS product_images,

    COALESCE(p.sale_price, p.price) AS final_price,

    CASE 
        WHEN p.stock_quantity > 0 THEN 'in_stock'
        ELSE 'out_of_stock'
    END AS stock_status

    $selects

FROM products p

LEFT JOIN product_images pi ON p.id = pi.product_id
LEFT JOIN media_images m ON pi.media_id = m.id

$joins
$where

GROUP BY 
    p.id
 --   , p.name,
 --    p.slug,
 --    p.price,
 --    p.sale_price,
 --    p.cost_price,
 --   p.stock_quantity,

ORDER BY p.featured_rank DESC, p.id DESC
LIMIT $limitInc OFFSET $offset
";

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);

    $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$data=[];

foreach( $rows AS $row){
    	$i++;
    
   if( $limit>$i ) {
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}
   
   $total=0; //Currently not in use

    return [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "total"=>$total,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Succesful"
    ];
}


//CREATE/UPDATE PRODUCTS

public function saveProduct()
{
    try {

        $data = $this->input();

        // Extract
        $id = $data['id'] ?? null;
        $featuredRank = trim($data['featured_rank'] ?? '');
        $status = trim($data['status'] ?? 'active');
        $name = trim($data['name'] ?? '');
        $slug = trim($data['slug'] ?? '');
        $price = $data['price'] ?? 0;
        $sale_price = $data['sale_price'] ?? null;
        $cost_price = $data['cost_price'] ?? null;
        $categories = $data['categories'] ?? []; // 👈 ARRAY
        $images = $data['images'] ?? []; // 👈 ARRAY
        $stock_quantity = $data['stock_quantity'] ?? 0;
        $description = $data['description'] ?? '';
        $fullDescription = mb_substr($data['full_description'] ?? '',0, 200);
        $image = $data['image'] ?? null;

        // Validation
        if (!$name) {
            $this->json([
        "success"=>false,
        "message"=>"Product name is required"
        ]);
        }

        if ($sale_price !== null && $sale_price > $price) {
            $this->json([
        "success"=>false,
        "message"=>"Sale price cannot be greater than regular price"
        ]);
        }

        if (!is_numeric($price) || $price < 0) {
            $this->json([
        "success"=>false,
        "message"=>"Invalid price"
        ]);
        }

 $hasDiscount=0;
 
 if ($sale_price !== null && $sale_price < $price) {
  $hasDiscount=1;
        }


        // Auto slug (optional)
        if (!$slug) {
            $slug = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', $name)));
        }
        
        $this->db->beginTransaction();

        if ($id) {
       
            // 🔁 UPDATE
            $sql = "
                UPDATE products SET
                featured_rank=?,
                status=?,
                    name = ?,
                    slug = ?,
                    price = ?,
                    sale_price = ?,
                    cost_price = ?,
                    stock_quantity = ?,
                    description = ?,
                    full_description=?,
                    image = ?,
                    has_discount= ?,
                    updated_at = NOW()
                WHERE id = ? AND site_id=?
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
             $featuredRank,
             $status,
                $name,
                $slug,
                $price,
                $sale_price,
                $cost_price,
                $stock_quantity,
                $description,
                $fullDescription,
                $image,
                $hasDiscount,
                $id,
                $this->siteId
            ]);

       $this->cache->invalidateTag('new_arrival', ['namespace'=>'new_arrival']);

        } else {
        	
            // ➕ CREATE
            $sql = "
                INSERT INTO products (
                site_id,
                  user_id,   name, slug, price, sale_price, cost_price,
                stock_quantity, description, full_description, image,
                   has_discount, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
            ";

            $stmt = $this->db->prepare($sql);

            $stmt->execute([
            $this->siteId,
                $this->userId,
                $name,
                $slug,
                $price,
                $sale_price,
                $cost_price,               
                $stock_quantity,
                $description,
                $fullDescription,
                $image,
                $hasDiscount
            ]);
            
    $id=$this->db->lastInsertId();        
            
        }
        
    // 🧹 CLEAR OLD CATEGORIES RELATIONS
        $this->db->prepare("DELETE FROM product_categories WHERE product_id = ?")
                  ->execute([$id]);                 
               
        // ➕ INSERT NEW CATEGORIES RELATIONS
        if (!empty($categories)) {

            $stmt = $this->db->prepare("
                INSERT INTO product_categories (product_id, category_id)
                VALUES (?, ?)
            ");

            foreach ($categories as $catId) {
                $stmt->execute([$id, $catId]);
            }
        }
        
        
// 🧹 CLEAR OLD PRODUCT IMAGES RELATIONS
        $this->db->prepare("DELETE FROM product_images WHERE product_id = ?")
                  ->execute([$id]);
        
        // ➕ INSERT NEW PRODUCT IMAGES RELATIONS
        if (!empty($images)) {

            $stmt = $this->db->prepare("
                INSERT INTO product_images (product_id, media_id)
                VALUES (?, ?)
            ");

            foreach ($images as $mediaId) {
                $stmt->execute([$id, $mediaId]);
            }
        }
        
        
    $this->db->commit();
        
        $this->cache->invalidateTag('new_arrival', ['namespace'=>'new_arrival']);
        
$this->json([
        "success"=>true,
        "message"=>"Product Saved",
        "id" => $id
    ]);
        
} catch (\Throwable $e) {
    	      if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }
    error_log($e->getMessage());
        $this->json([
        "success"=>false,
        "message"=>"Failed"
        ]);
    }
}
	
public function deleteProduct() {

    // 📥 Read input
    $data = $this->input();
    $id = (int)($_GET['id'] ?? 0);

    // ❌ Validate ID
    if ($id <= 0) {
        $this->json(['success'=>false, 'message'  => 'Invalid product ID'], 422);
    }

    // 🔍 Check product exists & not deleted
    $prod = $this->db->prepare(
        "SELECT id FROM products WHERE id = ? AND status = 1 LIMIT 1"
    );
    $prod->execute([$id]);

    if (!$prod->fetch()) {
        $this->json(['success'=>false, 'message' => 'Product not found or already deleted'], 404);
    }

    // ✅ Soft delete
    $stmt = $this->db->prepare(
        "UPDATE products SET status = 'inactive' WHERE id = ? AND site_id=?"
    );
    $stmt->execute([$id, $this->siteId]);

    $this->json([
        'success' => true,
        'message' => 'Product deleted successfully'
    ]);
}


public function getOrders( $options=[]){
   $data=$this->input();
    $data=array_merge( $data, $options);  
   
   $frontEnd=$data['frontend']??false;
   
    $id = intval($data['id']??0);
    $page  =  intval($data['p']??1);
    $limit = intval($data['limit']??10);    
    $search = trim($data['s'] ?? '');

    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;

    $where = [];
    $values = [];

    // 🔎 Search (order UID)
    if (!empty($search) ) {
        $where[] = "( o.order_uid LIKE ? OR o.payment_reference = ? )";
        $values[] = "%$search%";
        $values[] = $search;
    }

$status=$data['status']??'';
$payment_status=$data['payment_status']??'';
    // 📊 Status filter
    
if( !empty($status) ){
    $where[] = "o.status = ?";
        $values[] = $status;     
    }

 if( !empty($payment_status) ){
    $where[] = "o.payment_status = ?";
        $values[] = $payment_status;     
    }

    if ($frontEnd) {
        $where[] = "o.user_id = ?";
        $values[] = $this->userId;
    }

    // 📅 Date range
    if (!empty($data['from'])) {
        $where[] = "o.created_at >= ?";
        $values[] = $data['from'];
    }

    if (!empty($data['to'])) {
        $where[] = "o.created_at <= ?";
        $values[] = $data['to'];
    }

    $whereSql = '';
    if (!empty($where)) {
        $whereSql = 'WHERE ' . implode(' AND ', $where);
    }


    $limitInc=$limit+1;

 // 📦 products query
    $sql = "
        SELECT 
        o.id,
        o.user_id,
        o.total_amount,
        o.order_uid,
        o.status,
        o.payment_status,      
        o.created_at,
        COUNT(oi.id) AS total_items,
        COALESCE(u.name, o.customer_name) AS name,
        COALESCE(u.phone, o.customer_phone) AS phone,
        COALESCE(u.email, o.customer_email) AS email
        
    FROM orders o
    LEFT JOIN order_items oi ON oi.order_id = o.id
    LEFT JOIN users u ON o.user_id=u.id
    $whereSql
    GROUP BY o.id
    ORDER BY o.id DESC
LIMIT $limitInc OFFSET $offset    ";

    $stmt = $this->db->prepare($sql);
    $stmt->execute($values);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

$data=[];

foreach( $rows AS $row){
    	$i++;    
   if( $limit>$i ) {
   	       
    if ( strtotime($row['created_at']) <= strtotime("-{$this->AppSettings['orders']['maxOrderPendingDays']} days")  ){

 if ( in_array($row['status'], ['pending','expired']) ) {
     $row['expired']='expired';
     }
}
   
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}
   
   $total=0; //Currently not in use

   return [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "total"=>$total,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Successful"
    ];
}


public function orderDetails() {

    $data = $this->input();
    $orderId = ($data['id'] ?? 0);
    $newReference=$data['newReference']??false;

    if (!is_numeric($orderId) || $orderId < 1) {
        return $this->json([
            "success" => false,
            "message" => "Invalid order id"
        ]);
    }

    /* =========================
       1. FETCH ORDER + ITEMS
       ========================= */

    $sql = "
    SELECT
        o.id AS order_id,
        o.total_amount,
        o.order_uid,
        o.payment_reference,
        o.status,
        o.payment_status,
        o.payment_method,
        o.paid_at,
        o.created_at,
        COALESCE(o.customer_name, u.name) AS full_name,
        COALESCE( o.customer_phone, u.phone) AS phone,
        COALESCE(o.customer_email, u.email ) AS email,
        COALESCE(o.customer_state, u.state) AS state,
        COALESCE(o.customer_address, u.address ) AS address,

        oi.id AS item_id,
        oi.product_id,
        oi.quantity,
        oi.price,
        oi.total,

        p.name

    FROM orders o
    JOIN order_items oi ON oi.order_id = o.id
    JOIN products p ON p.id = oi.product_id
    LEFT JOIN users u ON o.user_id = u.id

    WHERE o.id = ?
    ";

try{
	
    $stmt = $this->db->prepare($sql);
    $stmt->execute([$orderId]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
        return $this->json([
            "success" => false,
            "message" => "Order not found"
        ]);
    }

    /* =========================
       2. BUILD ORDER + ITEMS
       ========================= */

    $order = null;
    $items = [];
    $productIds = [];


    foreach ($rows as $row) {

      $expired=false;
            
    if ( strtotime($row['created_at']) <= strtotime("-{$this->AppSettings['orders']['maxOrderPendingDays']} days")  ){

 if ( $newReference && in_array($row['status'], ['pending','expired']) ) {
     $expired=true;
     }
}

        if (!$order) {
        	
            $order = [
                'id' => $row['order_id'],                
                'order_uid' => $row['order_uid'],
                'total_amount' => $row['total_amount'],
                'status' => $row['status'],
                'payment_status' => $row['payment_status'],
                'payment_method' => $row['payment_method'],
                'payment_reference' => $row['payment_reference'],
                'paid_at' => $row['paid_at'],
                'created_at' => $row['created_at'],
                'fullname' => $row['full_name'],
                'email' => $row['email'],
                'phone' => $row['phone'],
                'state' => $row['state'],
                'address' => $row['address']
            ];
            
     
if( $newReference){
	//User is trying to pay for pending order
	 if(  $expired) {
		
if( $row['status']!=='expired'){
   $this->updateOrderStatus($orderId, 'expired');		
		}
		return $this->json([
            "success" => false,
            "message" => "Order expired"
        ]);
	}
	
$reference=$this->generateReference( 'OSR');

	$stmt=$this->db->prepare("UPDATE orders
SET payment_reference = ?
WHERE id = ? LIMIT 1");

$stmt->execute([$reference, $orderId]);

if( $stmt->rowCount()<1) {
	return $this->json([
            "success" => false,
            "message" => "Please try again"
        ]);
	}
	
	$order['new_reference']=$reference;
}


        }

        $productId = (int)$row['product_id'];

        $productIds[] = $productId;

        $items[$productId] = [
            'id' => $row['item_id'],
            'product_id' => $productId,
            'name' => $row['name'],
            'quantity' => $row['quantity'],
            'price' => $row['price'],
            'total' => $row['total'],
            'images' => [] // placeholder
        ];
    }

    /* =========================
       3. FETCH PRODUCT IMAGES
       ========================= */

    $productIds = array_values(array_unique($productIds));

    if (!empty($productIds)) {

        $placeholders = implode(',', array_fill(0, count($productIds), '?'));

        $sql2 = "
        SELECT
            pi.product_id,
            m.id,
            m.url
        FROM product_images pi
        JOIN media_images m ON m.id = pi.media_id
        WHERE pi.product_id IN ($placeholders)
        ORDER BY m.id ASC
        ";

        $stmt2 = $this->db->prepare($sql2);
        $stmt2->execute($productIds);

        $imageRows = $stmt2->fetchAll(PDO::FETCH_ASSOC);

        foreach ($imageRows as $img) {
            $pid = (int)$img['product_id'];

            if (isset($items[$pid])) {
                $items[$pid]['images'][] = [
                    'id' => $img['id'],
                    'url' => $img['url']
                ];
            }
        }
    }

    /* =========================
       4. FINAL RESPONSE
       ========================= */

    return $this->json([
        'success' => true,
        'order' => $order,
        'items' => array_values($items) // reset keys
    ]);
    
    
    }catch(\Throwable $e){
    	error_log($e->getMessage());
    return $this->json([
        'success' => false,
        'message'=>'An error occured'
    ]);
    }
}

public function generateReference(string $prefix = 'OSP'): string{
    return sprintf(
        '%s-%s-%s',
        $prefix,
        date('YmdHis'),
        strtoupper(bin2hex(random_bytes(4)))
    );
}

public function adjustOrder(){

$data=$this->input();
$orderId=intval($data['order_id']??0);
$newStatus=trim($data['status']??'pending');

if(empty($orderId)){

$this->json(['success'=>false, 'message'=>'Invalid order ID']);
}

$items=$data['items']??[];

$total=0;

 try{

$stmt = $this->db->prepare("
            SELECT id, status
            FROM orders
            WHERE id = ?
            FOR UPDATE");

        $stmt->execute([$orderId]);

        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            return ['success'=>false, 'message'=>'Order not found.'];
        }

$this->db->beginTransaction();

$this->db->prepare("
UPDATE orders
SET
payment_status=?,
payment_method=?,
customer_name=?,
customer_email=?,
customer_phone=?,
customer_state=?,
customer_address=?
WHERE id=?
")->execute([
trim($data['payment_status']??'unpaid'),
trim($data['payment_method']??'pod'),
trim($data['fullname']??''),
trim($data['email']??''),
trim($data['phone']??''),
trim($data['state']??''),
trim($data['address']??''),
$orderId

]);

$this->db->prepare("
DELETE FROM order_items
WHERE order_id=?
")->execute([$orderId]);

foreach($items as $item){
	
$productId=(int)($item['product_id']??0);
$name=trim($item['name']??'');
$quantity=(int)($item['quantity']??0);
$price=(float)($item['price']??0);

$itemTotal=$quantity*$price;

$total+=$itemTotal;

$this->db->prepare("
INSERT INTO order_items(
order_id,
product_id,
quantity,
price,
total ) VALUES (?,?,?,?,?)
")->execute([

$orderId,
$productId,
$quantity,
$price,
$itemTotal
]);

}

$this->db->prepare("
UPDATE orders
SET total_amount=?
WHERE id=?
")->execute([
$total,
$orderId
]);

$this->db->commit();

$this->json([
'success'=>true,
'message'=>'Adjusted Successfully',
'total_amount'=>$total
]);

}catch(Exception $e){

      if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }

$this->json([
'success'=>false,
'message'=>$e->getMessage()
]);
  }
}


public function changeOrderStatus(): array{
	$data=$this->input();
	$orderId=$data['orderId']??'';
	$newStatus=$data['newStatus']??'';
	
	if( empty( $orderId) || empty( $newStatus) ){
		return ['success'=>false, 'message'=>'Missing order ID or new status'];
	}
        
  return $this->updateOrderStatus($orderId, $newStatus);
}


public function cancelOrder(): array{
	$data=$this->input();
	$orderId=$data['id']??'';
	
	if( empty( $orderId) ){
		return ['success'=>false, 'message'=>'Missing order ID'];
	}
        
  return $this->updateOrderStatus($orderId, 'cancelled');
}

public function updateOrderStatus($orderId, $newStatus){
	
	$where=['id = ? '];
 $params=[ $orderId ];
 
 if( !$this->admin() ){
 	$where[]=' user_id=?';
     $params[]=$this->userId;
 }
 
$wheres= " WHERE " . implode("," , $where);
  
	
    try {
        
        // Get current order
        $stmt = $this->db->prepare("
            SELECT status
            FROM orders
            $wheres
            LIMIT 1
        ");
        $stmt->execute($params);

        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) {
            throw new Exception("Order not found.");
        }

  $oldStatus=$order['status'];

if( $newStatus== $oldStatus){
	return [
            'success' => true,
            'message' => 'Order status updated successfully.'
        ];
	}

if(  in_array( $oldStatus, ['cancelled','expired'] ) && !in_array($newStatus, ['pending','cancelled','expired'])  ) {     
        //If order is cancelled or expired, Order must should be changed to pending first before updating to new status: processing, delivered e.t.c because stock quantity must be updated
        
        return [
                    'success' => false,
                    'message' => 'Change order status to "pending" first' ];
}
        


        // Get order items
        $stmt = $this->db->prepare("
            SELECT
                oi.product_id,
                oi.quantity,
                p.name,
                p.stock_quantity
            FROM order_items oi
            INNER JOIN products p
                ON p.id = oi.product_id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$orderId]);

        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!$items) {
            throw new Exception("Order contains no items.");
        }

        /*
        |--------------------------------------------------------------------------
        | PENDING
        |--------------------------------------------------------------------------
        */
        
      $this->db->beginTransaction();
                 
        if ($newStatus === 'pending' && in_array( $oldStatus, ['cancelled','expired'] ) ) {
        	
            $lowStockItems = [];

            // Validate stock first
            foreach ($items as $item) {

                if ($item['stock_quantity'] < $item['quantity']) {
                    $lowStockItems[] = $item['name'];
                }
            }

            if (!empty($lowStockItems)) {

                $this->db->rollBack();

                return [
                    'success' => false,
                    'message' => 'Insufficient stock for: ' .
                        implode(', ', $lowStockItems)
                ];
            }

            // Deduct stock
            $stmt = $this->db->prepare("
                UPDATE products
                SET stock_quantity = stock_quantity - ?
                WHERE id = ?
            ");

            foreach ($items as $item) {
                $stmt->execute([
                    $item['quantity'],
                    $item['product_id']
                ]);
            }
        }

        /*
        |--------------------------------------------------------------------------
        | CANCELLED
        |--------------------------------------------------------------------------
        */
        elseif ( $newStatus === 'cancelled' || $newStatus =='expired' ) {

       if( $oldStatus!=='cancelled' && $oldStatus!=='expired'){
     $stmt = $this->db->prepare("
                UPDATE products
                SET stock_quantity = stock_quantity + ?
                WHERE id = ?
            ");

            foreach ($items as $item) {
                $stmt->execute([
                    $item['quantity'],
                    $item['product_id']
                ]);
            }
       }     
    } 

        // Update order status
        $stmt = $this->db->prepare("
            UPDATE orders
            SET status = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $newStatus,
            $orderId
        ]);

        $this->db->commit();

        return [
            'success' => true,
            'message' => 'Order status updated successfully.'
        ];

    } catch (\Throwable $e) {

        if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }

        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

public function removeOrderItem(): array{
	
	$data=$this->input();
	$orderItemId=$data['item_id'];
	
    try {
        $this->db->beginTransaction();

        // Get order item and order details
        $stmt = $this->db->prepare("
            SELECT
                oi.id,
                oi.order_id,
                oi.product_id,
                oi.quantity,
                oi.price,
                o.status
            FROM order_items oi
            INNER JOIN orders o
                ON o.id = oi.order_id
            WHERE oi.id = ?
            LIMIT 1
        ");

        $stmt->execute([$orderItemId]);

        $item = $stmt->fetch(\PDO::FETCH_ASSOC);

        if (!$item) {
            throw new \Exception("Order item not found.");
        }

        // Prevent removing items from finalized orders
if (in_array($item['status'], ['shipped', 'delivered','cancelled','expired'])) {
            throw new \Exception(
                "Items cannot be removed."
            );
        }

        // Restore stock if stock was deducted
       $stmt = $this->db->prepare("
                UPDATE products
                SET stock_quantity = stock_quantity + ?
                WHERE id = ?
            ");

            $stmt->execute([
                $item['quantity'],
                $item['product_id']
            ]);
        
        // Delete order item
        $stmt = $this->db->prepare("
            DELETE FROM order_items
            WHERE id = ?
        ");

        $stmt->execute([$orderItemId]);

        // Recalculate order total
        $stmt = $this->db->prepare("
            UPDATE orders
            SET total_amount = (
                SELECT COALESCE(
                    SUM(quantity * price),
                    0
                )
                FROM order_items
                WHERE order_id = ?
            )
            WHERE id = ?
        ");

        $stmt->execute([
            $item['order_id'],
            $item['order_id']
        ]);

        $this->db->commit();

        return [
            'success' => true,
            'message' => 'Order item removed successfully.'
        ];

    } catch (\Throwable $e) {

        if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }
        
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}	
	
	
	
public function updateOrderX(){	
 $data=$this->input();
 
 $orderId = $data['id']??0;
 $status=$data['status']??'';
 
 if( $orderId<1 ){
	$this->json([
         "success"=>false,
         "message"=>"Invalid order id"
         ]);
	}
	
 if( empty( $status) ){
 	
 $this->json(['success'=>false, 'message' => 'Status is empty'], 401); 
 }
 
	$stmt = $this->db->prepare("
    UPDATE orders 
    SET status = ?, updated_at = NOW() 
    WHERE id = ?
");
$stmt->execute([$status, $orderId]);

	$this->json(['success'=>true, 'message' => 'Successful'], 401);
}
	



   /* ================================
       USERS
    ================================= */
    
 public function listUsers() {
        $q = $this->db->query("SELECT U.id, U.name, U.branch_id, U.username, U.role, U.phone, U.email, B.id AS branch_id, B.name AS branch_name FROM users U 
LEFT JOIN branches B ON (U.branch_id=B.id) WHERE U.status=1 ORDER BY role ASC");//devl.-Os
      return $q->fetchAll(PDO::FETCH_ASSOC);
  }

  
public function addNewUser( $role='user') {
    
    $d = $this->input();
    
    $required = ['name','username','password','email','address','state'];
    
    foreach ($required as $field) {
        if (empty($d[$field])) {
            $this->json(['success'=>false, 
                'message' => "Missing required field: {$field}"
            ], 400);
        }
    }

    $allowedRoles = ['administrator','manager','staff','user'];
    
    if (!in_array($role, $allowedRoles, true)) {
        $this->json(['success'=>false, 
            'message' => 'Invalid role'
        ], 400);
    }

    $name = trim($d['name']);
    if (strlen($name) < 3) {
        $this->json(['success'=>false, 
            'message' => 'Full name must be at least 3 characters'
        ], 400);
    }

    $username = strtolower(trim($d['username']));
    
    if( strlen($username)< 4){
    	$this->json(['success'=>false, 
            'message' => 'Username should contain at least 4 characters'
        ], 400);
    }

if( strlen($username)>30){
    	$this->json(['success'=>false, 
            'message' => 'Username should not be more than 30 characters'
        ], 400);
    }
   
    if (!preg_match("/^[a-z0-9]+$/i",  $username)) {
        $this->json(['success'=>false, 
            'message' => 'Username supports alphabets & numbers'
        ], 400);
    }
    
    /*PHONE VALIDATION*/
    
   $phone = strtolower(trim($d['phone']??''));
    
    if (!empty( $phone) && !preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        $this->json(['success'=>false, 'message' => 'Invalid phone number'], 422);
    }
   
/* ================================
       Address VALIDATION
    ================================ */
    
    $state = trim($d['state']??'');
 
   if (mb_strlen($state)< 3 ) {
        $this->json(['success'=>false, 
            'message' => 'Select state'
        ], 400);
    }
 
 
    $address = trim($d['address']??'');
 
   if (mb_strlen($address)< 20 ) {
        $this->json(['success'=>false, 
            'message' => 'Enter a concise delivery address. Min: 20 characters'
        ], 400);
    }
 
 $email = strtolower(trim($d['email']??''));
    
    if (!empty( $email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $this->json(['success'=>false, 
            'message' => 'Invalid email address'
        ], 400);
    }

    $password = $d['password'];

    if (strlen($password) < 5) {
        $this->json(['success'=>false, 
            'message' => 'Password must be at least 5 characters'
        ], 400);
    }

    if (!preg_match('/[A-Z]/i', $password) 
    //    !preg_match('/[a-z]/i', $password) ||
   || !preg_match('/[0-9]/', $password)
) {

        $this->json(['success'=>false, 
            'message' => 'Password must contain alphabets and number'
        ], 400);
    }

    // Check duplicate email
    $q = $this->db->prepare(
        "SELECT id, username, email FROM users WHERE username=? OR email = ? LIMIT 1"
    );
    $q->execute([$username, $email]);
    if ($q->fetch()) {
    	
        $this->json(['success'=>false, 
            'message' => 'Username or Email already exists'
        ], 409);
    }


    /* ================================
       INSERT USER
    ================================= */
    $hash = password_hash($password, PASSWORD_DEFAULT);


$token = bin2hex(random_bytes(32)); // 64-char secure token
    $expire_timeStamp=strtotime('+12 days');
    $expiry = date('Y-m-d H:i:s', $expire_timeStamp );

setcookie($this->cookieName, $token, [
    'expires' => $expire_timeStamp, // 1 hour
    'path' => '/',
   // 'secure' => true, // HTTPS only
    'httponly' => true, // prevent JavaScript access
]);

	$emailVerificationToken=$this->generateRandomToken();


   $inserted= $this->db->prepare(
        "INSERT INTO users (site_id, role, name, username, email, email_verified, phone, password, state, address, login_token, token_expiry, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW() )"
    )->execute([
       $this->siteId,
        $role,
        $name,
        $username,
        $email,
        $emailVerificationToken,
        $phone,
        $hash,
        $state,
        $address,
        $token,
        $expiry
    ]);

if ($inserted && $this->db->lastInsertId()) {
	
$buid=base64_encode($this->db->lastInsertId());
$code= $emailVerificationToken;

$verificationLink=$this->site_url() . "/verify-email.php?id={$buid}&code={$code}";

$eMsg=$this->emailVerificationMessage($verificationLink, '24 hours');

$this->queue->push('email', [
    'to' => trim($email),
    'subject' => $eMsg['subject'], 
    'body' => $eMsg['message']
]);

    $this->json([
        'success' => true,
        'token'=>$token,
        'expiry'=>$expiry,
        'message' => 'Successful'
    ], 201);
    
    }
    
    
    $this->json(['success'=>false, 
            'message' => 'Could not create account'
        ], 409);
    
    
}

protected function generateRandomToken(): string {
    return strtoupper(substr( bin2hex(random_bytes(8)), 0, 10  )  );
    }
    
public function editUser() {
	
        $d = $this->input();

    $required = ['id','role','branch','full_name','username'];
    
    foreach ($required as $field) {
        if (empty($d[$field])) {
            $this->json(['success'=>false, 
                'message' => "Missing required field: {$field}"
            ], 400);
        }
    }

  //       ROLE VALIDATION (ENUM SAFE)
   
    $allowedRoles = ['administrator','manager','staff'];
    
    if (!in_array($d['role'], $allowedRoles, true)) {
        $this->json(['success'=>false, 
            'message' => 'Invalid role'
        ], 400);
    }

        $id= intval( $d['id']??0);
    
    
    if (empty($id) ) {
        $this->json(['success'=>false, 
            'message' => 'Invalid User ID'
        ], 400);
    }
   

if( !$this->admin() && $this->userId!==$id ){
		$this->json(['success'=>false, 
                'message' => "Permission denied"
            ], 400);
		}

//       Branches VALIDATION
   
    $branch = intval($d['branch']??0);
    
    if (empty($branch) ) {
        $this->json(['success'=>false, 
            'message' => 'Select branch'
        ], 400);
    }

if (!$this->admin() && $this->userId!==$id ) {
            $this->json(['success'=>false, 
                'message' => "Permission denied"
            ], 400);
        }
    
    //     NAME VALIDATION
   
$name = trim($d['full_name']);
    if (strlen($name) < 3) {
        $this->json(['success'=>false, 
            'message' => 'Full name must be at least 3 characters'
        ], 400);
    }

if( $this->userId==$id && $this->userRole!==$d['role'] ){
	$this->json(['success'=>false, 
            'message' => 'You cannot change your own role'
        ], 400);
	}

if( $this->userId==$id && $this->branchId!==$branch ){
	$this->json(['success'=>false, 
            'message' => 'You cannot change your own role'
        ], 400);
	}	
	
//       USERNAME VALIDATION
    
    $username = strtolower(trim($d['username']));
    
    if( strlen($username)< 4){
    	$this->json(['success'=>false, 
            'message' => 'Username should contain at least 4 characters'
        ], 400);
    }

if( strlen($username)>20){
    	$this->json(['success'=>false, 
            'message' => 'Username should not be more than 20 characters'
        ], 400);
    }
   
    if ( !preg_match("/^[a-z0-9]+$/i",  $username)) {
        $this->json(['success'=>false, 
            'message' => 'Username supports alphabets & numbers'
        ], 400);
    }
    
   //PHONE VALIDATION
    
   $phone = strtolower(trim($d['phone']??''));
    
    if (!empty( $phone) && !preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        $this->json(['success'=>false, 'message' => 'Invalid phone number'], 422);
    }
    
//       EMAIL VALIDATION
 $email = strtolower(trim($d['email']??''));
    
    if (!empty( $email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $this->json(['success'=>false, 
            'message' => 'Invalid email address'
        ], 400);
    }

$newPassword = trim($d['newPassword']??'');

 $oldPassword='';
 
if( $this->userId==$id) {
 $oldPassword=trim($d['oldPassword']??'');
}
  
    try {

        // Check if user exists
        $checkUser = $this->db->prepare("SELECT id, password FROM users WHERE id = ?");
        $checkUser->execute([$id]);
        
        if ($checkUser->rowCount() == 0) {
            $this->json([
            "success" => false,
                "message" => "User not found"
            ]);
            return;
        }
        
        $u = $checkUser->fetch(PDO::FETCH_ASSOC);
        
   $hashedPassword=$u['password'];
   
   if( !empty( $newPassword ) ){
   
   if (strlen($newPassword) < 5) {
        $this->json(['success'=>false, 
            'message' => 'New password must contain at least 5 characters'
        ], 400);
    }

    if (!preg_match('/[A-Z]/i', $newPassword) ||
    //    !preg_match('/[a-z]/i', $newPassword) ||
        !preg_match('/[0-9]/', $newPassword)) {

        $this->json(['success'=>false, 
            'message' => 'New password must contain alphabets and number'
        ], 400);
    } 
    
  if( $id==$this->userId){
  	
   if( empty($oldPassword)  ){
   	$this->json(['success'=>false, 
            'message' => 'Enter your old password to confirm new password'
        ], 400);
   }
   
   if(!password_verify(  $oldPassword, $hashedPassword) ){
    	$this->json(['success'=>false, 
            'message' => 'Invalid old password'
        ], 400);
    }
       
  }  
        
$hashedPassword= password_hash($newPassword, PASSWORD_DEFAULT);
    
 }

        // Check duplicate email or username
        $q = $this->db->prepare("SELECT id, username, email FROM users WHERE id != ?");
        $q->execute([ $id]);

    $user = $q->fetch(PDO::FETCH_ASSOC);
 
        if ( strtolower($user['email'])==strtolower($email) ) {
            echo json_encode([
                "status" => false,
                "message" => "Email already used by another user"
            ]);
            return;
        }
        
      if ( strtolower($user['username'])==strtolower($username) ) {
            echo json_encode([
                "status" => false,
                "message" => "Username already used by another user"
            ]);
            return;
        }

        // Update user
        $sql = "UPDATE users 
                SET name = ?, username=?, email = ?, password=?, phone = ?, role = ?
                WHERE id = ?";

        $stmt = $this->db->prepare($sql);

        $result = $stmt->execute([
            $name,
            $username,
            $email,
            $hashedPassword,
            $phone,
            $d['role'],
            $id
        ]);

        if ($result) {
            $this->json([
            "success" => true,
                "message" => "Updated successfully"
            ]);
        } else {
            $this->json([
            "success" => false,
            "message" => "Failed to update user"
            ]);
        }

    } catch (PDOException $e) {

        $this->json([
            "success" => false,
            "message" => "Server error. Try again later",
            "error" => $e->getMessage()
        ]);
    }
    
}


public function deleteUser() {
 // 🔒 Admin only
    if (!$this->admin() && $this->branchId==1) {
        $this->json(['success'=>false, 'message' => 'Only admins can delete users'], 403);
    }

    // 📥 Read input
   
    $id = (int)($_GET['id'] ?? 0);

    // ❌ Validate ID
    if ($id <= 0) {
        $this->json(['success'=>false, 'message' => 'Invalid User ID'], 422);
    }
    
    if ($id == 1) {
        $this->json(['success'=>false, 'message' => 'You cannot delete the Master Admin'], 422);
    }

    // 🔍 Check user exists and not deleted
    $q = $this->db->prepare(
        "SELECT id FROM users WHERE id = ? AND status = 1 LIMIT 1"
    );
    $q->execute([$id]);

    if (!$q->fetch()) {
        $this->json(['success'=>false, 'message' => 'User not found or already deleted'], 404);
    }

    // ✅ Soft delete
    $stmt = $this->db->prepare(
        "UPDATE users SET status = 0 WHERE id = ?"
    );
    $stmt->execute([$id]);

    $this->json([
        'success' => true,
        'message' => 'User deleted successfully'
    ]);
}

//GALLERY
public function gallery(){
	
$id = intval($_GET['id']??0);
    $page  =  intval($_GET['p']??1);
    $limit = intval($_GET['limit']??10);
   $search = trim($_GET['s'] ?? '');
   $status = trim($_GET['status'] ?? 1);
	
$id = intval($_GET['id']??0);
    
    if($page < 1) $page = 1;
    if($limit < 1 || $limit > 100) $limit = 20;

    $offset = ($page - 1) * $limit;
    
        $wheres[] = " site_id= ?";
        $params[] = $this->siteId;


if($status != ""){
        $wheres[] = " status LIKE ? ";
        $params[] = $status;
    }
     if($id){
        $wheres[] = " id= ?";
        $params[] = $id;
    }

    // 🔎 search by product name
    if(!$id && $search != ""){
        $wheres[] = " description LIKE ?";
        $params[] = "%$search%";
    }

  $where="";
  
if( !empty($wheres) ){
	$where=" WHERE " . implode(" AND " , $wheres);
	}

    $limitInc=$limit+1;

 // 📦 products query
    $sql = "
        SELECT id,  description, url
    FROM media_images
    $where
    ORDER BY id DESC LIMIT $limitInc OFFSET $offset";

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);

    $i=-1;
    $nextPage=0;
    $prevPage=0;
    
   if( $page>1 ){
    $prevPage=$page-1;
} 

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$data=[];

foreach( $rows AS $row){
    	$i++;
    
   if( $limit>$i ) {
        $data[] = $row;
     }else{
        $nextPage=$page+1;
     }
}
   
   $total=0; //Currently not in use

    $this->json( [
        "success"=>true,
        "page"=>$page,
        "limit"=>$limit,
        "total"=>$total,
        "next"=>$nextPage,
        "prev"=>$prevPage,
        "data"=>$data,
        "message"=>"Succesful"
    ]);
}


    public function processFile($tmpPath, $mime, $filename, $baseDir, $folder)
    {
        // Load source
        switch ($mime) {
            case 'image/jpeg': $src = imagecreatefromjpeg($tmpPath); break;
            case 'image/png':  $src = imagecreatefrompng($tmpPath); break;
            case 'image/webp': $src = imagecreatefromwebp($tmpPath); break;
            default: return false;
        }

        list($width, $height) = getimagesize($tmpPath);

   $width=(int)$width;
   $height=(int)$height;


        // Ensure directories exist
        foreach (array_merge(["original"], array_keys($this->sizes)) as $dir) {
            if (!is_dir("$baseDir/$dir")) {
                mkdir("$baseDir/$dir", 0775, true);
            }
        }

        // =========================
        // SAVE ORIGINAL
        // =========================
        $originalPath = "$baseDir/original/$filename";

        $this->saveImage($src, $originalPath, $mime, 85);

$originalSize = filesize($originalPath);

        // =========================
        // GENERATE SIZES
        // =========================
        $generated = [];

        foreach ($this->sizes as $key => $maxWidth) {

            if ($width <= $maxWidth) {
                $newWidth  = (int)$width;
                $newHeight = (int)$height;
            } else {
                $newWidth  = (int)$maxWidth;
                $newHeight = (int)($height / $width) * $newWidth;
            }

            $dst = imagecreatetruecolor($newWidth, $newHeight);

            // Preserve transparency
            if ($mime === 'image/png' || $mime === 'image/webp') {
                imagecolortransparent($dst, imagecolorallocatealpha($dst, 0, 0, 0, 127));
                imagealphablending($dst, false);
                imagesavealpha($dst, true);
            }

            imagecopyresampled(
                $dst, $src,
                0, 0, 0, 0,
                $newWidth, $newHeight,
                $width, $height
            );

            $path = "$baseDir/$key/$filename";
            $this->saveImage($dst, $path, $mime, $this->imgQuality);

            imagedestroy($dst);

            $generated[$key] = [
                "path" => $path,
                "url"  => $this->buildUrl("$folder/$key/$filename"),
                "size" => filesize($path) // ✅ bytes
            ];
        }

        imagedestroy($src);

        return [
            "direct" => $this->buildUrl("$folder/original/$filename"),
            "path"=>"$folder/original/$filename",
            "size"=>$originalSize,
            "sizes"    => $generated
        ];
    }

    private function saveImage($img, $path, $mime, $quality)
    {
        switch ($mime) {
            case 'image/jpeg': imagejpeg($img, $path, $quality); break;
            case 'image/png':  imagepng($img, $path, 6); break;
            case 'image/webp': imagewebp($img, $path, $quality); break;
        }
    }

    private function buildUrl($path)
    {
        $base = $this->site_url();
        return $base . "/" . trim($path, "/");
    }


public function uploadToServer($files, $folder = "uploads/images", $maxSizeMB = 2)
{
    $results = [];

    $isMulti = is_array($files['tmp_name']);
    $count   = $isMulti ? count($files['tmp_name']) : 1;

    $baseDir = $this->site_dir() . "/" . trim($folder, "/");
    $maxBytes = $maxSizeMB * 1024 * 1024;


    for ($i = 0; $i < $count; $i++) {

        $tmpPath      = $isMulti ? $files['tmp_name'][$i] : $files['tmp_name'];
        $originalName = $isMulti ? $files['name'][$i] : $files['name'];

        if (!file_exists($tmpPath)) continue;

        // ✅ Size check
        if (filesize($tmpPath) > $maxBytes) {
            $results[] = ["success"=>false,"file"=>$originalName,"message"=>"Too large"];
            continue;
        }

        // ✅ MIME check
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime  = finfo_file($finfo, $tmpPath);
        finfo_close($finfo);

        if (!in_array($mime, ['image/jpeg','image/png','image/webp'])) {
            $results[] = ["success"=>false,"file"=>$originalName,"message"=>"Invalid type"];
            continue;
        }


$meta = json_decode($_POST['meta'], true);

$imgDesc = htmlspecialchars($meta['description'] ?? '');

if (mb_strlen($imgDesc, 'UTF-8') > 100) {
    $imgDesc = mb_substr($imgDesc, 0, 100, 'UTF-8') . '...';
}

        // ✅ Safe filename
        $clean = preg_replace('/[^a-zA-Z0-9._-]/', '_', $originalName);
        $name  = uniqid() . "_" . pathinfo($clean, PATHINFO_FILENAME);

        $extMap = [
            'image/jpeg' => '.jpg',
            'image/png'  => '.png',
            'image/webp' => '.webp'
        ];

        $filename = $name . $extMap[$mime];

        // =========================
        // 🔥 PROCESS IMAGE
        // =========================
        $processed = $this->processFile($tmpPath, $mime, $filename, $baseDir, $folder);

        if (!$processed) {
            $results[] = ["success"=>false,"file"=>$originalName,"message"=>"Processing failed"];
            continue;
        }

        $results[] = [
            "success" => true,
            "links"=>[ "direct"=>$processed['direct'] ],
            "file" => [
            "original_name" => $originalName,
                "name" => $filename,
                "mime" => $mime,
                "desc"=>$imgDesc,
                "path" => $processed['path'], 
                "size"=>$processed['size'],
                "sizes" => $processed['sizes']
            ]
        ];
    }



$mediaId = [];

foreach ($results as $item) {
  //Insert into media_images table
    if (!isset($item['success']) || !$item['success']) {
        continue;
    }

$stmt = $this->db->prepare("
        INSERT INTO media_images (user_id, site_id, url, path, filename, description, mime_type, size, storage)
        VALUES (?, ?, ?, ?, ?, ?, ?,  ?, ?)
    ");

    $stmt->execute([
         $this->userId,
         $this->siteId,
        $item['links']['direct'],                 // url
        $item['file']['path'] ?? null,            // path
        $item['file']['name'] ?? null,            // filename
        $item['file']['desc'] ?? null, 
        $item['file']['mime'] ?? null,
        $item['file']['size'] ?? null,
        'local'
    ]);

    $mediaId[]= $this->db->lastInsertId();
}

    return [
        "success" => true,
        "mediaId"=>$mediaId,
        "result"  => $results
    ];
}

//UPLOAD TO CLOUDFLARE

public function uploadToCloudflare($files){
	
	$results = [];

    // Normalize input: allow single file OR multiple files
    $isMulti = is_array($files['tmp_name']);

    $count = $isMulti ? count($files['tmp_name']) : 1;

    for ($i = 0; $i < $count; $i++) {

        $tmpPath = $isMulti ? $files['tmp_name'][$i] : $files['tmp_name'];
        $originalName = $isMulti ? $files['name'][$i] : $files['name'];
$mime = mime_content_type($isMulti ? $files['tmp_name'][$i] : $files['tmp_name'] );

$size = filesize($tmpPath);
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

$remoteFile = 'uploads/' . date('Y/m/') . bin2hex(random_bytes(16)) . '.' . $ext;

if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/jpg'])) {
	
	$results[] = [
                "success" => false,
                "file" => $originalName,
                "message" =>"Invalid file type"
            ];
	  continue;
}

$meta = json_decode($_POST['meta'], true);

$imgDesc = htmlspecialchars($meta['description'] ?? '');

if (mb_strlen($imgDesc, 'UTF-8') > 100) {
    $imgDesc = mb_substr($imgDesc, 0, 100, 'UTF-8') . '...';
}

        if (!file_exists($tmpPath)) {
            continue;
        }

        // =========================
        // PREP FILE
        // =========================
        $safeName = time() . "_" . preg_replace('/[^a-zA-Z0-9._-]/', '_', $originalName);
     
     $set=$this->AppSettings['cloudflare'];   
          
     $accountId=$set['account_id']??'';     
     $accessKey= $set['access_key']??'';
$secretKey =$set['secret_key']??'';
    $bucket=$set['bucket']??''; 
    $endpoint  =$set['endpoint']??'';
    $publicUrl=$set['public_url']??'';
        
$cloudflare=new CloudFlare( $accountId, $accessKey, $secretKey, $bucket, $endpoint, $publicUrl);
   
 $response=$cloudflare->upload( $tmpPath, $remoteFile);

$results[] = [
            "success" => $response['success'],
            "file" => [
                "name" => $safeName,
                "original_name" => $originalName,
                "path" => $remoteFile,
                "size" => $size,
                "mime"=>$mime,
                "desc"=>$imgDesc
            ],
          
            "links" => [
                "shareable" => $response['url']??'',
                "direct" => $response['url']??''
            ]
        ];
    }

  $mediaId = [];

foreach ($results as $item) {
  //Insert into media_images table
    if (!isset($item['success']) || !$item['success']) {
        continue;
    }

$stmt = $this->db->prepare("
        INSERT INTO media_images (user_id, site_id, url, path, filename, description, mime_type, size, storage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
         $this->userId,
         $this->siteId,
        $item['links']['direct'],                 // url
        $item['file']['path'] ?? null,            // path
        $item['file']['name'] ?? null,            // filename
        $item['file']['desc'] ?? null, 
        $item['file']['mime'] ?? null,
        $item['file']['size'] ?? null,
        'cloudflare'
    ]);

    $mediaId[]= $this->db->lastInsertId();
}

return [
    'success'=>true,
    'mediaId'=>$mediaId,
    'result'=>$results
    ];
}
	

public function getDropboxAccessToken()
{
	$set=$this->AppSettings['dropbox'];   
         
     $appKey= $set['app_key']??'';
$appSecret =$set['app_secret']??'';
    $accessToken=$set['access_token']??''; 
    $refreshToken  =$set['refresh_token']??'';

if( $accessToken) return $accessToken;
    
    $cacheFile = __DIR__ . '/dropbox-token.json';

    // =========================
    // 1. CHECK CACHE
    // =========================
    if (file_exists($cacheFile)) {
        $data = json_decode(file_get_contents($cacheFile), true);

        if (!empty($data['access_token']) && time() < $data['expires_at']) {
            return $data['access_token']; // ✅ use cached
        }
    }

    // =========================
    // 2. REQUEST NEW TOKEN
    // =========================
    $ch = curl_init("https://api.dropboxapi.com/oauth2/token");

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        "grant_type" => "refresh_token",
        "refresh_token" => $refreshToken
    ]));

    curl_setopt($ch, CURLOPT_USERPWD, "$appKey:$appSecret");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    $res = json_decode($response, true);

    if (!isset($res['access_token'])) {
    	$this->json([
        'success' => false,
        'message' => 'Failed to get access token'
    ]);
       
    }

    // =========================
    // 3. SAVE CACHE
    // =========================
    $expiresAt = time() + ($res['expires_in'] - 60); // subtract 60s safety

    @file_put_contents($cacheFile, json_encode([
        "access_token" => $res['access_token'],
        "expires_at" => $expiresAt
    ]));

    return $res['access_token'];
}
	
public function uploadToDropbox($files, $folder = "os-shop")
{
	
	$set=$this->AppSettings['dropbox'];   
         
    $folder=$set['folder']??$folder;
	
	$token=$this->getDropboxAccessToken();

    $results = [];

    // Normalize input: allow single file OR multiple files
    $isMulti = is_array($files['tmp_name']);

    $count = $isMulti ? count($files['tmp_name']) : 1;

    for ($i = 0; $i < $count; $i++) {

        $tmpPath = $isMulti ? $files['tmp_name'][$i] : $files['tmp_name'];
        $originalName = $isMulti ? $files['name'][$i] : $files['name'];
$mime = mime_content_type($isMulti ? $files['tmp_name'][$i] : $files['tmp_name'] );

if (!in_array($mime, ['image/jpeg','image/png','image/webp'])) {
	
	$results[] = [
                "success" => false,
                "file" => $originalName,
                "message" =>"Invalid file type"
            ];
	  continue;
}

$meta = json_decode($_POST['meta'], true);

$imgDesc = htmlspecialchars($meta['description'] ?? '');

if (mb_strlen($imgDesc, 'UTF-8') > 100) {
    $imgDesc = mb_substr($imgDesc, 0, 100, 'UTF-8') . '...';
}

        if (!file_exists($tmpPath)) {
            continue;
        }

        // =========================
        // PREP FILE
        // =========================
        $safeName = time() . "_" . preg_replace('/[^a-zA-Z0-9._-]/', '_', $originalName);
        $dropboxPath = "/" . rtrim(ltrim($folder,'/'), '/') . "/" . $safeName;

        // =========================
        // 1. UPLOAD FILE
        // =========================
        $ch = curl_init("https://content.dropboxapi.com/2/files/upload");

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $token",
            "Content-Type: application/octet-stream",
            "Dropbox-API-Arg: " . json_encode([
                "path" => $dropboxPath,
                "mode" => "add",
                "autorename" => true
            ])
        ]);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, file_get_contents($tmpPath));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $uploadResponse = curl_exec($ch);
        curl_close($ch);

        $uploadData = json_decode($uploadResponse, true);

        if (!isset($uploadData['path_lower'])) {
            $results[] = [
                "success" => false,
                "file" => $originalName,
                "message" => $uploadResponse
            ];
            continue;
        }

        // =========================
        // 2. CREATE SHARE LINK
        // =========================
        $ch = curl_init("https://api.dropboxapi.com/2/sharing/create_shared_link_with_settings");

        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $token",
            "Content-Type: application/json"
        ]);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
            "path" => $uploadData['path_lower']
        ]));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $linkResponse = curl_exec($ch);
        curl_close($ch);

        $linkData = json_decode($linkResponse, true);

        // =========================
        // 3. BUILD DIRECT LINK
        // =========================
        $directUrl = null;

        if (isset($linkData['url'])) {
            $directUrl = str_replace("dl=0", "raw=1", $linkData['url']);
        }

        // =========================
        // 4. STORE RESULT
        // =========================
        $results[] = [
            "success" => true,
            "file" => [
                "name" => $safeName,
                "original_name" => $originalName,
                "path" => $uploadData['path_lower'],
                "size" => $uploadData['size'] ?? null,
                "mime"=>$mime,
                "desc"=>$imgDesc
            ],
          
            "links" => [
                "shareable" => $linkData['url'] ?? null,
                "direct" => $directUrl
            ]
        ];
    }

  
  $mediaId = [];

foreach ($results as $item) {
  //Insert into media_images table
    if (!isset($item['success']) || !$item['success']) {
        continue;
    }

$stmt = $this->db->prepare("
        INSERT INTO media_images (user_id, site_id, url, path, filename, description, mime_type, size, storage)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
         $this->userId,
         $this->siteId,
        $item['links']['direct'],                 // url
        $item['file']['path'] ?? null,            // path
        $item['file']['name'] ?? null,            // filename
        $item['file']['desc'] ?? null, 
        $item['file']['mime'] ?? null,
        $item['file']['size'] ?? null,
        'dropbox'
    ]);

    $mediaId[]= $this->db->lastInsertId();
}

return [
    'success'=>true,
    'mediaId'=>$mediaId,
    'result'=>$results
    ];
  
}

public function deleteImage()
{
    $data = $this->input();
    $id   = isset($data['id']) ? (int)$data['id'] : 0;

    // Strict validation
    if ($id <= 0) {
        return $this->json([
            'success' => false,
            'message' => 'Invalid image ID'
        ], 400);
    }

    // 1. Fetch image
    $stmt = $this->db->prepare("SELECT storage, id, url, path FROM media_images WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return $this->json([
            "success" => false,
            "message" => "Image not found"
        ], 404);
    }

    // 2. Delete file
    $this->db->beginTransaction();

    try {
        if ($row['storage']==='dropbox') {
            $res = $this->deleteFromDropbox($row['path']);
        } else if( $row['storage']==='cloudflare'){
        $res=$this->deleteFromCloudflare( $row['path'] );
        
}else {
            $res = $this->deleteLocalImages($row['path']);
        }
       $this->db->commit();
    } catch (\Throwable $e) {
    	      if ($this->db->inTransaction()) {
            $this->db->rollBack();
        }
    error_log($e->getMessage());
        $this->json([
            "success" => false,
            "message" => "Delete failed"
        ], 500);
    }

    // 3. If file deletion failed → stop
    if (empty($res['success'])) {
        return $this->json([
            "success" => false,
            "message" => $res['message'] ?? 'Unable to delete file'
        ], 500);
    }

    // 4. Delete DB record
    $stmt = $this->db->prepare("DELETE FROM media_images WHERE id = ?");
    $stmt->execute([$id]);

    return $this->json([
        'success' => true,
        'message' => 'Image deleted successfully'
    ]);
}

public function deleteLocalImages($path)
{
    $path = $this->site_dir() . "/$path";

    $paths = [
        $path,
        str_replace("original","large", $path),
        str_replace("original","medium", $path),
        str_replace("original","thumb", $path),
    ];

    $deleted = [];

    foreach ($paths as $path) {
        if (file_exists($path)) {
            if (@unlink($path)) {
                $deleted[] = $path;
            }
        }
    }

    return [
        "success" => true,
        "deleted" => $deleted
    ];
}

function deleteFromCloudflare($path){
	
	$set=$this->AppSettings['cloudflare'];   
          
     $accountId=$set['account_id']??'';     
     $accessKey= $set['access_key']??'';
$secretKey =$set['secret_key']??'';
    $bucket=$set['bucket']??''; 
    $endpoint  =$set['endpoint']??'';
    $publicUrl=$set['public_url']??'';
        
$cloudflare=new CloudFlare( $accountId, $accessKey, $secretKey, $bucket, $endpoint, $publicUrl);

	 $result= $cloudflare->delete($path );
	return $result;
}


public function deleteFromDropbox($path)
{
    $token = $this->getDropboxAccessToken(); // your cached token function

    $ch = curl_init("https://api.dropboxapi.com/2/files/delete_v2");

    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer $token",
        "Content-Type: application/json"
    ]);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        "path" => $path
    ]));

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response, true);

    if (isset($data['metadata'])) {
        return ["success" => true];
    }

    return [
        "success" => false,
        "message" => $data
    ];
}


public function safeExecute($stmt, $params = []) {
    try {
        $stmt->execute($params);
        return true;
    } catch (PDOException $e) {
        error_log($e->getMessage());
        return false;
    }
}

public function getUserIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }

    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }

    return $_SERVER['REMOTE_ADDR'] ?? null;
 }
 
 
 //CRON JOBS
public function updatePopularity(){
	$key='updatePopularity';
	$cron = $this->cache->get($key, ['namespace'=>'crons'] );       
	
	if( $cron) return; //Stop
  	try{
    // 1. Create a temporary "shadow" table
    // This ensures the live site isn't affected during calculation
    $this->db->exec("CREATE TABLE IF NOT EXISTS product_popularity_temp LIKE product_popularity");
    $this->db->exec("TRUNCATE TABLE product_popularity_temp");

    // 2. Calculate views for the last 7 days and insert into the temp table
    // This is the "Heavy Lift"
    $insertSql = "
        INSERT INTO product_popularity_temp (product_id, view_count)
        SELECT product_id, COUNT(*)
        FROM product_views
        WHERE created_at >= NOW() - INTERVAL 7 DAY
        GROUP BY product_id
    ";
    $this->db->exec($insertSql);

    // 3. Atomic Swap
    // This replaces the old data with new data in a fraction of a second
    $this->db->exec("RENAME TABLE product_popularity TO product_popularity_old, 
                             product_popularity_temp TO product_popularity, 
                             product_popularity_old TO product_popularity_temp");

    // "Trending data updated successfully at " . date('Y-m-d H:i:s') . "\n";

$this->cache->set($key, date('Y-m-d H:i:s'), ['namespace'=>'crons', 'tags'=>['crons_job'], 'ttl'=>(60*60) ]);

} catch (\PDOException $e) {
    error_log("Cron Error: " . $e->getMessage());
   return 1;
    }
  }
 
 public function emailVerificationMessage($verificationLink, $expiryTime = '24 hours')
{
    $subject = "Verify Your Email Address";

    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Verify Email</title>
    </head>
    <body style="margin:0;padding:0;background:#f5f7fb;font-family:Arial,sans-serif;">
        <table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f7fb;padding:40px 20px;">
            <tr>
                <td align="center">
                    <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:10px;overflow:hidden;">
                        
                        <tr>
                            <td style="background:#0f172a;padding:25px;text-align:center;color:#fff;font-size:22px;font-weight:bold;">
                                Email Verification
                            </td>
                        </tr>

                        <tr>
                            <td style="padding:35px;color:#334155;">
                                
                                <h2 style="margin-top:0;color:#111827;">Verify Your Email Address</h2>

                                <p style="font-size:15px;line-height:1.6;">
                                    Please verify your email to activate your account and start using the API platform.
                                </p>

                                <div style="text-align:center;margin:30px 0;">
                                    <a href="'.$verificationLink.'" 
                                       style="background:#0ea5e9;color:#fff;text-decoration:none;padding:14px 28px;
                                       border-radius:6px;font-weight:bold;display:inline-block;">
                                       Verify Email
                                    </a>
                                </div>

                                <p style="font-size:14px;color:#64748b;">
                                    If the button does not work, copy and paste this link:
                                </p>

                                <p style="font-size:13px;color:#0ea5e9;word-break:break-all;">
                                    '.$verificationLink.'
                                </p>

                                <p style="font-size:13px;color:#64748b;margin-top:25px;">
                                    This link will expire in <strong>'.$expiryTime.'</strong>.
                                </p>

                                <p style="font-size:13px;color:#64748b;">
                                    If you did not create an account, you can ignore this email.
                                </p>

                            </td>
                        </tr>

                        <tr>
                            <td style="background:#f8fafc;text-align:center;padding:18px;font-size:12px;color:#94a3b8;">
                                &copy; ' . $this->siteName . '. All rights reserved.
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </body>
    </html>';

    return [
        'subject' => $subject,
        'message' => $message
    ];
}

public function updateSoftware(){
    try {

        $data = $this->input();

        $zipUrl = trim($data['url'] ?? '');

        if (empty($zipUrl)) {
            return $this->json([
                'success' => false,
                'message' => 'Software location empty'
            ], 400);
        }

        $zipFile = $this->site_dir() . '/update.temp.zip';

        // Download update
        $read = fopen($zipUrl, 'rb');

        if (!$read) {
            throw new Exception('Unable to download update.');
        }

        $write = fopen($zipFile, 'wb');

        while (!feof($read)) {
            fwrite($write, fread($read, 8192));
        }

        fclose($read);
        fclose($write);

        if (!file_exists($zipFile) || filesize($zipFile) == 0) {
            throw new Exception('Downloaded file is invalid.');
        }

  $htaccess=$this->site_dir() . '/.htaccess';
   $backup = $this->site_dir() . '/.htaccess.' . date('Y-m-d_His') . '.bak';

if( file_exists($htaccess) ){
   if (!copy($htaccess, $backup)) {
        throw new Exception(
            'Unable to create .htaccess backup before update.'
        );
    }
}

        $zip = new ZipArchive();

        if ($zip->open($zipFile) !== TRUE) {
            throw new Exception('Invalid update package.');
        }

        if (!$zip->extractTo($this->site_dir() . '/tezt')) {
            $zip->close();
            throw new Exception('Failed to extract update.');
        }

        $zip->close();

        unlink($zipFile);

        return $this->json([
            'success' => true,
            'message' => 'Software updated successfully.'
        ]);

    } catch (Exception $e) {

        if (isset($zipFile) && file_exists($zipFile)) {
            unlink($zipFile);
        }

        return $this->json([
            'success' => false,
            'message' => $e->getMessage()
        ], 500);
    }
}


public function isBot() {

    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

    if ($ua === '') return true; // suspicious

    // common bot patterns
    $botPatterns = [
        'bot', 'crawl', 'spider', 'slurp', 'fetch', 'preview', 'monitor'
    ];

    foreach ($botPatterns as $pattern) {
        if (stripos($ua, $pattern) !== false) {
            return true;
        }
    }

    return false;
  } 
}
<?php

header('Content-Type: application/json');

function jsonResponse($success, $message, $extra = []) {
    echo json_encode(array_merge([
        'success' => $success,
        'message' => $message
    ], $extra));
    exit;
}


if(!file_exists(__DIR__ . "/../api/config/config.php") ){
	http_response_code(403);
    jsonResponse(false, 'Config.php not found.');
	}
	
require(__DIR__ . "/../api/config/config.php");

$pdo = $conn;

function clean_string($value) {
    return trim(filter_var($value, FILTER_SANITIZE_SPECIAL_CHARS));
}

// Collect input
$username = clean_string(strtolower($_POST['user'] ?? ''));
$emailRaw = trim($_POST['email'] ?? '');
$password = $_POST['pass'] ?? '';

// Validate
if ($username === '' || $emailRaw === '' || $password === '') {
    jsonResponse(false, 'All fields are required');
}

// Validate email
$email = filter_var($emailRaw, FILTER_VALIDATE_EMAIL);
if (!$email) {
    jsonResponse(false, 'Invalid email address');
}

// Username format
if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $username)) {
    jsonResponse(false, 'Invalid username format');
}

try {

    // Check duplicate email
    $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ? OR username=? LIMIT 1");
    $stmt->execute([$email, $username]);
     $row = $stmt->fetch(PDO::FETCH_ASSOC);
     
    if ($row) {
    	if( strtolower($row['username'])==$username){
    	        jsonResponse(false, 'Username already exists');
    }
        jsonResponse(false, 'Email already exists');
    }

    // Hash password
    $hashedPass = password_hash($password, PASSWORD_DEFAULT);

    // Insert user
    $stmt = $pdo->prepare("
        INSERT INTO users (username, password, email, role)
        VALUES (?, ?, ?, ?)
    ");

    $stmt->execute([$username, $hashedPass, $email, 'administrator']);

    // Lock installer
    file_put_contents(__DIR__ . '/installed.lock', date("Y-m-d H:i:s"));

    jsonResponse(true, 'Installation complete');

} catch (PDOException $e) {
    http_response_code(500);
    jsonResponse(false, $e->getMessage());
}
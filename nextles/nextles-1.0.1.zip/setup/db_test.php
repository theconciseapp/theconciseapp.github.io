<?php
if (file_exists(__DIR__ . '/../api/config/config.php')) {
    http_response_code(403);
    exit('<div class="alert alert-danger">Installer is locked.</div>');
}

$required = ['host','user'];

foreach ($required as $field) {
    if (empty($_POST[$field])) {
       // http_response_code(422);
        exit("<div class='alert alert-danger'>Missing field: $field</div>");
    }
}


// helper
function row($label, $ok, $current, $required, $note = '') {
    $class = $ok ? 'success' : 'danger';
    $icon  = $ok ? '✔' : '✖';

    return "
    <tr class='table-$class'>
        <td>$icon $label</td>
        <td>$current</td>
        <td>$required</td>
        <td>$note</td>
    </tr>";
}

try {

    $pdo = new PDO(
        "mysql:host=".$_POST['host'],
        $_POST['user'],
        $_POST['pass'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    $dbChecks = '';

    // MySQL Version
    $version = $pdo->query("SELECT VERSION()")->fetchColumn();
    $mysqlOk = version_compare($version, '5.7', '>=');

    $dbChecks .= row(
        'MySQL Version',
        $mysqlOk,
        $version,
        '>= 5.7'
    );

    // InnoDB Check
    $engine = $pdo->query("SHOW ENGINES")->fetchAll(PDO::FETCH_ASSOC);
    $innodb = false;

    foreach ($engine as $e) {
        if ($e['Engine'] === 'InnoDB' && $e['Support'] !== 'NO') {
            $innodb = true;
            break;
        }
    }

    $dbChecks .= row(
        'InnoDB Engine',
        $innodb,
        $innodb ? 'Available' : 'Missing',
        'Required'
    );

    // Output
    echo '<div class="alert alert-success">Connection OK</div>';

    echo '
    <table class="table table-bordered table-sm mt-2">
        <thead>
            <tr>
                <th>Check</th>
                <th>Current</th>
                <th>Required</th>
                <th>Note</th>
            </tr>
        </thead>
        <tbody>
            '.$dbChecks.'
        </tbody>
    </table>';

} catch (Exception $e) {

    echo '<div class="alert alert-danger">';
    echo '<strong>Connection Failed:</strong><br>';
    echo htmlspecialchars($e->getMessage());
    echo '</div>';
}
-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 29, 2026 at 01:44 PM
-- Server version: 10.4.34-MariaDB
-- PHP Version: 8.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `full_description` text DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `icon` varchar(150) DEFAULT NULL,
  `status` tinyint(3) UNSIGNED DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `site_id`, `user_id`, `name`, `slug`, `description`, `full_description`, `parent_id`, `icon`, `status`, `created_at`) VALUES
(1, 'abcde', 1, 'Uncategorised', 'uncategorised', NULL, NULL, NULL, NULL, 1, '2026-04-05 15:01:31'),
(2, 'abcde', 1, 'Ankara', 'ankara', 'ggssvs', NULL, 0, 'fas fa-shirt', 1, '2026-04-05 15:04:19'),
(3, 'abcde', 1, 'Shoes', 'shoes', 'Shop shoes at unbeatable prices. Browse top brands, enjoy fast delivery, and secure checkout. Order now.', 'Shop shoes at unbeatable prices. Browse top brands, enjoy fast delivery, and secure checkout. Order now.', 0, 'fas fa-socks', 1, '2026-04-05 15:04:35'),
(4, 'abcde', 1, 'ffffdd', 'd348d02de94291c8', '', NULL, 0, NULL, 0, '2026-04-05 15:33:51'),
(5, 'abcde', 1, 'Oluseyi Ola', 'bafab78df3b151e9', 'wow', NULL, 0, NULL, 1, '2026-04-05 15:35:14');

-- --------------------------------------------------------

--
-- Table structure for table `job_queue`
--

CREATE TABLE `job_queue` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(50) NOT NULL,
  `priority` tinyint(4) DEFAULT 0,
  `payload` text NOT NULL,
  `status` enum('pending','processing','done','failed') DEFAULT 'pending',
  `attempts` tinyint(3) UNSIGNED DEFAULT 0,
  `max_attempts` tinyint(3) UNSIGNED DEFAULT 3,
  `available_at` datetime DEFAULT current_timestamp(),
  `locked_at` datetime DEFAULT NULL,
  `reserved_by` varchar(100) DEFAULT NULL,
  `last_error` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_queue`
--

INSERT INTO `job_queue` (`id`, `type`, `priority`, `payload`, `status`, `attempts`, `max_attempts`, `available_at`, `locked_at`, `reserved_by`, `last_error`, `created_at`, `updated_at`) VALUES
(12, 'log', 0, '[1,2,3,4,5,6]', 'done', 0, 3, '2026-05-01 08:07:39', '2026-05-01 08:26:32', 'worker_69f454af8d0be8.44818630', NULL, '2026-05-01 08:07:39', '2026-05-01 08:26:32'),
(60, 'email', 0, '{\"to\":\"oluseyi.bankole2021@gmail.com\",\"subject\":\"Verify Your Email Address\",\"body\":\"\\r\\n    <!DOCTYPE html>\\r\\n    <html>\\r\\n    <head>\\r\\n        <meta charset=\\\"UTF-8\\\">\\r\\n        <title>Verify Email<\\/title>\\r\\n    <\\/head>\\r\\n    <body style=\\\"margin:0;padding:0;background:#f5f7fb;font-family:Arial,sans-serif;\\\">\\r\\n        <table width=\\\"100%\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" style=\\\"background:#f5f7fb;padding:40px 20px;\\\">\\r\\n            <tr>\\r\\n                <td align=\\\"center\\\">\\r\\n                    <table width=\\\"600\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" style=\\\"background:#ffffff;border-radius:10px;overflow:hidden;\\\">\\r\\n                        \\r\\n                        <tr>\\r\\n                            <td style=\\\"background:#0f172a;padding:25px;text-align:center;color:#fff;font-size:22px;font-weight:bold;\\\">\\r\\n                                Email Verification\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n\\r\\n                        <tr>\\r\\n                            <td style=\\\"padding:35px;color:#334155;\\\">\\r\\n                                \\r\\n                                <h2 style=\\\"margin-top:0;color:#111827;\\\">Verify Your Email Address<\\/h2>\\r\\n\\r\\n                                <p style=\\\"font-size:15px;line-height:1.6;\\\">\\r\\n                                    Please verify your email to activate your account and start using the API platform.\\r\\n                                <\\/p>\\r\\n\\r\\n                                <div style=\\\"text-align:center;margin:30px 0;\\\">\\r\\n                                    <a href=\\\"http:\\/\\/localhost:8000\\/ecommerce\\/verify-email.php?id=OQ==&code=D2E5BC5B0E\\\" \\r\\n                                       style=\\\"background:#0ea5e9;color:#fff;text-decoration:none;padding:14px 28px;\\r\\n                                       border-radius:6px;font-weight:bold;display:inline-block;\\\">\\r\\n                                       Verify Email\\r\\n                                    <\\/a>\\r\\n                                <\\/div>\\r\\n\\r\\n                                <p style=\\\"font-size:14px;color:#64748b;\\\">\\r\\n                                    If the button does not work, copy and paste this link:\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#0ea5e9;word-break:break-all;\\\">\\r\\n                                    http:\\/\\/localhost:8000\\/ecommerce\\/verify-email.php?id=OQ==&code=D2E5BC5B0E\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#64748b;margin-top:25px;\\\">\\r\\n                                    This link will expire in <strong>24 hours<\\/strong>.\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#64748b;\\\">\\r\\n                                    If you did not create an account, you can ignore this email.\\r\\n                                <\\/p>\\r\\n\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n\\r\\n                        <tr>\\r\\n                            <td style=\\\"background:#f8fafc;text-align:center;padding:18px;font-size:12px;color:#94a3b8;\\\">\\r\\n                                &copy; Os Shop. All rights reserved.\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n                    <\\/table>\\r\\n                <\\/td>\\r\\n            <\\/tr>\\r\\n        <\\/table>\\r\\n    <\\/body>\\r\\n    <\\/html>\"}', 'done', 0, 3, '2026-05-25 12:36:24', NULL, NULL, NULL, '2026-05-25 12:36:24', '2026-05-25 12:38:10'),
(61, 'email', 0, '{\"to\":\"oluseyi.bankole2021@gmail.com\",\"subject\":\"Verify Your Email Address\",\"body\":\"\\r\\n    <!DOCTYPE html>\\r\\n    <html>\\r\\n    <head>\\r\\n        <meta charset=\\\"UTF-8\\\">\\r\\n        <title>Verify Email<\\/title>\\r\\n    <\\/head>\\r\\n    <body style=\\\"margin:0;padding:0;background:#f5f7fb;font-family:Arial,sans-serif;\\\">\\r\\n        <table width=\\\"100%\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" style=\\\"background:#f5f7fb;padding:40px 20px;\\\">\\r\\n            <tr>\\r\\n                <td align=\\\"center\\\">\\r\\n                    <table width=\\\"600\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" style=\\\"background:#ffffff;border-radius:10px;overflow:hidden;\\\">\\r\\n                        \\r\\n                        <tr>\\r\\n                            <td style=\\\"background:#0f172a;padding:25px;text-align:center;color:#fff;font-size:22px;font-weight:bold;\\\">\\r\\n                                Email Verification\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n\\r\\n                        <tr>\\r\\n                            <td style=\\\"padding:35px;color:#334155;\\\">\\r\\n                                \\r\\n                                <h2 style=\\\"margin-top:0;color:#111827;\\\">Verify Your Email Address<\\/h2>\\r\\n\\r\\n                                <p style=\\\"font-size:15px;line-height:1.6;\\\">\\r\\n                                    Please verify your email to activate your account and start using the API platform.\\r\\n                                <\\/p>\\r\\n\\r\\n                                <div style=\\\"text-align:center;margin:30px 0;\\\">\\r\\n                                    <a href=\\\"http:\\/\\/localhost:8000\\/ecommerce\\/verify-email.php?id=MTA=&code=638EC8CAA3\\\" \\r\\n                                       style=\\\"background:#0ea5e9;color:#fff;text-decoration:none;padding:14px 28px;\\r\\n                                       border-radius:6px;font-weight:bold;display:inline-block;\\\">\\r\\n                                       Verify Email\\r\\n                                    <\\/a>\\r\\n                                <\\/div>\\r\\n\\r\\n                                <p style=\\\"font-size:14px;color:#64748b;\\\">\\r\\n                                    If the button does not work, copy and paste this link:\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#0ea5e9;word-break:break-all;\\\">\\r\\n                                    http:\\/\\/localhost:8000\\/ecommerce\\/verify-email.php?id=MTA=&code=638EC8CAA3\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#64748b;margin-top:25px;\\\">\\r\\n                                    This link will expire in <strong>24 hours<\\/strong>.\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#64748b;\\\">\\r\\n                                    If you did not create an account, you can ignore this email.\\r\\n                                <\\/p>\\r\\n\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n\\r\\n                        <tr>\\r\\n                            <td style=\\\"background:#f8fafc;text-align:center;padding:18px;font-size:12px;color:#94a3b8;\\\">\\r\\n                                &copy; Os Shop. All rights reserved.\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n                    <\\/table>\\r\\n                <\\/td>\\r\\n            <\\/tr>\\r\\n        <\\/table>\\r\\n    <\\/body>\\r\\n    <\\/html>\"}', 'done', 0, 3, '2026-05-25 16:24:30', NULL, NULL, NULL, '2026-05-25 16:24:30', '2026-05-25 16:26:13'),
(62, 'email', 0, '{\"to\":\"oluseyi.bankole2021@gmail.com\",\"subject\":\"Verify Your Email Address\",\"body\":\"\\r\\n    <!DOCTYPE html>\\r\\n    <html>\\r\\n    <head>\\r\\n        <meta charset=\\\"UTF-8\\\">\\r\\n        <title>Verify Email<\\/title>\\r\\n    <\\/head>\\r\\n    <body style=\\\"margin:0;padding:0;background:#f5f7fb;font-family:Arial,sans-serif;\\\">\\r\\n        <table width=\\\"100%\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" style=\\\"background:#f5f7fb;padding:40px 20px;\\\">\\r\\n            <tr>\\r\\n                <td align=\\\"center\\\">\\r\\n                    <table width=\\\"600\\\" cellpadding=\\\"0\\\" cellspacing=\\\"0\\\" style=\\\"background:#ffffff;border-radius:10px;overflow:hidden;\\\">\\r\\n                        \\r\\n                        <tr>\\r\\n                            <td style=\\\"background:#0f172a;padding:25px;text-align:center;color:#fff;font-size:22px;font-weight:bold;\\\">\\r\\n                                Email Verification\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n\\r\\n                        <tr>\\r\\n                            <td style=\\\"padding:35px;color:#334155;\\\">\\r\\n                                \\r\\n                                <h2 style=\\\"margin-top:0;color:#111827;\\\">Verify Your Email Address<\\/h2>\\r\\n\\r\\n                                <p style=\\\"font-size:15px;line-height:1.6;\\\">\\r\\n                                    Please verify your email to activate your account and start using the API platform.\\r\\n                                <\\/p>\\r\\n\\r\\n                                <div style=\\\"text-align:center;margin:30px 0;\\\">\\r\\n                                    <a href=\\\"http:\\/\\/localhost:8000\\/ecommerce\\/verify-email.php?id=MTE=&code=BFC2695CC0\\\" \\r\\n                                       style=\\\"background:#0ea5e9;color:#fff;text-decoration:none;padding:14px 28px;\\r\\n                                       border-radius:6px;font-weight:bold;display:inline-block;\\\">\\r\\n                                       Verify Email\\r\\n                                    <\\/a>\\r\\n                                <\\/div>\\r\\n\\r\\n                                <p style=\\\"font-size:14px;color:#64748b;\\\">\\r\\n                                    If the button does not work, copy and paste this link:\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#0ea5e9;word-break:break-all;\\\">\\r\\n                                    http:\\/\\/localhost:8000\\/ecommerce\\/verify-email.php?id=MTE=&code=BFC2695CC0\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#64748b;margin-top:25px;\\\">\\r\\n                                    This link will expire in <strong>24 hours<\\/strong>.\\r\\n                                <\\/p>\\r\\n\\r\\n                                <p style=\\\"font-size:13px;color:#64748b;\\\">\\r\\n                                    If you did not create an account, you can ignore this email.\\r\\n                                <\\/p>\\r\\n\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n\\r\\n                        <tr>\\r\\n                            <td style=\\\"background:#f8fafc;text-align:center;padding:18px;font-size:12px;color:#94a3b8;\\\">\\r\\n                                &copy; Os Shop. All rights reserved.\\r\\n                            <\\/td>\\r\\n                        <\\/tr>\\r\\n                    <\\/table>\\r\\n                <\\/td>\\r\\n            <\\/tr>\\r\\n        <\\/table>\\r\\n    <\\/body>\\r\\n    <\\/html>\"}', 'done', 0, 3, '2026-05-25 16:33:06', NULL, NULL, NULL, '2026-05-25 16:33:06', '2026-05-25 16:34:14'),
(63, 'email', 0, '{\"to\":\"oshobbyenterprise@gmail.com\",\"subject\":\"Os Shop - Your Order Details - OSWS-36D408E3D2E3\",\"body\":\"\\r\\n    <!DOCTYPE html>\\r\\n    <html>\\r\\n    <head>\\r\\n        <meta charset=\\\"UTF-8\\\">\\r\\n        <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\r\\n        <title>Order Notification<\\/title>\\r\\n        <style>\\r\\n            body { font-family: Arial, sans-serif; background-color: #f9f9f9; margin: 0; padding: 0; }\\r\\n            .container { width: 100%; max-width: 600px; margin: 20px auto; background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 0 10px rgba(0,0,0,0.1);}\\r\\n            .header { background: #4CAF50; color: white; padding: 20px; text-align: center;}\\r\\n            .header img { max-height: 50px; margin-bottom: 10px; }\\r\\n            .content { padding: 20px; color: #333333; line-height: 1.5; }\\r\\n            .content h3 { margin-top: 0; }\\r\\n            .content p { margin: 5px 0; }\\r\\n            .content .metadata { background: #f1f1f1; padding: 10px; border-radius: 4px; margin-top: 10px; }\\r\\n            .footer { text-align: center; padding: 15px; font-size: 12px; color: #777777; background: #f9f9f9; }\\r\\n        <\\/style>\\r\\n    <\\/head>\\r\\n    <body>\\r\\n        <div class=\\\"container\\\">\\r\\n            <div class=\\\"header\\\">\\r\\n                <!--<img srcx=\\\"https:\\/\\/yourdomain.com\\/assets\\/logo.png\\\" alt=\\\"Company Logo\\\">-->\\r\\n                <h2>Order Details<\\/h2>\\r\\n            <\\/div>\\r\\n            <div class=\\\"content\\\">\\r\\n                \\r\\n              <p>  Hi Master Admin,<\\/p>\\r\\n<p>\\r\\nThank you for shopping on Os Shop, your order OSWS-36D408E3D2E3 has been confirmed!\\r\\n<\\/p>\\r\\n<p>\\r\\nWe will notify you once it is ready.\\r\\n<\\/p>\\r\\n                <p><strong>Order Id:<\\/strong> OSWS-36D408E3D2E3<\\/p>\\r\\n                <p><strong>Total Amount:<\\/strong> 17800 NGN<\\/p>\\r\\n                <p><strong>Status:<\\/strong> Pending<\\/p>\\r\\n                <p><strong>Date:<\\/strong> Monday, 25 May 2026, 07:57 PM<\\/p>\\r\\n\\r\\n                <h4>Personal Info<\\/h4>\\r\\n                <p><strong>Email:<\\/strong> oshobbyenterprise@gmail.com<\\/p>\\r\\n                <p><strong>Phone:<\\/strong> 09064732951<\\/p>\\r\\n                \\r\\n                <div class=\\\"metadata\\\"><h4>Additional Info<\\/h4>\\ud83d\\udce6 *SHOES*<br><br>- *Vie Shoe*<br>  \\u20a612,300 x 1<br>  Subtotal: \\u20a612,300<br><br><br>\\ud83d\\udce6 *UNCATEGORISED*<br><br>- *Nivea Cream*<br>  \\u20a65,500 x 1<br>  Subtotal: \\u20a65,500<br><br><br>\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501<br>\\ud83d\\udcb0 *TOTAL: \\u20a617,800*<br>\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\u2501\\r\\n            <\\/div>\\r\\n            <div class=\\\"footer\\\">\\r\\n                &copy; 2026 OsHobby All rights reserved.\\r\\n            <\\/div>\\r\\n        <\\/div>\\r\\n    <\\/body>\\r\\n    <\\/html>\\r\\n    \"}', 'done', 0, 3, '2026-05-25 19:57:25', NULL, NULL, NULL, '2026-05-25 19:57:25', '2026-05-25 19:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `media_images`
--

CREATE TABLE `media_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `mime_type` varchar(50) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `storage` enum('local','dropbox') DEFAULT 'local',
  `status` tinyint(4) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `media_images`
--

INSERT INTO `media_images` (`id`, `user_id`, `site_id`, `url`, `path`, `filename`, `description`, `mime_type`, `size`, `storage`, `status`, `created_at`) VALUES
(24, 1, 'abcde', 'https://www.dropbox.com/scl/fi/jdtfg52mzmnydsjxi075x/1776282781_IMG-20260331-WA0011.jpg?rlkey=pl9hw8a1mg7zacjwginoi074e&raw=1', '/os-shop/1776282781_img-20260331-wa0011.jpg', '1776282781_IMG-20260331-WA0011.jpg', 'Black Canvas', 'image/jpeg', 319675, 'dropbox', 1, '2026-04-15 19:53:20'),
(25, 1, 'abcde', 'http://localhost:8000/ecommerce/uploads/original/69dfecf2d8ce4_IMG-20260331-WA0010.jpg', 'uploads/original/69dfecf2d8ce4_IMG-20260331-WA0010.jpg', '69dfecf2d8ce4_IMG-20260331-WA0010.jpg', 'Puma Jacket', 'image/jpeg', 178452, 'local', 1, '2026-04-15 19:54:29'),
(26, 1, 'abcde', 'http://localhost:8000/ecommerce/uploads/original/69e0b3bac2e28_IMG-20260331-WA0015.jpg', 'uploads/original/69e0b3bac2e28_IMG-20260331-WA0015.jpg', '69e0b3bac2e28_IMG-20260331-WA0015.jpg', '', 'image/jpeg', 119269, 'local', 1, '2026-04-16 10:02:37'),
(27, 6, 'abcde', 'http://localhost:8000/ecommerce/uploads/original/69ef3051556d3_IMG-20260402-WA0006.jpg', 'uploads/original/69ef3051556d3_IMG-20260402-WA0006.jpg', '69ef3051556d3_IMG-20260402-WA0006.jpg', '', 'image/jpeg', 153864, 'local', 1, '2026-04-27 09:45:54'),
(28, 6, 'abcde', 'http://localhost:8000/ecommerce/uploads/original/69ef3051556d3_IMG-20260425-WA0030.jpg', 'uploads/original/69ef3051556d3_IMG-20260425-WA0030.jpg', '69ef3051556d3_IMG-20260425-WA0030.jpg', '', 'image/jpeg', 100255, 'local', 1, '2026-04-27 09:45:55'),
(29, 3, 'abcde', 'http://localhost:8000/ecommerce/uploads/original/69f0be69746dd_IMG-20260331-WA0011.jpg', 'uploads/original/69f0be69746dd_IMG-20260331-WA0011.jpg', '69f0be69746dd_IMG-20260331-WA0011.jpg', '', 'image/jpeg', 145180, 'local', 1, '2026-04-28 14:04:28'),
(30, 3, 'abcde', 'http://localhost:8000/ecommerce/uploads/original/69f0bebf2d0fe_IMG-20260331-WA0009.jpg', 'uploads/original/69f0bebf2d0fe_IMG-20260331-WA0009.jpg', '69f0bebf2d0fe_IMG-20260331-WA0009.jpg', '', 'image/jpeg', 158884, 'local', 1, '2026-04-28 14:05:53');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `ref_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `slug` varchar(150) DEFAULT NULL,
  `icon` varchar(150) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  `type` enum('page','category','custom') NOT NULL DEFAULT 'custom',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `site_id`, `ref_id`, `title`, `slug`, `icon`, `status`, `type`, `created_at`, `updated_at`) VALUES
(1, 'abcde', 0, 'Child', 'https://oshobby.com.ng', 'fas fa-book', 1, 'custom', '2026-04-29 07:31:21', '2026-04-30 09:37:32'),
(2, 'abcde', 0, 'About Us', 'about-us', '', 1, 'custom', '2026-04-29 07:31:21', '2026-04-30 14:50:02'),
(3, 'abcde', 0, 'Orders', 'orders', NULL, 1, 'custom', '2026-04-29 05:13:46', '2026-04-30 05:36:55'),
(4, 'abcde', 0, 'Contact Us', 'contact-us', NULL, 1, 'custom', '2026-04-29 07:31:21', '2026-04-30 05:36:55'),
(77, 'abcde', 2, '', '', NULL, 1, 'category', '2026-04-29 18:04:19', '2026-04-30 05:36:55'),
(78, 'abcde', 3, 'Shoes', 'shoes', NULL, 1, 'category', '2026-04-29 21:19:29', '2026-04-30 05:36:55'),
(80, 'abcde', NULL, 'linkCustom', 'https://oshobby.com.ng', '', 1, 'custom', '2026-04-29 22:18:06', '2026-04-30 09:29:39'),
(81, 'abcde', 2, NULL, NULL, NULL, 1, 'page', '2026-04-29 22:20:29', '2026-04-30 05:36:55'),
(82, 'abcde', 1, NULL, NULL, NULL, 1, 'page', '2026-04-29 22:20:29', '2026-04-30 05:36:55'),
(83, 'abcde', 7, NULL, NULL, NULL, 1, 'page', '2026-05-06 08:48:05', '2026-05-06 08:48:05'),
(84, 'abcde', 8, NULL, NULL, NULL, 1, 'page', '2026-05-06 08:48:05', '2026-05-06 08:48:05');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `menu_id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT 0,
  `position` int(11) DEFAULT 0,
  `admin_only` tinyint(4) DEFAULT 0,
  `logged_only` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `menu_key` varchar(50) NOT NULL DEFAULT 'main'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `site_id`, `menu_id`, `parent_id`, `position`, `admin_only`, `logged_only`, `created_at`, `updated_at`, `menu_key`) VALUES
(223, 'abcde', 8, NULL, 0, 0, 0, '2026-05-06 08:49:48', '2026-05-06 08:49:48', 'header'),
(224, 'abcde', 81, NULL, 1, 0, 0, '2026-05-06 08:49:48', '2026-05-06 08:49:48', 'header'),
(225, 'abcde', 82, NULL, 2, 0, 0, '2026-05-06 08:49:48', '2026-05-06 08:49:48', 'header'),
(226, 'abcde', 77, NULL, 3, 0, 0, '2026-05-06 08:49:48', '2026-05-06 08:49:48', 'header'),
(227, 'abcde', 78, NULL, 4, 0, 0, '2026-05-06 08:49:48', '2026-05-06 08:49:48', 'header'),
(263, 'abcde', 81, NULL, 0, 0, 0, '2026-05-06 09:48:02', '2026-05-06 09:48:02', 'footer'),
(264, 'abcde', 83, NULL, 1, 0, 0, '2026-05-06 09:48:02', '2026-05-06 09:48:02', 'footer'),
(265, 'abcde', 84, NULL, 2, 0, 0, '2026-05-06 09:48:02', '2026-05-06 09:48:02', 'footer');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_uid` varchar(50) NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_address` text DEFAULT NULL,
  `customer_state` varchar(50) DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled','expired') NOT NULL DEFAULT 'pending',
  `total_amount` decimal(12,2) NOT NULL,
  `currency` varchar(10) DEFAULT 'NGN',
  `payment_method` enum('online','transfer','pod','wallet') DEFAULT NULL,
  `payment_reference` varchar(100) DEFAULT NULL,
  `payment_status` enum('unpaid','pending','paid','failed','refunded','partially_refunded') NOT NULL DEFAULT 'unpaid',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_uid`, `site_id`, `user_id`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `customer_state`, `session_id`, `status`, `total_amount`, `currency`, `payment_method`, `payment_reference`, `payment_status`, `created_at`, `updated_at`) VALUES
(16, 'OSWS-4C7CFBC0ED2B', 'abcde', 1, 'Master Admin', '09064732951', 'oshobbyenterprise@gmail.com', 'Abeokuta\nAbeokuta Ogun state', 'Ogun', NULL, 'pending', 20600.00, 'NGN', 'pod', 'OSR-20260526153135-D16455FF', 'unpaid', '2026-05-26 15:31:35', '2026-05-28 21:33:31'),
(17, 'OSWS-EBFF1053331A', 'abcde', 1, 'Master Admin', '09064732951', 'oshobbyenterprise@gmail.com', 'Abeokuta\nAbeokuta Ogun state', NULL, NULL, 'pending', 6500.00, 'NGN', 'online', 'OSR-20260529092553-9744AAB2', 'unpaid', '2026-05-29 09:25:53', '2026-05-29 09:25:53'),
(18, 'OSWS-6F45C6F7F207', 'abcde', 1, 'Master Admin', '09064732951', 'oshobbyenterprise@gmail.com', 'Abeokuta\nAbeokuta Ogun state', NULL, NULL, 'pending', 5000.00, 'NGN', 'online', 'OSR-20260529093641-145397D3', 'unpaid', '2026-05-29 09:36:41', '2026-05-29 09:36:41');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`, `total`, `created_at`) VALUES
(56, 16, 4, 2, 10300.00, 20600.00, '2026-05-28 21:36:51'),
(57, 17, 3, 1, 5500.00, 5500.00, '2026-05-29 09:25:53'),
(58, 17, 2, 1, 1000.00, 1000.00, '2026-05-29 09:25:53'),
(59, 18, 1, 1, 5000.00, 5000.00, '2026-05-29 09:36:41');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(191) NOT NULL,
  `content` longtext DEFAULT NULL,
  `icon` varchar(150) DEFAULT NULL,
  `status` enum('draft','published','deleted') DEFAULT 'draft',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `site_id`, `title`, `slug`, `content`, `icon`, `status`, `description`, `created_at`, `updated_at`) VALUES
(1, 'abcde', 'About Us', 'about-us', '<div class=\"row mt-3 mb-2\">\n    <div class=\"col-md-6\">\n      <p>\n        Welcome to <strong>Your Store Name</strong>, your trusted destination for stylish clothing, \n        quality footwear, elegant wristwatches, and everyday essentials.\n      </p>\n      <p>\n        We are passionate about helping you look good and feel confident without breaking the bank. \n        Our collections are carefully curated to combine modern trends, comfort, durability, \n        and affordability — all in one place.\n      </p>\n      <p>\n        At <strong>Your Store Name</strong>, we believe fashion is more than just appearance; \n        it’s a statement of personality. That’s why we offer a wide range of products designed \n        to suit different styles, occasions, and lifestyles.\n      </p>\n    </div>\n\n    <div class=\"col-md-6\">\n      <h4 class=\"mt-4 mt-md-0\">What We Offer</h4>\n      <ul class=\"list-unstyled\">\n        <li>✔ Trendy and classic clothing for all occasions</li>\n        <li>✔ Durable and stylish shoes</li>\n        <li>✔ Premium wristwatches that elevate your look</li>\n        <li>✔ A variety of accessories and essentials</li>\n      </ul>\n\n      <h4 class=\"mt-4\">Why Choose Us?</h4>\n      <ul class=\"list-unstyled\">\n        <li>✔ High-quality products</li>\n        <li>✔ Affordable prices</li>\n        <li>✔ Fast and reliable delivery</li>\n        <li>✔ Excellent customer support</li>\n      </ul>\n    </div>\n  </div>\n', NULL, 'published', 'About Us', '2026-04-25 09:31:50', '2026-05-06 07:37:41'),
(2, 'abcde', 'Contact us', 'contact-us', '<div class=\"text-left mt-3 mb-5\">\n    <p class=\"text-muted\">We’re here to help. Reach out anytime.</p>\n  </div>\n  \n  <div class=\"row\">\n\n    <!-- Contact Info -->\n    <div class=\"col-lg-5 mb-4\">\n      <h4>Get in Touch</h4>\n\n      <p id=\"business-contact-info\"></p>\n    </div>\n\n    <!-- Contact Form -->\n    <div class=\"col-lg-7\">\n      <form id=\"contactForm\" novalidate>\n        \n        <div class=\"row\">\n          <div class=\"col-md-6 mb-3\">\n            <input type=\"text\" id=\"name\" class=\"form-control\" placeholder=\"Your Name\" autocomplete=\"on\">\n            <small class=\"text-danger\" id=\"nameError\"></small>\n          </div>\n          <div class=\"col-md-6 mb-3\">\n            <input type=\"email\" id=\"email\" class=\"form-control\" placeholder=\"Your Email\" autocomplete=\"on\">\n            <small class=\"text-danger\" id=\"emailError\"></small>\n          </div>\n        </div>\n\n        <div class=\"mb-3\">\n          <input type=\"text\" id=\"subject\" class=\"form-control\" placeholder=\"Subject\">\n          <small class=\"text-danger\" id=\"subjectError\"></small>\n        </div>\n\n        <div class=\"mb-3\">\n          <textarea id=\"message\" class=\"form-control\" rows=\"5\" placeholder=\"Your Message\"></textarea>\n          <small class=\"text-danger\" id=\"messageError\"></small>\n        </div>\n\n        <button type=\"submit\" class=\"btn btn-dark w-100\">\n          <i class=\"fab fa-whatsapp me-2\"></i> Send via WhatsApp\n        </button>\n\n      </form>\n    </div>\n\n<script>\npopulateContactPage();\n</script>', NULL, 'published', 'Contact us', '2026-04-26 05:53:50', '2026-05-06 07:31:04'),
(7, 'abcde', 'Privacy Policy', 'privacy-policy', '<section class=\"container\">\n  <div class=\"row justify-content-center\">\n    <div class=\"col-lg-10\">\n\n      <div class=\"card shadow-sm border-0\">\n        <div class=\"card-body p-4 p-md-5\">\n\n          <h1 class=\"mb-3 fw-bold\">Privacy Policy</h1>\n          <p class=\"text-muted\">Effective Date: [Insert Date]</p>\n\n          <p>\n            At <strong>[Your Store Name]</strong>, we value your privacy. This Privacy Policy explains how we collect,\n            use, and protect your information when you use our website.\n          </p>\n\n          <hr>\n\n          <h5 class=\"mt-4\">1. Information We Collect</h5>\n\n          <h6 class=\"mt-3\">Personal Information</h6>\n          <ul>\n            <li>Full name</li>\n            <li>Email address</li>\n            <li>Phone number</li>\n            <li>Billing and shipping address</li>\n          </ul>\n\n          <h6 class=\"mt-3\">Non-Personal Information</h6>\n          <ul>\n            <li>IP address</li>\n            <li>Browser type</li>\n            <li>Device information</li>\n            <li>Pages visited and usage data</li>\n          </ul>\n\n          <h6 class=\"mt-3\">Cookies</h6>\n          <p>\n            We use cookies to improve your browsing experience, remember preferences, and analyze traffic.\n            You can disable cookies in your browser settings.\n          </p>\n\n          <h5 class=\"mt-4\">2. How We Use Your Information</h5>\n          <ul>\n            <li>Process and deliver orders</li>\n            <li>Manage your account</li>\n            <li>Send updates and notifications</li>\n            <li>Improve our services</li>\n            <li>Prevent fraud and enhance security</li>\n          </ul>\n\n          <h5 class=\"mt-4\">3. Sharing Your Information</h5>\n          <p>We do not sell your personal data. We may share it with:</p>\n          <ul>\n            <li>Payment processors</li>\n            <li>Shipping partners</li>\n            <li>Analytics and hosting providers</li>\n          </ul>\n\n          <h5 class=\"mt-4\">4. Data Security</h5>\n          <p>\n            We implement security measures such as encryption and secure servers to protect your data.\n            However, no system is completely secure.\n          </p>\n\n          <h5 class=\"mt-4\">5. Data Retention</h5>\n          <p>\n            We retain your data only as long as necessary for business and legal purposes.\n          </p>\n\n          <h5 class=\"mt-4\">6. Your Rights</h5>\n          <ul>\n            <li>Access your personal data</li>\n            <li>Request correction or deletion</li>\n            <li>Opt out of marketing communications</li>\n          </ul>\n\n          <h5 class=\"mt-4\">7. Third-Party Links</h5>\n          <p>\n            Our site may contain links to third-party websites. We are not responsible for their privacy practices.\n          </p>\n\n          <h5 class=\"mt-4\">8. Children’s Privacy</h5>\n          <p>\n            We do not knowingly collect data from children under applicable legal age.\n          </p>\n\n          <h5 class=\"mt-4\">9. Changes to This Policy</h5>\n          <p>\n            We may update this Privacy Policy from time to time. Changes will be posted on this page.\n          </p>\n\n          <h5 class=\"mt-4\">10. Contact Us</h5>\n          <p>\n            Email: <a href=\"mailto:[Your Email]\">[Your Email]</a><br>\n            Phone: [Your Phone Number]<br>\n            Address: [Your Business Address]\n          </p>\n\n        </div>\n      </div>\n\n    </div>\n  </div>\n</section>', NULL, 'published', 'Your privacy matters. Discover how {{siteName}} safeguards your data, processes payments securely, and respects your privacy rights.', '2026-05-06 08:39:42', '2026-05-25 16:10:49'),
(8, 'abcde', 'Term & Conditions', 'terms', ' <div class=\"row justify-content-center\">\n    <div class=\"col-lg-10\">\n      \n      <div class=\"card shadow-sm border-0\">\n        <div class=\"card-body p-4 p-md-5\">\n\n          <h1 class=\"mb-3 fw-bold\">Terms & Conditions</h1>\n          <p class=\"text-muted\">Effective Date: [Insert Date]</p>\n\n          <p>\n            Welcome to <strong>[Your Store Name]</strong>. By accessing or using our website,\n            you agree to be bound by these Terms & Conditions. If you do not agree, please do not use our services.\n          </p>\n\n          <hr>\n\n          <h5 class=\"mt-4\">1. Eligibility</h5>\n          <ul>\n            <li>You must be at least 18 years old or use under supervision.</li>\n            <li>You agree to comply with all applicable laws.</li>\n          </ul>\n\n          <h5 class=\"mt-4\">2. Account Registration</h5>\n          <ul>\n            <li>Provide accurate and complete information</li>\n            <li>Keep your login credentials secure</li>\n            <li>You are responsible for activities under your account</li>\n          </ul>\n\n          <h5 class=\"mt-4\">3. Products and Services</h5>\n          <p>\n            We strive for accuracy in product descriptions and pricing. However,\n            errors may occur and we reserve the right to correct them at any time.\n          </p>\n\n          <h5 class=\"mt-4\">4. Pricing and Payments</h5>\n          <ul>\n            <li>Prices are listed in [Currency]</li>\n            <li>Payments are processed via secure third-party providers</li>\n            <li>We may cancel orders due to fraud or pricing errors</li>\n          </ul>\n\n          <h5 class=\"mt-4\">5. Orders and Acceptance</h5>\n          <p>\n            Orders are subject to acceptance. We reserve the right to refuse or cancel any order.\n          </p>\n\n          <h5 class=\"mt-4\">6. Shipping and Delivery</h5>\n          <ul>\n            <li>Delivery times are estimates</li>\n            <li>We are not responsible for carrier delays</li>\n            <li>Risk transfers upon delivery</li>\n          </ul>\n\n          <h5 class=\"mt-4\">7. Returns and Refunds</h5>\n          <p>\n            Please refer to our <a href=\"#\">Return & Refund Policy</a> for full details.\n          </p>\n\n          <h5 class=\"mt-4\">8. Intellectual Property</h5>\n          <p>\n            All website content (text, images, logos) is owned by <strong>[Your Store Name]</strong>\n            and protected by copyright laws.\n          </p>\n\n          <h5 class=\"mt-4\">9. Prohibited Activities</h5>\n          <ul>\n            <li>Using the site for unlawful purposes</li>\n            <li>Attempting unauthorized access</li>\n            <li>Uploading harmful code</li>\n          </ul>\n\n          <h5 class=\"mt-4\">10. Limitation of Liability</h5>\n          <p>\n            We are not liable for indirect or consequential damages. Liability is limited to the purchase amount.\n          </p>\n\n          <h5 class=\"mt-4\">11. Disclaimer</h5>\n          <p>\n            All services are provided “as is” without warranties of any kind.\n          </p>\n\n          <h5 class=\"mt-4\">12. Termination</h5>\n          <p>\n            We may suspend or terminate your access at any time for violations.\n          </p>\n\n          <h5 class=\"mt-4\">13. Governing Law</h5>\n          <p>\n            These Terms are governed by the laws of [Your Country/State].\n          </p>\n\n          <h5 class=\"mt-4\">14. Changes to Terms</h5>\n          <p>\n            We may update these Terms at any time. Continued use means acceptance of changes.\n          </p>\n\n          <h5 class=\"mt-4\">15. Contact Information</h5>\n          <p>\n            Email: <a href=\"mailto:[Your Email]\">[Your Email]</a><br>\n            Phone: [Your Phone Number]<br>\n            Address: [Your Business Address]\n          </p>\n\n        </div>\n      </div>\n\n    </div>\n</div>', NULL, 'published', 'Terms &amp;amp;amp; Conditions\n          Effective Date: [Insert Date]\n\n          \n            Welcome to [Your Store Name]. By accessing or using our website,\n', '2026-05-06 08:44:40', '2026-05-29 11:29:44');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token_hash`, `expires_at`, `created_at`) VALUES
(7, 1, '$2y$10$38s6Yaefk2JaJ4Sev87JX.GyAkDlTAkJqSfWqFERw3.HWV4GGHyfy', '2026-05-25 11:03:23', '2026-05-25 09:03:23');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `full_description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `stock_status` enum('in_stock','out_of_stock','backorder') DEFAULT 'in_stock',
  `image` varchar(500) DEFAULT NULL,
  `gallery` text DEFAULT NULL,
  `brand_id` bigint(20) UNSIGNED DEFAULT NULL,
  `weight` decimal(8,2) DEFAULT NULL,
  `dimensions` varchar(100) DEFAULT NULL,
  `status` enum('active','inactive','draft') DEFAULT 'active',
  `featured_rank` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `has_discount` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `site_id`, `user_id`, `name`, `slug`, `description`, `full_description`, `price`, `sale_price`, `cost_price`, `sku`, `stock_quantity`, `stock_status`, `image`, `gallery`, `brand_id`, `weight`, `dimensions`, `status`, `featured_rank`, `created_at`, `updated_at`, `has_discount`) VALUES
(1, 'abcde', 1, 'Puma Jacket', 'puma', 'Nice Puma Jacket', 'Nice Puma Jacket', 9000.00, 5000.00, NULL, NULL, 4984, 'in_stock', NULL, NULL, NULL, NULL, NULL, 'active', 5, '2026-04-05 20:43:11', '2026-05-29 08:36:41', 1),
(2, 'abcde', 1, 'Gucci Canvas Shoe', 'gucci-canvas', 'hello', 'hello', 1000.00, NULL, 50.00, NULL, 2099, 'in_stock', NULL, NULL, NULL, NULL, NULL, 'active', 1, '2026-04-06 05:22:34', '2026-05-29 08:25:53', 0),
(3, 'abcde', 1, 'Nivea Cream', 'nivea-cream', 'short seo description', 'Full descriptionz', 5500.00, NULL, 4000.00, NULL, 986, 'in_stock', NULL, NULL, NULL, NULL, NULL, 'active', 3, '2026-04-07 21:12:21', '2026-05-29 08:25:53', 0),
(4, 'abcde', 1, 'Vie Shoe', 'vie-shoe', 'Nice vie-shoe', 'Full nice vie shoe', 15000.00, 12300.00, 13000.00, NULL, 310, 'in_stock', NULL, NULL, NULL, NULL, NULL, 'active', 0, '2026-04-11 16:53:50', '2026-05-26 14:31:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`product_id`, `category_id`) VALUES
(1, 1),
(2, 1),
(2, 3),
(3, 1),
(4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `media_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `media_id`, `position`, `is_featured`, `created_at`) VALUES
(26, 1, 25, 0, 0, '2026-04-28 09:58:23'),
(27, 2, 29, 0, 0, '2026-04-28 14:04:51'),
(28, 4, 30, 0, 0, '2026-04-28 14:06:12'),
(37, 3, 26, 0, 0, '2026-05-05 16:02:41'),
(38, 3, 28, 0, 0, '2026-05-05 16:02:41');

-- --------------------------------------------------------

--
-- Table structure for table `product_popularity`
--

CREATE TABLE `product_popularity` (
  `product_id` int(11) NOT NULL,
  `view_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_popularity`
--

INSERT INTO `product_popularity` (`product_id`, `view_count`) VALUES
(2, 1),
(3, 2),
(4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `product_popularity_temp`
--

CREATE TABLE `product_popularity_temp` (
  `product_id` int(11) NOT NULL,
  `view_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_popularity_temp`
--

INSERT INTO `product_popularity_temp` (`product_id`, `view_count`) VALUES
(4, 1),
(3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_variants`
--

CREATE TABLE `product_variants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `sku` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `attributes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_views`
--

CREATE TABLE `product_views` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_views`
--

INSERT INTO `product_views` (`id`, `product_id`, `user_id`, `session_id`, `ip_address`, `created_at`) VALUES
(1, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-12 16:00:49'),
(2, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-12 16:01:40'),
(3, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-13 07:32:23'),
(4, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-13 08:07:34'),
(5, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 07:39:24'),
(6, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 07:40:49'),
(7, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 08:25:38'),
(8, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 09:03:07'),
(9, 2, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 10:47:09'),
(10, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 11:44:57'),
(11, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 14:21:05'),
(12, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 14:46:38'),
(13, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-14 20:08:41'),
(14, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-15 04:52:45'),
(15, 2, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-15 05:10:29'),
(16, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-15 07:44:32'),
(17, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-15 07:45:44'),
(18, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 07:20:08'),
(19, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 07:22:27'),
(20, 2, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 07:22:40'),
(21, 1, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 07:22:56'),
(22, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 10:59:51'),
(23, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 19:39:13'),
(24, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 20:02:38'),
(25, 3, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 20:52:12'),
(26, 2, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 21:08:25'),
(27, 4, NULL, '2054cdd9d3eb4ff6b0cfd773700ce3ab', '::1', '2026-04-16 21:13:50'),
(28, 4, NULL, '71d4dff81db58d5d461d3bda26cedb4c', '::1', '2026-04-17 14:59:49'),
(29, 3, NULL, '71d4dff81db58d5d461d3bda26cedb4c', '::1', '2026-04-17 14:59:53'),
(30, 1, NULL, '71d4dff81db58d5d461d3bda26cedb4c', '::1', '2026-04-17 15:00:10'),
(31, 3, NULL, 'd0579183367ebe9a087cfa42f81a245d', '::1', '2026-04-17 16:11:48'),
(32, 3, NULL, 'a538a5b7cf5282c3cea5a9004a1162bc', '::1', '2026-04-17 17:35:02'),
(33, 3, NULL, '7fbf3dafab16b5185294748f8ca7fbb5', '::1', '2026-04-17 17:38:47'),
(34, 1, NULL, '7fbf3dafab16b5185294748f8ca7fbb5', '::1', '2026-04-17 18:24:53'),
(35, 4, NULL, '7fbf3dafab16b5185294748f8ca7fbb5', '::1', '2026-04-17 18:25:36'),
(36, 2, NULL, '7fbf3dafab16b5185294748f8ca7fbb5', '::1', '2026-04-17 19:15:26'),
(37, 4, NULL, '7fbf3dafab16b5185294748f8ca7fbb5', '::1', '2026-04-17 21:02:20'),
(38, 3, NULL, 'e0123d868b3c238aed05754f582b5eb5', '::1', '2026-04-18 12:26:48'),
(39, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-18 12:48:51'),
(40, 2, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-18 13:33:37'),
(41, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-18 13:33:41'),
(42, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-19 23:30:10'),
(43, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-19 23:35:47'),
(44, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-19 23:49:28'),
(45, 4, NULL, 'efeaa577d303e358db140f0bf48b56eb', '::1', '2026-04-20 06:51:57'),
(46, 3, NULL, 'efeaa577d303e358db140f0bf48b56eb', '::1', '2026-04-20 06:51:59'),
(47, 3, NULL, 'cf3207bef6d5b84cf5eefb1fbbcffeea', '::1', '2026-04-20 08:14:59'),
(48, 4, NULL, 'dac809103874ea5a17a7529f0dd28364', '::1', '2026-04-20 09:29:50'),
(49, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-21 10:47:06'),
(50, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-21 13:15:34'),
(51, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-21 16:47:40'),
(52, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-22 10:30:52'),
(53, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-22 10:30:57'),
(54, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-22 10:31:06'),
(55, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-25 09:20:32'),
(56, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 08:58:04'),
(57, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 09:32:28'),
(58, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 09:41:11'),
(59, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 09:41:22'),
(60, 2, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 09:59:21'),
(61, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 10:03:59'),
(62, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 10:44:00'),
(63, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 12:56:35'),
(64, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 13:55:46'),
(65, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 13:57:10'),
(66, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 16:02:08'),
(67, 2, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 17:51:02'),
(68, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 20:00:30'),
(69, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-27 20:02:43'),
(70, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 02:08:47'),
(71, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 02:43:44'),
(72, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 02:48:29'),
(73, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 03:24:30'),
(74, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 03:56:46'),
(75, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 09:01:15'),
(76, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 09:01:29'),
(77, 2, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 09:23:51'),
(78, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 10:42:10'),
(79, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 10:42:25'),
(80, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 11:13:13'),
(81, 1, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 14:55:11'),
(82, 3, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 14:56:01'),
(83, 4, NULL, 'e1212bd1944e296cfadffe7f36b934b0', '::1', '2026-04-28 15:02:34'),
(84, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-28 15:09:05'),
(85, 1, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-28 15:09:14'),
(86, 2, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-28 15:09:19'),
(87, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-28 15:09:23'),
(88, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-29 06:03:18'),
(89, 2, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-29 23:21:25'),
(90, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-04-30 16:19:07'),
(91, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-01 22:10:00'),
(92, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-01 23:09:56'),
(93, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-05 14:38:57'),
(94, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-05 14:44:39'),
(95, 2, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-05 16:19:12'),
(96, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-05 16:27:51'),
(97, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-05 16:30:28'),
(98, 4, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-05 22:16:27'),
(99, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-08 13:17:12'),
(100, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-08 17:07:26'),
(101, 2, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-08 17:14:44'),
(102, 1, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-08 17:14:49'),
(103, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-08 17:54:20'),
(104, 3, NULL, 'e305fc8c3a4925db9a25af8d3642d80e', '::1', '2026-05-08 20:36:58'),
(105, 4, NULL, 'b1c561854f35d6e8f5ee5669a16b9bdb', '::1', '2026-05-12 00:59:27'),
(106, 1, NULL, 'b1c561854f35d6e8f5ee5669a16b9bdb', '::1', '2026-05-12 09:25:00'),
(107, 4, NULL, '081aed6a0bfd4762640a88186ab92dce', '::1', '2026-05-15 22:58:21'),
(108, 3, NULL, '081aed6a0bfd4762640a88186ab92dce', '::1', '2026-05-15 22:58:29'),
(109, 1, NULL, '081aed6a0bfd4762640a88186ab92dce', '::1', '2026-05-15 23:12:34'),
(110, 4, NULL, '3b4798c785234c7d18f532e21fc567ab', '::1', '2026-05-25 04:54:04'),
(111, 4, NULL, '3b4798c785234c7d18f532e21fc567ab', '::1', '2026-05-26 14:48:24'),
(112, 3, NULL, '3b4798c785234c7d18f532e21fc567ab', '::1', '2026-05-29 09:25:36'),
(113, 2, NULL, '3b4798c785234c7d18f532e21fc567ab', '::1', '2026-05-29 09:25:41'),
(114, 4, NULL, '3b4798c785234c7d18f532e21fc567ab', '::1', '2026-05-29 09:36:21'),
(115, 1, NULL, '3b4798c785234c7d18f532e21fc567ab', '::1', '2026-05-29 09:36:31');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `settings` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_id`, `settings`, `updated_at`) VALUES
(1, 'abcde', '{\"app\":{\"name\":\"Os Shop\",\"title\":\"Os Shop\",\"description\":\"Discover a smarter way to shop. From trending products to everyday essentials, we connect you with what you love\\u2014quickly, securely, and effortlessly. Shopping just got better.\",\"logo\":\"https:\\/\\/dummyimage.com\\/500x500\\/444\\/fff&text=Os\",\"version\":\"1.0.0\",\"environment\":\"production\"},\"payment\":{\"provider\":\"paystack\",\"publicKey\":\"pk_1234567890\",\"enablePod\":true},\"contact\":{\"phone\":\"+2349064732951\",\"whatsapp\":\"2349064732951\",\"email\":\"shop-support@gmail.com\",\"address\":\"Oke-ilewo, Abeokuta, Ogun, Nigeria\",\"map\":\"oke-ilewo abeokuta lafenwa ogun nigeria\"},\"business_days\":{\"open\":\"Mon \\u2013 Sat: 9:00 AM \\u2013 6:00 PM\",\"close\":\"Sunday: Closed\"},\"api\":{\"baseUrl\":\"http:\\/\\/localhost:8080\\/ecommerce\",\"timeout\":10000},\"currency\":{\"code\":\"NGN\",\"symbol\":\"\\u20a6\",\"locale\":\"en-NG\"},\"shipping\":{\"flatRate\":0,\"freeShippingThreshold\":0,\"maxDate\":5},\"features\":{\"enableCoupons\":true,\"enableWishlist\":true,\"enableReviews\":false},\"storageKeys\":{\"cart\":\"site_mystore_cart\",\"user\":\"site_mystore_user\"},\"google\":{\"client\":\"\",\"secret\":\"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\",\"redirect\":\"http:\\/\\/localhost:8000\\/ecommerce\\/api\\/google-auth\",\"clientid\":\"414280429870-9edivvjhc60c738ve0e44co6p8cmpdgj.apps.googleusercontent.com\"},\"email\":{\"channel\":\"phpmailer\",\"host\":\"mail.oshobby.com.ng\",\"username\":\"support@oshobby.com.ng\",\"password\":\"Fvp-9UY-juT-EcP\",\"encryption\":\"tls\",\"port\":587,\"from\":\"support@oshobby.com.ng\",\"alias\":\"Os Hobby\",\"authentication\":1,\"reply_to\":\"support@oshobby.com.ng\"}}', '2026-05-25 21:31:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `site_id` varchar(50) NOT NULL,
  `role` enum('administrator','manager','user') NOT NULL DEFAULT 'user',
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `google_id` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_verified` varchar(50) NOT NULL DEFAULT '0',
  `address` text DEFAULT NULL,
  `avatar` text DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `state` varchar(55) NOT NULL,
  `status` tinyint(4) DEFAULT 1,
  `login_token` varchar(64) DEFAULT NULL,
  `token_expiry` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `site_id`, `role`, `name`, `username`, `google_id`, `phone`, `email`, `email_verified`, `address`, `avatar`, `password`, `state`, `status`, `login_token`, `token_expiry`, `created_at`, `updated_at`) VALUES
(1, 'abcde', 'administrator', 'Master Admin', 'admin', '', '09064732951', 'oshobbyenterprise@gmail.com', '0', 'Abeokuta\nAbeokuta Ogun state', NULL, '$2y$10$8LuZaG6buTPJAVVS4HYnXuk5Iv5FZktMwA3qpSZc4WwxB86xvuP8i', 'Ogun', 1, 'f8f4334553a81437309f5f991006b2f3f22c9750b126510c7d4f1d3fef07c7c7', '2026-06-06 16:43:23', '2026-03-03 16:31:33', '2026-05-25 06:47:05'),
(11, 'abcde', 'user', 'Oluseyi Bangvvkole', 'ggdddcc', NULL, '09064732951', 'oluseyi.bankole2021@gmail.com', '1', 'Lafenwa, Abeokuta, Ogun state', NULL, '$2y$10$M5t909IUxSE0.rOW6VtsjOwgRS1yViOxw36qqtt8rJi3m7ezL3/TW', 'Benue', 1, '', '2026-05-25 14:43:15', '2026-05-25 16:33:06', '2026-05-25 15:33:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `site_id` (`site_id`);

--
-- Indexes for table `job_queue`
--
ALTER TABLE `job_queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status_available` (`status`,`available_at`),
  ADD KEY `idx_locked` (`locked_at`),
  ADD KEY `idx_priority` (`priority`,`status`,`available_at`);

--
-- Indexes for table `media_images`
--
ALTER TABLE `media_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `site_id` (`site_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`),
  ADD KEY `status` (`status`),
  ADD KEY `slug_status` (`slug`,`status`),
  ADD KEY `status_type_site_id` (`status`,`type`,`site_id`),
  ADD KEY `type_ref_id` (`type`,`ref_id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `position` (`position`),
  ADD KEY `menu_key` (`menu_key`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_payment_reference` (`payment_reference`),
  ADD KEY `idx_orders_status_created` (`status`,`created_at`),
  ADD KEY `idx_orders_user_created` (`user_id`,`created_at`),
  ADD KEY `idx_orders_session_created` (`session_id`,`created_at`),
  ADD KEY `site_id` (`site_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_order_items_product_order` (`product_id`,`order_id`),
  ADD KEY `idx_order_items_order_product` (`order_id`,`product_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `id_site_id` (`id`,`site_id`),
  ADD KEY `site_id_title` (`site_id`,`title`(100)),
  ADD KEY `site_id_slug` (`site_id`,`slug`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `developer_id` (`user_id`),
  ADD KEY `expires_at` (`expires_at`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `site_id` (`site_id`),
  ADD KEY `idx_discount` (`has_discount`),
  ADD KEY `status_created_at` (`status`,`created_at`);
ALTER TABLE `products` ADD FULLTEXT KEY `name` (`name`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`product_id`,`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_media` (`media_id`);

--
-- Indexes for table `product_popularity`
--
ALTER TABLE `product_popularity`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `view_count` (`view_count`);

--
-- Indexes for table `product_popularity_temp`
--
ALTER TABLE `product_popularity_temp`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `view_count` (`view_count`);

--
-- Indexes for table `product_variants`
--
ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`);

--
-- Indexes for table `product_views`
--
ALTER TABLE `product_views`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_views_product_created` (`product_id`,`created_at`),
  ADD KEY `idx_views_session_created` (`session_id`,`created_at`),
  ADD KEY `idx_views_user_created` (`user_id`,`created_at`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `site_id` (`site_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `idx_users_email` (`email`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `google_id` (`google_id`),
  ADD KEY `site_id` (`site_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `job_queue`
--
ALTER TABLE `job_queue`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `media_images`
--
ALTER TABLE `media_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=266;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `product_variants`
--
ALTER TABLE `product_variants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_views`
--
ALTER TABLE `product_views`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

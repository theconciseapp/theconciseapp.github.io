<?php

if (file_exists(__DIR__ . '/../api/config/config.php')) {
    http_response_code(403);
    exit('Installer is locked. Application already installed.');
}

// ---------- helpers ----------
function ok($cond){ return $cond ? 'success' : 'danger'; }
function icon($cond){ return $cond ? '✔' : '✖'; }
function row($label, $status, $current = '', $required = '', $note = ''){
    $class = ok($status);
    $ic = icon($status);
    return "
    <tr class='table-$class'>
        <td>{$ic} {$label}</td>
        <td>{$current}</td>
        <td>{$required}</td>
        <td>{$note}</td>
    </tr>";
}

$errors = [];

// ---------- REQUIRED ----------
$required = [];

// PHP version
$phpOk = version_compare(PHP_VERSION, '7.3', '>=');
$required[] = row(
    'PHP Version',
    $phpOk,
    PHP_VERSION,
    '>= 7.3'
);
if (!$phpOk) $errors[] = 'PHP Version';

// PDO
$pdoOk = extension_loaded('pdo');
$required[] = row(
    'PDO Extension',
    $pdoOk,
    $pdoOk ? 'Enabled' : 'Missing',
    'Enabled'
);
if (!$pdoOk) $errors[] = 'PDO';

// PDO MySQL
$pdoMysqlOk = extension_loaded('pdo_mysql');
$required[] = row(
    'PDO MySQL Driver',
    $pdoMysqlOk,
    $pdoMysqlOk ? 'Enabled' : 'Missing',
    'Enabled'
);
if (!$pdoMysqlOk) $errors[] = 'PDO MySQL';

// mbstring
$mbOk = extension_loaded('mbstring') && function_exists('mb_strlen');
$required[] = row(
    'mbstring',
    $mbOk,
    $mbOk ? 'Enabled' : 'Missing',
    'Enabled'
);
if (!$mbOk) $errors[] = 'mbstring';

// writable config dir
$writeOk = is_writable(__DIR__);
$required[] = row(
    'Writable Directory',
    $writeOk,
    $writeOk ? 'Writable' : 'Not writable',
    'Writable'
);
if (!$writeOk) $errors[] = 'Writable Directory';

// ---------- RECOMMENDED ----------
$recommended = [];

// curl
$curlOk = extension_loaded('curl');
$recommended[] = row(
    'cURL',
    $curlOk,
    $curlOk ? 'Enabled' : 'Disabled',
    'Enabled',
    'Required for API calls'
);

// openssl
$sslOk = extension_loaded('openssl');
$recommended[] = row(
    'OpenSSL',
    $sslOk,
    $sslOk ? 'Enabled' : 'Disabled',
    'Enabled',
    'Required for HTTPS/secure requests'
);

// file uploads
$uploadOk = ini_get('file_uploads');
$recommended[] = row(
    'File Uploads',
    $uploadOk,
    $uploadOk ? 'On' : 'Off',
    'On'
);

// upload size
$recommended[] = row(
    'Upload Max Filesize',
    true,
    ini_get('upload_max_filesize'),
    '>= 10M'
);

// memory limit
$recommended[] = row(
    'Memory Limit',
    true,
    ini_get('memory_limit'),
    '>= 128M'
);

// execution time
$recommended[] = row(
    'Max Execution Time',
    true,
    ini_get('max_execution_time') . 's',
    '>= 30s'
);

// timezone
$tz = ini_get('date.timezone');
$recommended[] = row(
    'Timezone',
    !empty($tz),
    $tz ?: 'Not set',
    'Set',
    'Set in php.ini'
);


// ---------- EXTENSION DEEP CHECKS ----------

// JSON (usually always enabled in modern PHP)
$jsonOk = extension_loaded('json');
$recommended[] = row(
    'JSON Extension',
    $jsonOk,
    $jsonOk ? 'Enabled' : 'Missing',
    'Enabled'
);

// fileinfo (used for uploads, MIME detection)
$fileinfoOk = extension_loaded('fileinfo');
$recommended[] = row(
    'Fileinfo Extension',
    $fileinfoOk,
    $fileinfoOk ? 'Enabled' : 'Missing',
    'Enabled',
    'Used for file uploads'
);

// GD (image processing)
$gdOk = extension_loaded('gd');
$recommended[] = row(
    'GD Library',
    $gdOk,
    $gdOk ? 'Enabled' : 'Missing',
    'Optional',
    'Required for image resizing'
);
// ---------- OUTPUT ----------
?>

<h5>Server Diagnostics</h5>

<h6 class="mt-3">Required</h6>
<div class="table-responsive">
<table class="table table-sm table-bordered">
<thead>
<tr>
    <th>Check</th>
    <th>Current</th>
    <th>Required</th>
    <th>Note</th>
</tr>
</thead>
<tbody>
<?= implode('', $required) ?>
</tbody>
</table>
</div>

<h6 class="mt-4">Recommended</h6>
<div class="table-responsive">
<table class="table table-sm table-bordered">
<thead>
<tr>
    <th>Check</th>
    <th>Current</th>
    <th>Recommended</th>
    <th>Note</th>
</tr>
</thead>
<tbody>
<?= implode('', $recommended) ?>
</tbody>
</table>
</div>

<?php if (!empty($errors)): ?>
<div class="alert alert-danger mt-3">
    <strong>Installation cannot continue.</strong><br>
    Fix the following:
    <ul>
        <?php foreach ($errors as $e) echo "<li>$e</li>"; ?>
    </ul>
</div>
<?php else: ?>
<div class="alert alert-success mt-3">
    All required checks passed. You can continue.
</div>
<?php endif; ?>
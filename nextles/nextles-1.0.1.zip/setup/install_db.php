<?php

if (file_exists(__DIR__ . '/../api/config/config.php')) {

    http_response_code(403);

    exit('<div class="alert alert-danger">
        Installer is locked. Application already installed.
    </div>');
}


$required = ['host', 'dbname', 'user'];

foreach ($required as $field) {

    if (empty($_POST[$field])) {

        http_response_code(422);

        exit("<div class='alert alert-danger'>
            Missing field: {$field}
        </div>");
    }
}


$host = trim($_POST['host'] ?? '');
$db   = trim($_POST['dbname'] ?? '');
$user = trim($_POST['user'] ?? '');
$pass = $_POST['pass'] ?? '';

$pdo = null;

try {

    /*
    |--------------------------------------------------------------------------
    | Connect To MySQL
    |--------------------------------------------------------------------------
    */

    $pdo = new PDO(
        "mysql:host={$host};charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );


    /*
    |--------------------------------------------------------------------------
    | Create Database
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE DATABASE IF NOT EXISTS `{$db}`
        CHARACTER SET utf8mb4
        COLLATE utf8mb4_unicode_ci
    ");


    /*
    |--------------------------------------------------------------------------
    | Select Database
    |--------------------------------------------------------------------------
    */

    $pdo->exec("USE `{$db}`");


    /*
    |--------------------------------------------------------------------------
    | Write Config File
    |--------------------------------------------------------------------------
    */

    include __DIR__ . "/write-config-file.php";

    writeConfigFile(
        __DIR__ . '/../api/config/config.php',
        [
            'host'   => $host,
            'db'     => $db,
            'user'   => $user,
            'pass'   => $pass,
            'siteId' => 'abcde'
        ]
    );


    /*
    |--------------------------------------------------------------------------
    | Import SQL File
    |--------------------------------------------------------------------------
    */

    $sqlFile = __DIR__ . '/database.sql';

    if (!file_exists($sqlFile)) {

        throw new Exception("database.sql file not found");
    }


    $file = fopen($sqlFile, 'r');

    if (!$file) {

        throw new Exception("Unable to open database.sql");
    }


    $query = '';

    while (!feof($file)) {

        $line = fgets($file);

        if ($line === false) {
            continue;
        }

        $trimmed = trim($line);


        // Skip comments and empty lines
        if (
            $trimmed == '' ||
            str_starts_with($trimmed, '--') ||
            str_starts_with($trimmed, '/*') ||
            str_starts_with($trimmed, '//')
        ) {
            continue;
        }

        $query .= $line;


        // Execute query when semicolon is found
        if (substr(rtrim($trimmed), -1) == ';') {

            $pdo->exec($query);

            $query = '';
        }
    }

    fclose($file);


    /*
    |--------------------------------------------------------------------------
    | Success
    |--------------------------------------------------------------------------
    */

    echo '<div class="alert alert-success">
        Installation successful
    </div>';

} catch (Exception $e) {


    /*
    |--------------------------------------------------------------------------
    | Rollback - Drop Database
    |--------------------------------------------------------------------------
    */

    try {

        if ($pdo !== null && !empty($db)) {

            $pdo->exec("DROP DATABASE IF EXISTS `{$db}`");
        }

    } catch (Exception $dropError) {

        // Ignore rollback errors
    }


    /*
    |--------------------------------------------------------------------------
    | Remove Config File If Created
    |--------------------------------------------------------------------------
    */

    $configPath = __DIR__ . '/../api/config/config.php';

    if (file_exists($configPath)) {

        @unlink($configPath);
    }


    /*
    |--------------------------------------------------------------------------
    | Error Response
    |--------------------------------------------------------------------------
    */

    http_response_code(500);

    echo '<div class="alert alert-danger">';
    echo 'Installation failed: ' . htmlspecialchars($e->getMessage());
    echo '</div>';
}
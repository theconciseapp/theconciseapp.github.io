<?php $homeUrl=dirname(dirname($_SERVER['SCRIPT_NAME']));
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>App Installer</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<style>
body { background:#f4f6f9; }
.card { max-width:600px; margin:60px auto; }
.step { display:none; }
.step.active { display:block; }
</style>
</head>

<body>
<div class="container">
  <div class="card shadow-sm">
    <div class="card-header text-center">
      <h4>🚀 Installer</h4>
    </div>

    <div class="card-body">

      <!-- Progress -->
      <div class="progress mb-4">
        <div id="bar" class="progress-bar" style="width:20%">Step 1</div>
      </div>

      <!-- STEP 1: Requirements -->
      <div class="step active" id="step1">
        <h5>Server Requirements</h5>
        <div id="reqList" class="ms-2"></div>
        <button class="btn btn-primary w-100 next">Continue</button>
      </div>

      <!-- STEP 2: DB -->
      <div class="step" id="step2">
        <h5>Database Setup</h5>

        <input class="form-control mb-2" name="host" placeholder="Host" value="localhost">
        <input class="form-control mb-2" name="dbname" placeholder="Database">
        <input class="form-control mb-2" name="user" placeholder="Username">
        <input type="password" class="form-control mb-3" id="db-pass" name="pass" placeholder="Password">

        <button id="testDb" class="btn btn-secondary w-100 mb-2">Test Connection</button>
        <button class="btn btn-primary w-100 next">Continue</button>

        <div id="dbResult" class="mt-2"></div>
      </div>

      <!-- STEP 3: Install -->
      <div class="step" id="step3">
        <h5>Install Database</h5>
        <button id="runInstall" class="btn btn-success w-100">Run Installation</button>
        <button class="mt-2 btn btn-secondary" onclick="showStep(2);">Back</button>
        <div id="installLog" class="mt-3"></div>
      </div>

      <!-- STEP 4: Admin -->
      <div class="step" id="step4">
        <h5>Create Admin</h5>

        <input class="form-control mb-2" id="adminUser" placeholder="Admin Username">
        <input class="form-control mb-2" id="adminEmail" placeholder="Admin Email">
        <input type="password" class="form-control mb-3" id="adminPass" placeholder="Password">

        <button id="createAdmin" class="btn btn-primary w-100">Create Admin</button>
        <div id="adminResult" class="mt-2"></div>
      </div>

      <!-- STEP 5: Finish -->
      <div class="step" id="step5">
        <h5>✅ Installation Complete</h5>
        <p>Your application is ready.</p>
        <a href="<?php echo $homeUrl;?>" class="btn btn-success w-100">Go to Site</a>
      </div>

    </div>
  </div>
</div>

<script>
let step = 1;

// STEP NAVIGATION
function showStep(n){
  $('.step').removeClass('active');
  $('#step'+n).addClass('active');
  $('#bar').css('width', (n*20)+'%').text('Step '+n);
  step = n;
}

// NEXT BUTTON
$('.next').on('click', function(){
    if(step === 2 && !validateStep2()) return;
  showStep(step+1);
});

// STEP 1: REQUIREMENTS CHECK
$.ajax({
    url: 'check.php',
    method: 'GET'
})
.done(function (res) {
    $('#reqList').html(res);
})
.fail(function (xhr, textStatus, errorThrown) {
    let msg = xhr.responseText || 'Request failed';
    $('#reqList').html(
        '<div class="alert alert-danger">' + msg + '</div>'
    );
});
// STEP 2: TEST DB
$('#testDb').on('click', function () {

    let data = {
        host: $('[name=host]').val(),
        user: $('[name=user]').val(),
        pass: $('[name=pass]').val()
    };

    $('#dbResult').html('Testing...');

    const btn = $(this);
    btn.prop('disabled', true);

    $.ajax({
        url: 'db_test.php',
        method: 'POST',
        data: data
    })
    .done(function (res) {

        btn.prop('disabled', false);

        // res is plain text / HTML from PHP
        $('#dbResult').html(res);
    })
    .fail(function (xhr, textStatus, errorThrown) {

        btn.prop('disabled', false);

        let msg = xhr.responseText || 'Request failed';

        $('#dbResult').html(
            '<div class="alert alert-danger">' + msg + '</div>'
        );
    });
});

// STEP 3: INSTALL DB
$('#runInstall').on('click', function(){
 	
  let data = {
    host: $('[name=host]').val(),
    dbname: $('[name=dbname]').val(),
    user: $('[name=user]').val(),
    pass: $('[name=pass]').val()
  };

  $('#installLog').html('Installing...');

const btn=$(this);
	btn.prop('disabled', true);

  $.ajax({
   url: 'install_db.php',
  method: 'POST',
  data: data
}).done(function(data){
  	 btn.prop('disabled', false);

    $('#installLog').html(data);
    showStep(4);
  }).fail( function(e, txt, xhr){
   	//alert( JSON.stringify( e))
  btn.prop('disabled', false);
  $('#installLog').html(e.responseText);
  });
});

// STEP 4: CREATE ADMIN
$('#createAdmin').on('click', function(){
  let data = {
    user: $('#adminUser').val(),
    email: $('#adminEmail').val(),
    pass: $('#adminPass').val()
  };

  $('#adminResult').html('Creating...');

const btn=$(this);
	btn.prop('disabled', true);

$.ajax({
   url: 'create-admin.php',
  method: 'POST',
  dataType: 'json',
  data: data
}).done(function(data){
	//alert( JSON.stringify( data));
  	 btn.prop('disabled', false);
 
    $('#adminResult').html(`<div class="alert alert-${data.success?'success':'danger'}">${data.message}</div>`);
    
   if( data.success)  showStep(5);
  }).fail( function(e, txt, xhr){
   //	alert( JSON.stringify( e))
  btn.prop('disabled', false);
  let msg = xhr.responseJSON?.message || 'Request failed';
    $('#adminResult').html('<div class="alert alert-danger">' + msg + '</div>');
 });
});

function validateStep2() {
    let ok = true;

    $('#step2 input').each(function(){
   const id=$(this).attr('id');
   
        if ( id!=='db-pass' && $(this).val().trim() === '') {
            $(this).addClass('is-invalid');
            ok = false;
        } else {
            $(this).removeClass('is-invalid');
        }
    });

    return ok;
}
</script>

</body>
</html>
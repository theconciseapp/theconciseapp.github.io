<?php function writeConfigFile($path, $data)
{
    // Basic validation
    $required = ['host','db','user','pass','siteId'];
    foreach ($required as $key) {
        if (!isset($data[$key])) {
            throw new Exception("Missing config key: $key");
        }
    }

    // Escape values safely for PHP string output
    $host   = addslashes($data['host']);
    $db     = addslashes($data['db']);
    $user   = addslashes($data['user']);
    $pass   = addslashes($data['pass']);
    $siteId = addslashes($data['siteId']);
    $charset = 'utf8mb4';

    // Build config content
    $config = <<<PHP
<?php
date_default_timezone_set('Africa/Lagos');

\$host = '$host';
\$db   = '$db';
\$user = '$user';
\$pass = '$pass';

\$charset = '$charset';

\$dsn = "mysql:host=\$host;dbname=\$db;charset=\$charset";

\$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    \$conn = new PDO(\$dsn, \$user, \$pass, \$options);
} catch (PDOException \$e) {
    exit("Database connection failed: " . \$e->getMessage());
}

\$siteId = '$siteId';

PHP;

    // Write file safely
    if (file_put_contents($path, $config, LOCK_EX) === false) {
        throw new Exception("Failed to write config file");
    }

    // Optional: secure permissions
    @chmod($path, 0640);

    return true;
}
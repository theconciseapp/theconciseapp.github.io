<?php

require_once "ProjectClasses/bootstrap.php";

require_once "ProjectClasses/main.php";
require_once "ProjectClasses/main-frontend.php";

$api= new FrontendAPI();
$settings=$api->returnSafeSettings($api->AppSettings);

$env = $settings['app']['environment'] ?? 'production';

if ($env === 'maintenance' && !$api->admin()) {
    http_response_code(503);
    include __DIR__ . '/ProjectViews/maintenance.php';
    exit;
}

$user=$api->verifyToken($_COOKIE[$api->cookieName]??'', true);

$start= $api->start__();
$start['user']=$user;
$siteName=htmlspecialchars($settings['app']['name']);
$siteLogo= $settings['app']['logo'];

  $metaImages = array_filter(explode('||', $start['meta']['images']??''));
  
    $meta_images=[];
 
  foreach ($metaImages as $cnt=>$item) {
  	if( $cnt>3 ) break;
    $parts = explode('|', $item);
    
  if (count($parts) >= 2) {
        $imgUrl = trim($parts[1]);
              $meta_images[]=$imgUrl;   
        }
}

// header menu
$pageMenu = $api->getMenu('header','page');
$catzMenu = $api->getMenu('header','category');
$headerCustomMenu=$api->getMenu('header','custom');

// footer menu
$footerMenu = $api->getMenu('footer');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" cvontent="width=1268px, initial-scale=1.0" content="width=device-width, initial-scale=1.0">
<title><?php echo $start['meta']['title'];?></title>
<meta name="description" content="<?php echo $start['meta']['description'];?>">

<link rel="canonical" href="<?php echo $start['meta']['canonical'];?>">
 <link rel="icon" href="<?php echo $api->site_url() . '/favicon.ico';?>" type="image/x-icon">
 <!-- Open Graph -->
 <meta property="og:site_name" content="<?php echo $siteName;?>">
  <meta property="og:title" content="<?php echo $start['meta']['title'];?>">
  <meta property="og:description" content="<?php echo $start['meta']['description'];?>">
  
  
  <meta property="og:url" content="<?php echo $start['meta']['canonical'];?>">
  <meta property="og:type" content="<?php echo $start['meta']['type']??"website";?>">

<?php foreach($meta_images AS $imgUrl){
	echo '<meta property="og:image" content="' . htmlspecialchars($imgUrl, ENT_QUOTES, 'UTF-8') . '">' . "\n";
	}?>

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $start['meta']['title'];?>">
<meta name="twitter:description" content="<?php echo $start['meta']['description'];?>">
<meta name="twitter:image" content="<?php echo $meta_images[0]??'';?>">

<?php if( $api->singleProductPage ){?>

<script type="application/ld+json">
{
  "@context": "https://schema.org/",
  "@type": "<?php echo ucfirst($start['meta']['type']??"website");?>",
  "name": "<?php echo $start['meta']['title'];?>",
  "image": <?php echo json_encode($images);?>,
  "description": "<?php echo $start['meta']['description'];?>",
  "offers": {
    "@type": "Offer",
    "priceCurrency": "NGN",
    "price": "<?php echo $start['meta']['price']??'';?>",
    "availability": "https://schema.org/InStock",
    "url": "<?php echo $start['meta']['canonical'];?>"
  }
}

</script>
<?php } ?>
<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7.2.0/css/all.min.css">
<link href="<?php echo $api->assets('css','style.css');?>" rel="stylesheet">
<script>
const OsBaseUrl = '<?php echo $api->site_url();?>';
const config=<?php echo json_encode( $settings);?>;
const START__=<?php echo json_encode($start);?>;
</script>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const OsPaystackLocal=''; //http://localhost:8000/paystack/api';
</script>
<script src="/paystack/assets/js/os-paystack.js?v=<?php echo time();?>"></script>
<script sgrc="https://theconciseapp.github.io/os-paystack.js?v=1"></script>

<script src="<?php echo $api->assets('js','popstate.js');?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lazysizes/5.3.2/lazysizes.min.js"></script>
<script src="<?php echo $api->assets('js','global.js');?>"></script>
</head>
<body>
<div id="loader-container">
  <div><i class="fas fa-spin fa-spinner fa-3x text-warning"></i></div>
</div>
<div id="ajax-loader-container2">
  <div><i class="fas fa-spin fa-spinner fa-3x"></i></div>
</div>
<div id="ajax-loader-container">
  <i class="fas fa-spin fa-shopping-cart fa-2x text-warning"></i>
</div>

<div id="appModalContainer"></div>

<!--DASHBOARD-->

<section id="dashboard">

 <header id="main-header"> 
 <div id="header-menu-btn" onclick="toggleMenu(this);"><i class="fas fa-bars text-dark"></i>
</div>

<div>
<span class="d-inline-block" id="logo-container"></span>
</div>

<div id="top-search-btn">
  <div class="d-flex gap-2 ps-2 align-items-center w-100 bg-white">
 <i class="fas fa-search"></i>
 <span class="form-control border-0" onclick="togglePage('sectionProductSearch'); $('#product-search-input')[0].focus();">Search items</span>
</div>
</div>
<div class="text-end dropdown">
 <span class="dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-user"></i> <span class="d-none d-md-inline">Account</span></span>

  <ul class="dropdown-menu dropdown-menu-end pb-0" id="user-menu-items"></ul>
</div>

<div onclick="openCart(this);" class="text-end">
<div class="cart-wrapper position-relative d-inline-block">
  <i class="fa fa-shopping-cart"></i>
  <span class="badge bg-danger cartCount position-absolute top-0 start-100 translate-middle">
    0
  </span>
</div>
<span class="d-none d-md-inline">Cart</span>
</div>
</header>

<div class="d-flex py-1 px-2 bg-white d-md-none gap-2 ps-3 align-items-center w-100">
 <i class="fas fa-search"></i>
 <span class="form-control border-0" onclick="togglePage('sectionProductSearch'); $('#product-search-input')[0].focus();">Search items</span>
</div>

<div class="mt-2 d-flex gap-2">

<div id="header-menu-container" class="flex-shrink-0">

<div id="header-menu-blur" onclick="toggleMenu(this,1);"></div>

 <div id="header-ul">
 
  <span class="menu-close-btn d-flex justify-content-end pe-0">
    <i class="px-4 py-3 fas fa-times text-dark d-md-none" onclick="toggleMenu(this,1);"></i>
    </span>
   
   <ul class="ps-0 ms-0">
   
<?php 
 if ( $api->admin() ){?>
<li><a href="<?php echo $api->site_url(). '/admin';?>" class="ps-3 text-decoration-none" target="_blank"><i class="fas fa-circle"></i> Admin</a></li><?php }?>
  </ul>
   
   <div class="py-2">
<strong class="ps-3">Categories</strong></div>
 
 <?php  echo $api->sidebarMenu($catzMenu['data'], ['custom_link_class'=>'category-link'] );
?>

   <div class="py-2">
<strong class="ps-3">Pages</strong>
</div>
 
 <?php  
echo $api->sidebarMenu($pageMenu['data'], ['custom_link_class'=>'ajax-page-link'] );
?>

   <div class="py-2 d-none">
<strong class="ps-3">Other Links</strong></div>
 
 <?php  echo $api->sidebarMenu($headerCustomMenu['data'], ['custom_link_class'=>'custom-link', 'target'=>'_blank'] );
?>
  </div>
</div>

<div class="leaderboard-items flex-fill">

<div id="hero-commerce"></div>
 </div>
</div>

<div class="cart-btn" id="cart-btn" onclick="openCart(this);">
            <i class="fa fa-shopping-cart"></i>                 <span class="badge bg-danger  cartCount">0</span>
    </div>

</section>

<!--Preview Product-->

<section class="hidden-section"  id="sectionProductPreview">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-0 w-75">

<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-between align-items-center">
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>

<div onclick="openCart(this);" class="text-end me-3">
<div class="cart-wrapper position-relative d-inline-block">
  <i class="fa fa-shopping-cart"></i>
  <span class="badge bg-danger cartCount position-absolute top-0 start-100 translate-middle">
    0
  </span>
</div>
<span class="d-none d-md-inline">Cart</span>
</div>
</div>

</div>

<div>
 <div class="row mt-3 mb-2">
   <div class="col-md-8 mb-2">
   <div class="container" id="product-preview-container"></div>
   </div>   
   <div class="col-md-4 py-2">
   
   <b class="fw-bold">Full Description</b>
   <div id="product-preview-full-desc"></div>
      
  </div>
</div>

<div class="mb-2">
   <b class="fw-bold">Customers also viewed</b>
 
   <div id="product-preview-related-products" class="container-fluid">
   <div class="text-center mt-4"><i class="fas fa-spin fa-spinner fa-2x text-warning"></i></div></div>
  
  </div>
  <hr>
   <div class="mb-2">
 <b class="fw-bold">Recently viewed</b>
 
   <div class="container-fluid recently-viewed-products-2">
   <div class="text-center mt-4"><i class="fas fa-spin fa-spinner fa-2x text-warning"></i></div></div>
  
  </div>
<div class="section-sticky-footer" id="product-preview-footer"></div>

  </div>  
</section>


<!--Products in Categories-->

<section class="hidden-section"  id="sectionProductsInCatz">
<div class="page-blur"></div>
<div class="section-data container-fluid pt-2 pb-5 h-75 w-75">

<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-between align-items-center gap-1">

<div class="flex-shrink-0">
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div class="w-100 text-center">
<span id="products-catz-slug"></span>
</div>
</div>
</div>

<div class="my-2" id="category-products-description"></div>

 <div class="row mt-3 mb-2">
   <div class="col-12 mb-2">
   
   <div class="container" id="product-catz-container"></div>
   <!-- Pagination -->
  
<nav class="text-center my-3">
<button class="prev btn btn-sm btn-warning d-none" data-page="" onclick="loadProductsByCategories(this);">Previous</button>
<button class="next ms-2 btn btn-sm btn-warning d-none"  data-page="" onclick="loadProductsByCategories(this);">Next</button>

</nav>
   
   
   </div>   
   <div class="col-12"></div>
   
</div>
  </div>  
</section>


<?php if( $api->isBot()) {
  include('sections/footer.php');
exit;
}?>
<!--Products-->

<section class="mt-2">
   <div class="container-fluid home-product-container px-0 mb-2 mt-0">
   
   <div class="products-title-container bg-warning d-flex align-items-center justify-content-between px-3 py-1">
<strong>New Arrivals</strong>
<button class="btn btn-outline-warning text-dark" data-section="new-arrivals" onclick="loadAllProducts(this)">See all</button>
</div>
  <div class="container-fluid px-2 mt-1" id="products"></div>  
  </div>
<!---------------->  

<div class="container-fluid home-product-container px-0 mb-2 mt-0">
   <div class="products-title-container bg-warning d-flex align-items-center justify-content-between px-3 py-1">
<strong>Trending Products</strong>
<button class="btn btn-outline-warning text-dark" data-section="trending" onclick="loadAllProducts(this);">See all</button>
</div>
  <div class="container-fluid px-2 mt-1" id="home-trending-products"></div>
  </div>
<!---------------->  
  
<div class="container-fluid home-product-container px-0">
   <div class="products-title-container bg-warning d-flex align-items-center justify-content-between px-3 py-1">
<strong>Top Deals</strong>
<button class="btn btn-outline-warning text-dark" data-section="top-deals" onclick="loadAllProducts(this);">See all</button>
</div>
  <div class="container-fluid px-2 mt-1" id="products-top-deals"></div>
  </div>
   <!---------------->  
   
   <div class="container-fluid home-product-container px-0">
   <div class="products-title-container bg-warning d-flex align-items-center justify-content-between px-3 py-1">
<strong class="py-">Best Sellers</strong>
<button class="btn btn-outline-warning text-dark" data-section="best-sellers" onclick="loadAllProducts(this);">See all</button>
</div>
  <div class="container-fluid px-2 mt-1" id="products-best-sellers"></div>
  </div>
   <!---------------->  
   
      <div class="container-fluid home-product-container px-0">
   <div class="products-title-container bg-warning d-flex  align-items-center justify-content-between px-3 py-1">
<strong class="py-1">You Showed Interest </strong>
<button class="btn btn-outline-warning text-dark d-none" data-section="recently-viewed">See all</button>
</div>
  <div class="container-fluid px-2 mt-1" id="recently-viewed-products"></div>
  </div>
   <!---------------->
   
   
  </div>  
</section>

<!--View All Section-->
<section class="hidden-section"  id="viewAllSection">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-5 h-75 w-75">
<div class="py-2 section-sticky-header">

<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>

</div>

 <div id="view-all-container" class="mt-2"></div>

</div>
</section>

<!--Search Product-->

<section class="hidden-section"  id="sectionProductSearch">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-5 h-75 w-75">


<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-between align-items-center gap-1">

<div class="flex-shrink-0">
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div class="w-100">
<form id="searchProductForm2" class="needs-validation" novalidate>

<div class="input-group position-relative">
 <input name="s" id="product-search-input" class="form-control border-0" placeholder="Search items" minlength="3">
<span class="input-group-text border-0">
<button type="submit" class="btn btn-sm border-0"><i class="fas fa-search"></i></button>
</span>
</div>
</form>
    <div class="position-absolute z-2 invalid-feedback">Enter at least 3 characters</div>
</div>
</div>
</div>

 <div class="row mt-3 mb-2">
   <div class="col-12 mb-2">
   
   <div class="container" id="product-search-container"></div>
   <!-- Pagination -->
  
<nav class="text-center my-3">
<button class="prev btn btn-sm btn-warning d-none" data-page="" onclick="searchProduct(this);">Previous</button>
<button class="next ms-2 btn btn-sm btn-warning d-none"  data-page="" onclick="searchProduct(this);">Next</button>

</nav>
   
   
   </div>   
   <div class="col-12"></div>
   
</div>
  </div>  
</section>

<!--Cart-->

<section class="hidden-section"  id="cart">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-0 h-75 w-75">

<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-between align-items-center">
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>

<h5>Cart <i class="fas fa-shopping-bag text-secondary"></i></h5>
</div>
</div>
 <div class="row mt-3 mb-2">
<div class="col-md-7">
   <div class="mb-3 d-block d-md-none">
      Your Details <strong><span class="customer-name"></span></strong> - 
   <small>
<span class="text-muted"> <i class="fa fa-location-dot text-danger"></i> <span class="customer-address"></span> <i class="fas fa-phone"></i> <span class="customer-phone"></span></span>
   </small> <a href="javascript: void(0);" class="text-decoration-none" onclick="openRegistrationForm(this)">Edit</a> 
    </div>
    
  <div id="cartItems"></div>
 
</div>
<div class="col-md-5">

<div class="sticky-sidebar d-none d-md-block">
<div class="card shadow-lg bg-light mb-5">
  <div class="card-body">

    <h6 class="fw-bold mb-3">
      <i class="fa fa-location-dot text-danger me-2"></i>
   Your Details
    </h6>

<h6 class="fw-semibold mb-3">
<i class="fas fa-user text-primary me-3"></i><span class="customer-name"></span>  
</h6>

   <h6 class="fw-bold mb-3">
      <i class="fa fa-map-marker-alt me-3 text-secondary"></i><span class="fw-semibold customer-address"></span>
   </h6>
 
 <h6 class="fw-bold mb-3 text-muted">
      <i class="fas fa-phone me-3 text-info"></i><span class="fw-semibold customer-phone"></span>
   </h6>
   
    <button class="btn btn-link text-decoration-none p-0 mt-2" onclick="openRegistrationForm(this)">
      <i class="fa fa-pen"></i> Change
    </button>

  </div>
</div>
</div><!--End sticky sidebar-->

</div>
<div class="section-sticky-footer">
  <div class="d-flex justify-content-between align-items-center">
    
    <div>
      <strong>Total:</strong> ₦<span class="cart-total">0</span>
    </div>

    <button class="btn btn-secondary attention" id="checkoutBtn" onclick="checkOut(this);">
      Checkout <i class="fas fa-arrow-right"></i>
    </button>

  </div>
</div>

</div>

  </div>
</section>


<!--PAGES-->
<section class="hidden-section"  id="sectionPages">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-5 h-h75 wh-75">


<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-start align-items-center">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div>
<h5 class="ms-3" id="section-pages-title"></h5>
</div>
</div>
</div>

 <div id="pages-data-container"></div>
 
 </div>
</section>

<!--USER PROFILE-->

<section class="hidden-section"  id="sectionUserProfile">
<div class="page-blur"></div>
<div class="section-data container pt-2 pb-5 h-75 w-75">

  <div class="row">

    <!-- SIDEBAR -->
    <div class="col-lg-3 mb-3">
      <div class="card shadow-sm">
        <div class="card-body p-0">

          <!-- User Header -->
          <div class="text-center p-3 border-bottom">
            <img class="profile-user-avatar rounded-circle mb-2" />
            <h6 class="mb-0 profile-user-name"></h6>
            <small class="text-muted profile-user-email"></small>
            <div class="mb-2">
           <button class="btn btn-sm btn-info" onclick="openRegistrationForm(this)"> <i class="fas fa-pen"></i> Edit</button>
           </div>
          </div>
          

          <!-- Menu -->
          <div class="list-group list-group-flush" id="userProfileMenu">


            <a href="#" class="list-group-item list-group-item-action" onclick="togglePage('sectionUserOrders', 'loadOrders')">
              <i class="fa fa-shopping-bag me-2"></i> Orders
            </a>

            <a href="#" class="list-group-item list-group-item-action d-none"
               onclick="loadProfileSection('addresses')">
              <i class="fa fa-map-marker me-2"></i> Addresses
            </a>

            <a href="#" class="list-group-item list-group-item-action d-none"
               onclick="loadProfileSection('wishlist')">
              <i class="fa fa-heart me-2"></i> Wishlist
            </a>

            <a href="#" class="list-group-item list-group-item-action d-none"
               onclick="loadProfileSection('settings')">
              <i class="fa fa-cog me-2"></i> Settings
            </a>

          </div>
        </div>
      </div>
    </div>

    <!-- MAIN CONTENT -->
    <div class="col-lg-9">

      <div class="card shadow-sm">
        <div class="card-header bg-white d-flex justify-content-between">
          <h6 class="mb-0" id="sectionTitle">Dashboard</h6>
          <span class="text-muted small d-none">Account Panel</span>
        </div>

        <div class="card-body" id="profileContent">

          <!-- DEFAULT DASHBOARD -->
          <div class="row g-3">

            <div class="col-md-4">
              <div class="card border-0 bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-shopping-bag fa-2x mb-2 text-primary"></i>
                  <h5 class="user-stat-total-orders">0</h5>
                  <small>Total Orders</small>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card border-0 bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-truck fa-2x mb-2 text-success"></i>
                  <h5 class="user-stat-total-pending-delivery">0</h5>
                  <small>Pending Delivery</small>
                </div>
              </div>
            </div>

            <div class="col-md-4">
              <div class="card border-0 bg-light">
                <div class="card-body text-center">
                  <i class="fa fa-heart fa-2x mb-2 text-danger"></i>
                  <h5 class="user-stat-total-delivered">0</h5>
                  <small>Delivered</small>
                </div>
              </div>
            </div>


<h3>Recent orders</h3>
   <div class="table-responsive" id="user-orders-summary">
        <table class="table table-hover table-bordered" style="min-width: 850px;">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Total</th>
              <th>status</th>
              <th>Payment</th>
              <th>Total Items</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>



          </div>

        </div>

      </div>
    </div>

  </div>
</div>
</section>

<!--User orders-->
<section class="hidden-section"  id="sectionUserOrders">
<div class="page-blur"></div>

<div class="section-data container pt-0 pb-5 h-h75 wh-75">


<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-start align-items-center mb-2">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div>
<b class="ms-3">Orders</b>
</div>
</div>
</div>

 <div class="row">
  
    <!-- Orders List -->
    <div class="col-12">
     
<form id="order-filter-form">
<div class="row mb-3 g-2">

  <!-- Search -->
  <div class="col-md-3">
    <input type="text" id="orders-search" class="form-control" placeholder="Search Order UID">
  </div>

  <!-- Status -->
  <div class="col-md-2">
  <label for="orders-status">
  Delivery Status</label>
    <select id="orders-status" class="form-select">
          <option value="">--</option>
      <option value="pending">Pending</option>
      <option value="processing">Processing</option>
      <option value="shipped">Shipped</option>
      <option value="delivered">Delivered</option>
      <option value="cancelled">Cancelled</option>
     <option value="expired">Expired</option>
     </select>
  </div>

  <!-- Date From -->
  <div class="col-md-2 d-none">
  <label for="orders-from">Date (From)</label>
    <input type="date" id="orders-from" class="form-control">
  </div>

  <!-- Date To -->
  <div class="col-md-2 d-none">
  <label for="orders-to">Date (To)</label>
    <input type="date" id="orders-to" class="form-control">
  </div>

  <!-- Button -->
  <div class="col-md-2">
    <button type="button" class="btn btn-secondary w-100" onclick="loadOrders(this);">Filter</button>
  </div>
</div>
</form>

      <div class="table-responsive">
        <table class="table table-hover table-bordered" style="min-width: 850px;">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Total</th>
              <th>status</th>
              <th>Payment</th>
              <th>Total Items</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="ordersTable"></tbody>
        </table>
      </div>
      
            <nav class="mt-2 text-center">
<button class="btn btn-sm btn-warning d-none prev" data-page="" onclick="loadOrders(this);">Previous</button>
<button class="ms-2 btn btn-sm btn-warning d-none next" data-page="" onclick="loadOrders(this);">Next</button>

</nav>
        
    </div>

  </div>
 
 </div>
</section>

<!--ORDER ITEMS-->

<section class="hidden-section"  id="sectionOrderItemsList">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-5">

<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-start align-items-center">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div>
<b class="ms-3">Orders Details</b>
</div>
</div>
</div>

    <!-- Orders List -->
      <div id="orderDetails" class="border rounded p-3 bg-light">
      
      </div>
     
</div>

</section>

<!--CATEGORIES-->

<section class="hidden-section"  id="sectionCategoriesList">
<div class="page-blur"></div>
<div class="section-data container py-5">

<div class="row">
        <div class="col-12">

            <div class="card shadow-sm">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="mb-0">Categories</h4>
                        <button class="btn btn-primary btn-sm" onclick="togglePage('sectionCreateCategory','resetCatForm');">
                            + New Category
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-min-width-2 align-middle">
    
  <thead>
    <tr>
      <th>Name</th>
      <th>Slug</th>
      <th>Parent</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody id="categoriesListTable"></tbody>
                        </table>
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</div>

</section>

<!--CUSTOMER Login Form-->

<section class="hidden-section"  id="sectionCustomerForm">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-5 h-75 w-75">

<div class="py-2 section-sticky-header">

<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>

</div>

  <div class="row mt-3 justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-lg border-0">
      
<div class="card-body user-form login-form d-none p-4">

  <form id="loginForm" class="needs-validation" novalidate>
    
    <?php if ( !empty( $api->AppSettings['google']['secret']) ){?>
    <!-- Google Login -->
    <a href="<?php echo $api->site_url() . '/api/glogin';?>" id="googleLoginBtn"
      class="btn btn-light border w-100 d-flex align-items-center justify-content-center gap-2 mb-3">
      
      <!-- Google Icon -->
      <svg width="18" height="18" viewBox="0 0 48 48">
        <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.6 32.6 29.2 36 24 36c-6.6 0-12-5.4-12-12
          s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l5.7-5.7C34.1 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24
          s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z"/>
        <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.5 16.1 18.9 13 24 13c3.1 0 5.9 1.2 8 3.1l5.7-5.7
          C34.1 6.1 29.3 4 24 4c-7.7 0-14.3 4.3-17.7 10.7z"/>
        <path fill="#4CAF50" d="M24 44c5.1 0 9.8-1.9 13.3-5.2l-6.1-5
          c-2 1.5-4.5 2.4-7.2 2.4-5.2 0-9.6-3.4-11.2-8.1l-6.5 5
          C9.7 39.7 16.3 44 24 44z"/>
        <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3
          c-1.1 3-3.2 5.5-6.1 7.1l6.1 5C39.5 36.9 44 31 44 24
          c0-1.3-.1-2.7-.4-3.5z"/>
      </svg>

      <span>Continue with Google</span>
    </a>

<!-- Divider -->
    <div class="d-flex align-items-center mb-3">
      <hr class="flex-grow-1">
      <span class="px-2 small text-muted">OR</span>      

      <hr class="flex-grow-1">      
    </div>
<?php }?>

<h4 class="mb-4 text-center">Login</h4>


    <!-- Email -->
    <div class="form-floating mb-3">
      <input type="text" class="form-control" name="login" id="user-email"
        placeholder="Email/Username" autocomplete="on" required>
      <label for="user-email">Email address/Username</label>
      <div class="invalid-feedback">Enter a valid email address or username</div>
    </div>

    <!-- Password -->
    <div class="form-floating mb-2">
      <input type="password" class="form-control" name="password"
        id="login-user-password" placeholder="Password"
        autocomplete="off" required>
      <label for="login-user-password">Password</label>
      <div class="invalid-feedback">Enter valid password</div>
    </div>

    <!-- Forgot Password -->
    <div class="text-end mb-3">
      <a href="javascript: void(0);" onclick="togglePage('sectionForgotPassword');" class="small text-decoration-none">
        Forgot password?
      </a>
    </div>

    <!-- Login Button -->
    <button type="submit" class="btn btn-primary w-100 mb-4">
      Login
    </button>



    <!-- Signup -->
    <div class="text-center">
      <span class="small">Don’t have an account?</span>
      <a href="javascript:void(0);" class="small text-decoration-none fw-semibold" onclick="$('.login-form, .registration-form').toggleClass('d-none');">
        Sign up
      </a>
    </div>

  </form>

</div>
      
     <!--Registration card-->
        <div class="card-body user-form registration-form p-4 d-none">
          <h4 class="mb-4">Register</h4>

          <form id="registerForm" class="needs-validation" novalidate>

            <!-- Full Name -->
            <div class="form-floating mb-3">
              <input type="text" class="form-control" name="name" id="reg-user-fullname" placeholder="Full Name" autocomplete="on"  required>
              <label for="reg-user-fullname">Full Name</label>
              <div class="invalid-feedback">Full name is required</div>
            </div>
         
  <!-- UserName -->
            <div class="form-floating mb-3">
              <input type="text" class="form-control" name="username" id="reg-username" placeholder="Username" autocomplete="on"  >
              <label for="reg-username">Choose a username</label>
              <div class="invalid-feedback">Username is required</div>
            </div>
            
     <!-- Email -->
     <div class="form-floating mb-3">
     <input type="email" class="form-control" name="email" id="reg-user-email" placeholder="name@example.com" autocomplete="on" required>
              <label for="reg-user-email">Email address</label>
              <div class="invalid-feedback">Enter a valid email</div>
            </div>

       <!-- Phone -->
      <div class="form-text mb-2">Whatsapp number preferable for faster communication & delivery</div>
            <div class="form-floating mb-3">
              <input type="tel" class="form-control" name="phone" id="reg-user-phone" placeholder="08012345678" pattern="[0-9+]{10,14}" autocomplete="on" required>
              <label for="reg-user-phone">Phone Number</label>
              <div class="invalid-feedback">Enter a valid phone number</div>
            </div>

            <!-- Address -->
         <div class="form-floating mb-3">
           <select class="form-select nigeria-states" name="state" id="reg-user-state" autocomplete="on" required><option value="">Choose</option></select>
         <label for="reg-user-state">State</label>
         </div>
         
            <div class="form-floating mb-3">
              <textarea class="form-control" name="address" id="reg-user-address" style="height: 100px" autocomplete="on" required></textarea>
              <label for="reg-user-address">Delivery Address</label>
              <div class="invalid-feedback">Address is required</div>
            </div>

<!-- Password -->
            <div class="form-floating mb-3">
              <input type="password" class="form-control" name="password" id="reg-user-pass" placeholder="Password" autocomplete="off" required>
              <label for="reg-user-pass">Password</label>
              <div class="invalid-feedback">Create new password</div>
            </div>
<!-- Confirm Password -->
            <div class="form-floating mb-3">
              <input type="password" class="form-control" name="cpassword" id="reg-user-cpass" placeholder="Confirm Password" autocomplete="off" required>
              <label for="reg-user-cpass">Confirm Password</label>
              <div class="invalid-feedback">Retype password</div>
            </div>
            <!-- Terms -->
            <div class="form-check mb-3 d-non">
              <input class="form-check-input" type="checkbox" name="terms" id="reg-agree-terms">
              <label class="form-check-label" for="reg-agree-terms">
                I agree to the terms and conditions
              </label>
              <div class="invalid-feedback">You must agree before submitting</div>
            </div>

            <!-- Submit -->
            <div class="d-grid">
              <button type="submit" class="btn btn-primary btn-lg">Save</button>
            </div>

          </form>

          <p class="text-center mt-3 mb-0">
            Already have an account? <a class="text-decoration-none" href="javascript: void(0);" onclick="$('.login-form, .registration-form').toggleClass('d-none');">Login</a>
          </p>         
        </div>
        
        
 <!--Profile card-->
        <div class="card-body user-form profile-form p-4 d-none">
          <h4 class="mb-4" id="profile-form-title">Profile</h4>

          <form id="profileForm" class="needs-validation" novalidate>

            <!-- Full Name -->
            <div class="form-floating mb-3">
              <input type="text" class="form-control" name="name" id="user-fullname" placeholder="Full Name" autocomplete="on"  required>
              <label for="user-fullname">Full Name</label>
              <div class="invalid-feedback">Full name is required</div>
            </div>
     <!-- Email -->
     <div class="form-floating mb-3">
     <input type="email" class="form-control" name="email" id="user-email" placeholder="name@example.com" autocomplete="on" required>
              <label for="user-email">Email address</label>
              <div class="invalid-feedback">Enter a valid email</div>
            </div>

       <!-- Phone -->
            <div class="form-floating mb-3">          
              <input type="tel" class="form-control" name="phone" id="user-phone" placeholder="08012345678" pattern="[0-9+]{10,14}" autocomplete="on" required>
              <label for="user-phone">Phone Number <small><i>(Whatsapp preferable)</i></small></label>           
              <div class="invalid-feedback">Enter a valid phone number</div>
            </div>

            <!-- Address -->
         <div class="form-floating mb-3">
           <select class="form-select nigeria-states" name="state" id="user-state" autocomplete="on" required><option value="">Choose</option></select>
         <label for="user-state">State</label>
         </div>
         
            <div class="form-floating mb-3">
              <textarea class="form-control" name="address" id="user-address" style="height: 100px" autocomplete="on" required></textarea>
              <label for="user-address">Delivery Address</label>
              <div class="invalid-feedback">Address is required</div>
            </div>

            <!-- Submit -->
            <div class="d-grid">
              <button type="submit" class="btn btn-primary btn-lg">Save</button>
            </div>

          </form>         
        </div>       
           
   
           
      </div>

    </div>
  </div>
  
 </div>
</section>


<section class="hidden-section"  id="sectionForgotPassword">
<div class="page-blur"></div>

<div class="py-2 section-sticky-header">

<div class="section-data container pt-2 pb-5 h-h75 wh-75">

<div class="d-flex justify-content-start align-items-center">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
</div>
<div>

          <h4>Forgot Password</h4>
</div>
</div>

       <div class="card-body mt-4">

<p class="text-muted mb-0">
                                Enter your registered email address to receive a password reset link.
                            </p>

    <form id="forgot-password-form" novalidate>

                            <!-- Email -->
                            <div class="mb-4">

                                <label class="form-label fw-semibold">
                                    Email Address
                                </label>

                                <input
                                    type="email"
                                    class="form-control form-control-lg"
                                    id="forgot-email"
                                    name="email"
                                    placeholder="john@example.com"
                                    required
                                >

                                <div class="invalid-feedback">
                                    Enter a valid email address.
                                </div>

                            </div>

                            <!-- Submit -->
                            <button
                                type="submit"
                                class="btn btn-primary btn-lg w-100 rounded-3"
                                id="forgot-btn"
                            >
                                Send Reset Link
                            </button>
                       </form>
           
        </div>
  </section>
        
<?php require(__DIR__ . '/sections/footer.php'); ?>
</body>
</html>
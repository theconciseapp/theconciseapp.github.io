<?php
require "../ProjectClasses/bootstrap.php";
require "../ProjectClasses/main.php";

$api=new ProjectAPI();

 $response=$api->verifyToken($_COOKIE[$api->cookieName]??'', true);

 if( !$response['success']  ){
	header("Location: login.php?redirect=" . urlencode($api->site_url() . '/admin'));
	exit;
}

include('sections/header.php');?>

<!--ORDERS-->

<section id="sectionOrdersList">
<div class="container-fluid mt-2">

  <div class="row">
  
    <!-- Orders List -->
    <div class="col-12">
      <h5>Orders</h5>

<div class="row mb-3 g-2">

  <!-- Search -->
  <div class="col-md-3">
  <label for="orders-search">Search</label>
    <input type="text" id="orders-search" class="form-control" placeholder="Order UID or Payment Ref.">
  </div>

  <!-- Status -->
  <div class="col-md-2">
  <label for="orders-status">Order Status</label>
    <select id="orders-status" class="form-select">
      <option value="">--</option>
      <option value="pending">Pending</option>
      <option value="processing">Processing</option>
      <option value="shipped">Shipped</option>
      <option value="delivered">Delivered</option>
      <option value="cancelled">Cancelled</option>
     <option value="expired">Expired</option>
    </select>
  </div>

<!--Payment status-->
<div class="col-md-2">
  <label for="orders-payment-status">Payment Status</label>
    <select id="orders-payment-status" class="form-select">
      <option value="">--</option>
      <option value="pending">Pending</option>
      <option value="paid">Paid</option>
      <option value="failed">Failed</option>
      <option value="refunded">Refunded</option>
      <option value="partially_refunded">Partially Refunded</option>
    </select>
</div>

  <!-- Date From -->
  <div class="col-md-2">
  <label for="orders-from">Date (From)</label>
    <input type="date" id="orders-from" class="form-control">
  </div>

  <!-- Date To -->
  <div class="col-md-1">
  <label for="orders-to">Date (To)</label>
    <input type="date" id="orders-to" class="form-control">
  </div>

  <!-- Button -->
  <div class="col-md-2">
  <label for="orders-filter-btn"></label>
    <button class="btn btn-secondary w-100" id="orders-filter-btn" onclick="loadOrders(this);">Filter</button>
  </div>
</div>


      <div class="table-responsive">
        <table class="table table-hover table-bordered" style="min-width: 700px;">
          <thead class="table-light">
            <tr>
              <th>#</th>
              <th>Total</th>
              <th>Payment</th>
              <th>Delivery</th>
              <th>Total Items</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="ordersTable"></tbody>
        </table>
      </div>
      
            <nav class="mt-2 mb-5 text-center">
<button id="prevOrders"  class="btn btn-sm btn-warning d-none" data-page="" onclick="loadOrders(this);">Previous</button>
<button id="nextOrders" class="ms-2 btn btn-sm btn-warning d-none" data-page="" onclick="loadOrders(this);">Next</button>

</nav>
        
    </div>

  </div>
</div>

</section>


<!-- Products-->
<section class="hidden-section" id="sectionProductsList">
 <div class="section-data container-fluid py-4">

  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h4><i class="fas fa-box"></i> Products</h4>
    <button class="btn btn-primary" onclick="togglePage('sectionProductForm','resetProductForm');">
      <i class="fas fa-plus"></i> Add Product
    </button>
  </div>

  <!-- Filters -->
  <div class="card mb-3">
    <div class="card-body row g-2">

      <div class="col-md-4">
        <input type="text" id="product-search" class="form-control" placeholder="Search product...">
      </div>

      <div class="col-md-3">
        <select id="product-filterCategory" class="form-select"></select>
      </div>

      <div class="col-md-2">
        <button class="btn btn-secondary w-100" onclick="loadProducts(this)">
          <i class="fas fa-search"></i> Filter
        </button>
      </div>

    </div>
  </div>

  <!-- Table -->
  <div class="card">
    <div class="table-responsive">
      <table class="table align-middle mb-0" style="min-width: 700px;">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Image</th>
            <th>Name</th>
         <!--   <th>Categories</th>-->
            <th>Price</th>
            <th>Status</th>
            <th width="120">Action</th>
          </tr>
        </thead>
        <tbody id="productsTable"></tbody>
      </table>
    </div>
  </div>

  <!-- Pagination -->
  <div class="d-flex justify-content-between align-items-center mt-3">
    <small id="paginationInfo"></small>
    <div>
      <nav class="text-center">
<button id="prevProducts"  class="btn btn-sm btn-warning d-none" data-page="" onclick="loadProducts(this);">Previous</button>
<button id="nextProducts" class="ms-2 btn btn-sm btn-warning d-none" data-page="" onclick="loadProducts(this);">Next</button>

</nav>
    </div>
  </div>

</div>
</section>

<!--CREATE PRODUCT-->
<section class="hidden-section"  id="sectionProductForm">
<div class="page-blur"></div>
<div class="section-data container py-5">


  <div class="card shadow-sm">
    <div class="card-header">
      <h5 class="mb-0">
        <i class="fas fa-box"></i>
        <span id="productFormTitle">Add Product</span>
      </h5>
    </div>

    <div class="card-body">
      <form id="productForm">

        <input type="text" id="product-product_id" value="" class="d-none">

<!-- Status-->
          <div class="mb-3">
            <label class="form-label" for="product-status">Status</label>
            <select id="product-status" class="form-select">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="draft">Draft</option>
           </select>
          </div>

<!-- Featured Rank-->
          <div class="mb-3">
            <label class="form-label" for="product-featured">Featured Rank (Leave if it's not a featured product)</label>
            <select id="product-featured-rank" class="form-select">
            <option>0</option>
            <option>1</option>
            <option>2</option>
            <option>3</option>
            <option>4</option>
            <option>5</option>
           </select>
          </div>

        <div class="row">
        
          <!-- Name -->
          <div class="col-md-6 mb-3">
            <label class="form-label">Product Name</label>
            <input type="text" id="product-name" class="form-control" required>
            <div class="invalid-feedback">Product name is required</div>
          </div>

          <!-- Slug -->
          <div class="col-md-6 mb-3">
            <label class="form-label">Slug (optional)</label>
            <input type="text" id="product-slug" class="form-control">
          </div>

          <!-- Price -->
          <div class="col-md-4 mb-3">
            <label class="form-label">Regular Price</label>
            <input type="number" id="product-price" class="form-control" required>
            <div class="invalid-feedback">Regular price required</div>
          </div>

          <!-- Sale Price -->
          <div class="col-md-4 mb-3">
            <label class="form-label">Sale Price</label>
            <input type="number" id="product-sale_price" class="form-control">
          </div>

          <!-- Cost Price -->
          <div class="col-md-4 mb-3">
            <label class="form-label">Cost Price</label>
            <input type="number" id="product-cost_price" class="form-control">
          </div>

          <!-- Stock -->
          <div class="col-md-6 mb-3">
            <label class="form-label">Stock Quantity</label>
            <input type="number" id="product-stock_quantity" class="form-control" value="0">
          </div>

          <!-- Image -->
          <div class="col-md-6 mb-3">
          
  <div id="product-images-selected"></div> 
         
   <a class="text-decoration-none text-primary" href="javascript:void(0);" onclick="togglePage('sectionGallery','loadGallery','showSelectedImages');">Select product images</a>

          </div>

        </div>

        <!-- Categories (MULTI SELECT) -->
        <div class="mb-3">
          <label class="form-label">
            <i class="fas fa-tags"></i> Categories
          </label>
          <select id="product-categories" class="form-select" multiple></select>
          <small class="text-muted">Hold Ctrl (or tap multiple) to select multiple</small>
        </div>

<!--Short Description -->
        <div class="mb-3">
          <label class="form-label">Short Description (SEO)</label>
          <textarea id="product-description" class="form-control" rows="2"></textarea>
        </div>

        <!-- Full Description -->
        <div class="mb-3">
          <label class="form-label">Description</label>
          <textarea id="product-full-description" class="form-control" rows="4"></textarea>
        </div>

        <!-- Actions -->
        <div class="d-flex justify-content-between">
          <button type="button" class="btn btn-light" onclick="goBack();"><i class="fas fa-arrow-left"></i> Back</button>
          <button type="submit" class="btn btn-success" id="save-product-btn">
            <i class="fas fa-save"></i> Save Product
          </button>
        </div>

      </form>
    </div>
  </div>

</div>
</section>


<!--ORDER ITEMS-->

<section class="hidden-section"  id="sectionOrderItemsList">
<div class="page-blur"></div>
<div class="section-data container pt-2 pb-5">

<div class="d-flex justify-content-start align-items-center mb-2">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div>
<b class="ms-3">Order Details</b>
</div>
</div>

    <!-- Orders List -->
    
      <div id="orderDetails" class="border rounded p-3 bg-light">
      
      </div>
     
</div>

</section>

<section class="hidden-section"  id="sectionAdjustOrder">
<div class="page-blur"></div>
<div class="section-data container pt-2 pb-5">

<div class="d-flex justify-content-start align-items-center mb-2">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div>
<b class="ms-3">Update Order</b>
</div>
</div>

<div class="row g-4">

<div class="col-lg-4">

<div class="card shadow-sm">

<div class="card-body" id="orderAdjustDetails"></div>

</div>

</div>


<div class="col-lg-8">

<div class="card shadow-sm">

<div class="card-header d-flex justify-content-between align-items-center">

<h5 class="mb-0">Ordered Products</h5>

<button class="btn btn-primary btn-sm d-none" id="addItem">
Add Item
</button>

</div>

<div class="card-body p-0">

<div class="table-responsive">

<table class="table table-bordered align-middle mb-0" id="adjustOrderTable" style="min-width: 550px;">

<thead class="table-light">

<tr>
<th width="90">Image</th>
<th width="140">Product</th>
<th width="130">Price</th>
<th width="90">Qty</th>
<th width="160">Total</th>
<th width="40">Action</th>
</tr>

</thead>

<tbody></tbody>

</table>

</div>

</div>

</div>


<div class="card shadow-sm mt-4">

<div class="card-body">

<div class="d-flex justify-content-between mb-2">

<strong>Grand Total</strong>

<h4>
₦<span id="grandTotal">0</span>
</h4>

</div>

<button class="btn btn-success" onclick="saveAdjustedOrder(this)">
Save Changes
</button>

</div>

</div>

</div>

</div>

    </div>
</section>



<!--CATEGORIES-->

<section class="hidden-section"  id="sectionCategoriesList">
<div class="page-blur"></div>
<div class="section-data container py-5">

<div class="row">
        <div class="col-12">

            <div class="card shadow-sm">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="mb-0">Categories</h4>
                        <button class="btn btn-primary btn-sm" onclick="togglePage('sectionCreateCategory','resetCatForm');">
                            + New Category
                        </button>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover table-min-width-2 align-middle">
    
  <thead>
    <tr>
      <th>Name</th>
      <th>Slug</th>
      <th>Parent</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody id="categoriesListTable"></tbody>
                        </table>
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</div>

</section>

<!--CREATE CATEGORY-->

<section class="hidden-section"  id="sectionCreateCategory">
<div class="page-blur"></div>
<div class="section-data container py-5">

<div class="card shadow-sm">
    <div class="card-header">
      <h5 class="mb-0">
        <i class="fas fa-tags"></i>
        <span id="catFormTitle">Add Category</span>
      </h5>
    </div>

    <div class="card-body">
      <form id="createCategoryForm">

        <input type="text" id="category_id" value="" class="d-none">

        <div class="row">
          <!-- Name -->
          <div class="col-md-6 mb-3">
            <label class="form-label">
              <i class="fas fa-font"></i> Category Name
            </label>
            <input type="text" id="name" class="form-control" required minlength="3">
            <div class="invalid-feedback">
                Category name is required (min 3 characters).
              </div>
          </div>

          <!-- Slug -->
          <div class="col-md-6 mb-3">
            <label class="form-label">
              <i class="fas fa-link"></i> Slug
            </label>
            <input type="text" id="slug" name="cat_slug" class="form-control">
            
        <div class="invalid-feedback">
                Slug
              </div>    
            
          </div>
        </div>

        <!-- Parent -->
        <div class="mb-3">
          <label class="form-label">
            <i class="fas fa-sitemap"></i> Parent Category
          </label>
          <select id="parent_id" name="cat_parent" class="form-select">
            <option value="">None (Top Level)</option>
          </select>
        </div>

        <!-- Description -->
        <div class="mb-3">
          <label class="form-label">
            <i class="fas fa-align-left"></i> Description
          </label>
          <textarea id="description" name="cat_desc" class="form-control" rows="3" maxlength="200"></textarea>
          
          <div class="invalid-feedback">
                Description too long
              </div>
        </div>

<!-- Icon -->
          <div class="col-md-6 mb-3">
            <label class="form-label">
              <i class="fas fa-shoe-prints"></i> Icon
            </label>
            <input type="text" id="catz-icon" class="form-control" placeholder="Font awesome icon e.g fas fa-socks">
          </div>

        <!-- Actions -->
        <div class="d-flex justify-content-between">
          <button type="button" onclick="goBack();" class="btn btn-light">
            <i class="fas fa-arrow-left"></i> Back
          </button>

          <button type="submit" class="btn btn-success">
            <i class="fas fa-save"></i> Save Category
          </button>
        </div>

      </form>
    </div>
  </div>

</div>
</section>


<!-- Gallery -->
<section class="hidden-section"  id="sectionGallery">
<div class="page-blur"></div>
<div class="section-data container py-5">

<div class="card">
  <div class="card-body">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="fw-bold mb-0">Gallery</h5>
      <button class="btn btn-sm btn-outline-secondary" id="refreshGallery">
        <i class="fas fa-sync"></i>
      </button>
    </div>

    <div id="galleryGrid" class="row g-2"></div>
    
    <!-- Pagination -->
  
      <nav class="text-center my-3">
<button id="prevGallery"  class="btn btn-sm btn-warning d-none" data-page="" onclick="loadGallery(this);">Previous</button>
<button id="nextGallery" class="ms-2 btn btn-sm btn-warning d-none" data-page="" onclick="loadGallery(this);">Next</button>

</nav>
    
   
<!-- Actions -->
        <div class="d-flex justify-content-between">
          <button type="button" onclick="goBack();" class="m-back-btn btn btn-outline-secondary">
            <i class="fas fa-arrow-left"></i> Back
          </button>
        </div>

  </div>
</div>

</div>                   

</section>

<!-- Upload -->
<section class="hidden-section"  id="sectionUpload">
<div class="page-blur"></div>
<div class="section-data container py-5">

<div class="card">
  <div class="card-body">

    <label class="form-label fw-bold">Product Images (Max 4)</label>

    <div id="uploadArea" class="border rounded p-4 text-center bg-light position-relative" style="cursor:pointer;">
      <p class="mb-1">Drag & drop images here</p>
      <small class="text-muted">or click to select (max 4)</small>

      <input type="file" id="imageInput" multiple accept="image/*"
             class="position-absolute top-0 start-0 w-100 h-100 opacity-0">
    </div>

    <div id="previewContainer" class="row g-2 mt-3"></div>

<div class="mt-2">
<button type="button" class="btn btn-primary" id="image-upload-btn">Upload now</button>
</div>


    <input type="hidden" name="uploaded_images" id="uploadedImages">

  </div>
</div>

</div>                   

</section>


<section class="hidden-section"  id="sectionSettings">
<div class="page-blur"></div>
<div class="section-data container py-5">

<ul class="nav nav-tabs">
  <li class="nav-item">
    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#siteSettings">
      Site
    </button>
  </li>
 <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#mediaSettings">
      Media Settings
    </button>
  </li>
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#orderSettings">
      Order Settings
    </button>
  </li>

<li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#shippingSettings">
      Shipping
    </button>
  </li>
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#paymentSettings">
      Payment API
    </button>
  </li>
  
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#contactSettings">
      Contacts
    </button>
  </li>
   <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#workdaysSettings">
      Open & Close Hours
    </button>
  </li>
  
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#currencySettings">
      Currency
    </button>
  </li>
   
         <li class="nav-item d-none">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#featuresSettings">
      Features
    </button>
  </li>
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#googleLoginSettings">
      Google Login
    </button>
  </li> 
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#cloudflareSettings">
      Cloudflare Setup
    </button>
  </li> 
    <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#dropboxSettings">
      Dropbox Setup
    </button>
  </li> 
  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#emailSettings">
      Email Config. (PHPMailer)
    </button>
  </li>   
</ul>

<div class="tab-content mt-3">

  <!-- ================= MANAGE TAB ================= -->
  <div class="tab-pane fade show active" id="siteSettings">

<!-- APP -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-cube"></i> Site</span>
    <button class="btn btn-sm btn-primary save-section" data-section="app">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="app">

      <label class="form-label">Site Name</label>
      <input class="form-control mb-3" name="app.name" placeholder="Site Name">

<label class="form-label">Site Title</label>
      <input class="form-control mb-3" name="app.title" placeholder="Site Title">

<label class="form-label">Site Description</label>
      <input class="form-control mb-3" name="app.description" placeholder="Description">
      
      <label class="form-label">Logo</label>
      <input class="form-control mb-3" name="app.logo" placeholder="Logo">

      <label class="form-label">Version</label>
      <input class="form-control mb-3" name="app.version" placeholder="Version" readonly>

      <label class="form-label">Environment</label>
      <select class="form-select mb-3" name="app.environment">
        <option value="development">Development</option>        
        <option value="production">Production</option>
        <option value="maintenance">Under Maintenance</option>
      </select>

    </form>
  </div>
</div>

</div>

<div class="tab-pane fade" id="mediaSettings">

<!-- Media -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-cube"></i> Media</span>
    <button class="btn btn-sm btn-primary save-section" data-section="media">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="media">

      <label class="form-label">Media Storage</label>
      <div class="form-text">
      Setup Cloudflare or Dropbox if you intend to use external file storage</div>
      <select class="form-select mb-3" name="media.storage">
        <option value="local">Local</option>        
        <option value="cloudflare">CloudFlare</option>
        <option value="dropbox">Dropbox</option>
      </select>

    </form>
  </div>
</div>

</div>

<div class="tab-pane fade" id="paymentSettings">
<!-- PAYMENT -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-credit-card"></i> Payment</span>
    <button class="btn btn-sm btn-primary save-section" data-section="payment">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="payment">

      <label class="form-label">Provider</label>
      <select class="form-select mb-3" name="payment.provider">
      <option value="paystack">Paystack</option>
      </select>

      <label class="form-label">Public Key</label>
      <input class="form-control mb-3" name="payment.publicKey" placeholder="Public Key">

      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" name="payment.enablePod" id="paymentPod">
        <label class="form-check-label" for="paymentPod">Enable Pay on Delivery</label>
      </div>

    </form>
  </div>
</div>
</div>

<div class="tab-pane fade" id="contactSettings">
<!-- CONTACT -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-phone"></i> Contact</span>
    <button class="btn btn-sm btn-primary save-section" data-section="contact">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="contact">

      <label class="form-label">Phone</label>
      <input class="form-control mb-3" name="contact.phone" placeholder="Phone">

      <label class="form-label">WhatsApp</label>
      <input class="form-control mb-3" name="contact.whatsapp" placeholder="WhatsApp (234...)">

      <label class="form-label">Email</label>
      <input class="form-control mb-3" name="contact.email" placeholder="Email">

      <label class="form-label">Address</label>
      <textarea class="form-control mb-3" name="contact.address" placeholder="Address"></textarea>

      <label class="form-label">Map Query</label>
      <input class="form-control mb-3" name="contact.map" placeholder="Map Query">

    </form>
  </div>
</div>
</div>

<div class="tab-pane fade" id="workdaysSettings">
<!-- BUSINESS DAYS -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-calendar"></i> Business Days</span>
    <button class="btn btn-sm btn-primary save-section" data-section="business_days">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="business_days">

      <label class="form-label">Opening Hours</label>
      <input class="form-control mb-3" name="business_days.open" placeholder="Opening Hours">

      <label class="form-label">Closing Days</label>
      <input class="form-control mb-3" name="business_days.close" placeholder="Closing Days">

    </form>
  </div>
</div>
</div>
<div class="tab-pane fade" id="siteSettings">
<!-- API -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-plug"></i> API</span>
    <button class="btn btn-sm btn-primary save-section" data-section="api">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="api">

      <label class="form-label">Base URL</label>
      <input class="form-control mb-3" name="api.baseUrl" placeholder="Base URL" disabled>

      <label class="form-label">Timeout (ms)</label>
      <input class="form-control mb-3" type="number" name="api.timeout" placeholder="Timeout (ms)">

    </form>
  </div>
</div>

</div>

<div class="tab-pane fade" id="currencySettings">
<!-- CURRENCY -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-money-bill"></i> Currency</span>
    <button class="btn btn-sm btn-primary save-section" data-section="currency">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="currency">

      <label class="form-label">Code</label>
      <input class="form-control mb-3" name="currency.code" placeholder="Code (NGN)">

      <label class="form-label">Symbol</label>
      <input class="form-control mb-3" name="currency.symbol" placeholder="Symbol (₦)">

      <label class="form-label">Locale</label>
      <input class="form-control mb-3" name="currency.locale" placeholder="Locale (en-NG)">

    </form>
  </div>
</div>
</div>

<div class="tab-pane fade" id="orderSettings">
<!--ORDER SETTINGS-->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-shopping-cart"></i> Orders</span>
    <button class="btn btn-sm btn-primary save-section" data-section="orders">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="orders">

<div class="mb-3">
      <label class="form-label">Maximum order items</label>
      <div class="form-text">
      Maximum number of unique items(products) that can be ordered at once</div>
      <input class="form-control" type="number" name="orders.maxOrderItems" placeholder="">
</div>
<div class="mb-3">
      <label class="form-label">
Maximum number of days before a pending order expires
</label>
      <input class="form-control mb-3" type="number" name="orders.maxOrderPendingDays" placeholder="">
</div>

    </form>
  </div>
</div>
</div>



<div class="tab-pane fade" id="shippingSettings">
<!-- SHIPPING -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-truck"></i> Shipping</span>
    <button class="btn btn-sm btn-primary save-section" data-section="shipping">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="shipping">

<div class="mb-3 d-none">
      <label class="form-label">Flat Rate</label>
      <input class="form-control" type="number" name="shipping.flatRate" placeholder="Flat Rate">
</div>
<div class="mb-3 d-none">
      <label class="form-label">Free Shipping Threshold</label>
      <input class="form-control mb-3" type="number" name="shipping.freeShippingThreshold" placeholder="Free Shipping Threshold">
</div>
      <label class="form-label">Max Delivery Days</label>
      <input class="form-control mb-3" type="number" name="shipping.maxDate" placeholder="Max Delivery Days">

    </form>
  </div>
</div>
</div>

<div class="tab-pane fade" id="featuresSettings">
<!-- FEATURES -->
<div class="card mb-4 d-none">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-toggle-on"></i> Features</span>
    <button class="btn btn-sm btn-primary save-section" data-section="features">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="features">

      <div class="form-check form-switch mb-2">
        <input class="form-check-input" type="checkbox" name="features.enableCoupons" id="featCoupons">
        <label class="form-check-label" for="featCoupons">Enable Coupons</label>
      </div>

      <div class="form-check form-switch mb-2">
        <input class="form-check-input" type="checkbox" name="features.enableWishlist" id="featWishlist">
        <label class="form-check-label" for="featWishlist">Enable Wishlist</label>
      </div>

      <div class="form-check form-switch">
        <input class="form-check-input" type="checkbox" name="features.enableReviews" id="featReviews">
        <label class="form-check-label" for="featReviews">Enable Reviews</label>
      </div>

    </form>
  </div>
</div>
</div>

<!-- Google Login-->
<div class="tab-pane fade" id="googleLoginSettings">

<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fab fa-google"></i> Google</span>
    <button class="btn btn-sm btn-primary save-section" data-section="google">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="google">

      <label class="form-label">Client Id</label>
      <input class="form-control mb-3" name="google.clientid" placeholder="Client Id">
      
    <label class="form-label">Google Secret</label>
      <input class="form-control mb-3" name="google.secret" placeholder="Secret Key">
      <label class="form-label">Redirect Url</label>
      <input class="form-control mb-3" name="google.redirect" placeholder="Redirect Url">
</form>
</div>
</div>
</div>

<!-- Cloudflare R2 -->
<div class="tab-pane fade" id="cloudflareSettings">

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between">
            <span>
                <i class="fas fa-cloud"></i> Cloudflare R2
            </span>
            <button class="btn btn-sm btn-primary save-section" data-section="cloudflare">
                Save
            </button>
        </div>

        <div class="card-body">
            <form class="section-form" data-section="cloudflare">

                <label class="form-label">Account ID</label>
                <input class="form-control mb-3"
                       name="cloudflare.account_id"
                       placeholder="Cloudflare Account ID">

                <label class="form-label">Access Key ID</label>
                <input class="form-control mb-3"
                       name="cloudflare.access_key"
                       placeholder="Access Key ID">

                <label class="form-label">Secret Access Key</label>
                <input type="password"
                       class="form-control mb-3"
                       name="cloudflare.secret_key"
                       placeholder="Secret Access Key">

                <label class="form-label">Bucket Name</label>
                <input class="form-control mb-3"
                       name="cloudflare.bucket"
                       placeholder="Bucket Name">

                <label class="form-label">Public URL</label>
                <input class="form-control mb-3"
                       name="cloudflare.public_url"
                       placeholder="https://cdn.example.com">

                <label class="form-label">Endpoint</label>
                <input class="form-control mb-3"
                       name="cloudflare.endpoint"
                       placeholder="https://ACCT_ID.r2.cloudflarestorage.com">

            </form>
        </div>
    </div>
</div>



<!-- Dropbox -->
<div class="tab-pane fade" id="dropboxSettings">

    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between">
            <span>
                <i class="fab fa-dropbox"></i> Dropbox
            </span>
            <button class="btn btn-sm btn-primary save-section" data-section="dropbox">
                Save
            </button>
        </div>

        <div class="card-body">
            <form class="section-form" data-section="dropbox">

                <label class="form-label">App Key</label>
                <input class="form-control mb-3"
                       name="dropbox.app_key"
                       placeholder="Dropbox App Key">

                <label class="form-label">App Secret</label>
                <input type="password"
                       class="form-control mb-3"
                       name="dropbox.app_secret"
                       placeholder="Dropbox App Secret">

                <label class="form-label">Access Token</label>
                <input type="password"
                       class="form-control mb-3"
                       name="dropbox.access_token"
                       placeholder="Dropbox Access Token">

                <label class="form-label">Refresh Token</label>
                <input type="password"
                       class="form-control mb-3"
                       name="dropbox.refresh_token"
                       placeholder="Dropbox Refresh Token">

                <label class="form-label">Root Folder</label>
                <input class="form-control mb-3"
                       name="dropbox.folder"
                       placeholder="uploads">

            </form>
        </div>
    </div>

</div>

<!-- Email settings-->
<div class="tab-pane fade" id="emailSettings">
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fas fa-inbox"></i> Email Configuration</span>
    <button class="btn btn-sm btn-primary save-section" data-section="email">Save</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="email">

      <label class="form-label">Channel</label>
      <div class="form-text">If you select Default, you may leave other fields as it is</div>
      <select class="form-select mb-3" name="email.channel"><option value="phpmailer">PHPMailer</option>
      <option value="default">Default</option></select>
      
    <label class="form-label">SMTP Host</label>
      <input class="form-control mb-3" name="email.host" placeholder="Host">
      <label class="form-label">SMTP authentication</label>
     <select class="form-select mb-3" name="email.authentication"><option value="1">True</option>
      <option value="0">False</option></select>
      
    <label class="form-label">SMTP Username</label>
    <div class="form-text">Username to connect to SMTP sever</div>
      <input class="form-control mb-3" name="email.username" placeholder="Username">  
      <label class="form-label">SMTP Password</label>
      <div class="form-text">Password to connect to SMTP server</div>
      <input class="form-control mb-3" name="email.password" placeholder="Password">  
      <label class="form-label">Type of Encryption</label>
      <div class="form-text">Encryption to be used when sending an email (TLS/SSL. TLS recommended)</div>
      <select class="form-select mb-3" name="email.encryption"><option value="tls">TLS / STARTTLS (Recommended)</option>
      <option value="ssl">SSL / SMTPS</option>
      <option value="">NONE</option>
</select>
      
      <label class="form-label">SMTP Port</label>
      <div class="form-text">Port to be used when sending an Email (587, 465). If you choose TLS above, the port should be 587. For SSL, use port 465 instead</div>
      <input class="form-control mb-3" name="email.port" placeholder="Port">  
      
    <label class="form-label">From email</label>
    <div class="form-text">Some email providers requires you to set sender email. You may enter your business email. E.g support@your-domain.com</div>
      <input type="email"  class="form-control mb-3" name="email.from" placeholder="company@email.com">    
     
<label class="form-label">From alias</label>
      <input type="text"  class="form-control mb-3" name="email.alias" placeholder="Company name">
      <label class="form-label">Reply To</label>
      <input type="email"  class="form-control mb-3" name="email.reply_to" placeholder="reply@example.com">    
 
</form>
</div>
</div>
</div>

<div class="tab-pane fade" id="storageSettings">
<!-- STORAGE -->
<div class="card mb-4">
  <div class="card-header d-flex justify-content-between">
    <span><i class="fa fa-database"></i> Storage Keys</span>
    <button class="btn btn-sm btn-secondary" disabled>System</button>
  </div>
  <div class="card-body">
    <form class="section-form" data-section="storageKeys">

      <label class="form-label">Cart Key</label>
      <input class="form-control mb-3" name="storageKeys.cart" readonly>

      <label class="form-label">User Key</label>
      <input class="form-control mb-3" name="storageKeys.user" readonly>

    </form>
  </div>
</div>
</div>


</div>
</section>


<!--LIST Pages-->

<section class="hidden-section"  id="sectionPagesList">
<div class="page-blur"></div>
<div class="section-data container pt-2 pb-5">

<div class="d-flex justify-content-start align-items-center mb-2">
<div>
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div class="ps-2">
          <h4>Pages</h4>
</div>
</div>

  <!-- Header -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="form-text">Site  pages</div>
    <button class="btn btn-primary" id="btnAddPage" onclick="createPageForm();">
      <i class="fa fa-plus"></i> Create Page
    </button>
  </div>

<div class="mb-2">
<button class="btn btn-sm btn-success me-1 filter-page-btn" id="all-pages-filter-btn" onclick="filterPages(this);">All</button>

<button class="btn btn-sm btn-secondary me-1 filter-page-btn" onclick="filterPages(this, 'published');">Published</button>

<button class="btn btn-sm btn-secondary me-1 filter-page-btn" onclick="filterPages(this, 'draft');">Draft</button>

<button class="btn btn-sm btn-secondary me-1 filter-page-btn" onclick="filterPages(this, 'deleted');">Trashed</button>
</div>

  <!-- Pages Table -->
  <div class="card">
    <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0" style="min-width: 450px;">
        <thead class="table-light">
          <tr>
            <th>Title</th>
            <th>Slug</th>
            <th>Status</th>
            <th style="width:150px;">Actions</th>
          </tr>
        </thead>
        <tbody id="pageTableBody">
          <!-- Filled dynamically -->
        </tbody>
      </table>
      </div>
    </div>
  </div>

</div>

</section>

<!-- Create/Edit page -->


<section class="hidden-section"  id="sectionCreatePage">
<div class="page-blur"></div>
<div class="section-data container pt-2 pb-5">

<button class="btn btn-outline-secondary m-back-btn mb-2" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>

        <form id="createPageForm">

          <input type="text" name="id"  id="pageId" class="d-none">

          <div class="mb-3">
            <label class="form-label">Title</label>
            <input type="text" name="title" id="pageTitle" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">Slug</label>
            <input type="text" name="slug" id="pageSlug" class="form-control">
          </div>

          <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content"  id="pageContent" class="form-control" rows="6"></textarea>
          </div>
<div class="mb-3">
            <label class="form-label">Short Description (SEO)</label>
            <textarea name="description"  id="pageDescription" class="form-control" rows="2" maxlength="200"></textarea>
          </div>

          <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" id="pageStatus" class="form-select">
              <option value="draft">Draft</option>
              <option value="published" selected>Published</option>
            </select>
          </div>

        </form>

        <button class="btn btn-primary" id="savePage" onclick="savePage(this);">Save</button>
     
</div>
</section>


<section class="hidden-section"  id="sectionMenuPage">
<div class="page-blur"></div>
<div class="section-data container pt-2 w-md-75 h-md-75 pb-5">
     <h4 class="mb-4">Menu</h4>

    <ul class="nav nav-tabs">
  <li class="nav-item">
    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#manageTab">
      Manage Menus
    </button>
  </li>

  <li class="nav-item">
    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#addTab">
      Create Menu Item
    </button>
  </li>
</ul>

<div class="tab-content mt-3">

  <!-- ================= MANAGE TAB ================= -->
  <div class="tab-pane fade show active" id="manageTab">

<div class="container-fluid">
<div class="row">
<div class="col-md-6">

  <div class="mb-3">
  <div class="text-muted mb-2">Drag Menus to menu locations</div> 
<div id="list-menus"></div>
   </div>
   
</div>   
   <div class="col-md-6">
<hr class="d-md-none" />

    <div class="mb-3">
      <h6>Menu Locations</h6>
   
    <div class="d-flex align-items-center gap-2 mb-3">
<div class="w-100">
<select id="menu-list-2-type" class="form-select">
        <option value="header">Header Menu</option>
        <option value="footer">Footer Menu</option>
      </select>
   </div>
   <div class="flex-shrink-0">   
      <button class="btn btn-primary" onclick="loadMenuByKey()">
      Load
    </button>
    </div>
</div>    
      
    </div>


    <div id="menu-list-2" class="list-group"></div>

    <button class="btn btn-success mt-3" onclick="saveMenu('menu-list-2', true)">
      Save Menu
    </button>
</div>
</div>
</div>

  </div>

  <!-- ================= ADD TAB ================= -->
  <div class="tab-pane fade" id="addTab">


<div class="mb-3">
  <details>
<summary>Pages</summary> 
<div id="list-menu-pages"></div>
</details>
   </div>

<div class="mb-3">
  <details>
<summary>Categories</summary> 
<div id="list-menu-categories"></div>
</details>
   </div>

    <div class="mb-3">
     <details>
<summary>Custom Menu</summary>
 
<div class="mb-2">
<label for="new-menu-title">Menu Title</label>
<input type="text" id="new-menu-title" class="form-control" placeholder="Menu Title">
                </div>
                <div class="mb-2">
                <label for="new-menu-url">Menu url/link</label>
                    <input type="text" id="new-menu-url" class="form-control" placeholder="URL or slug">
                </div>
        <div class="mb-2">
       <label for="new-menu-icon">Menu Icon <i>(Font awesome icon e.g fas fa-book)</i></label>
                    <input type="text" id="new-menu-icon" class="form-control" placeholder="Font awesome icon e.g fas fa-book">
                </div>
                <div class="mb-2">
     <label for="new-menu-type">Type</label>
<select id="new-menu-type" class="form-select">
                        <option value="custom">Custom</option>
                    </select>
                </div>
                             
                <div class="mb-2">
                    <button class="btn btn-primary w-100" onclick="addMenuItem()">Add</button>
                </div>
               </details>
              </div>
                
<div id="menu-list" class="list-group dragged-items-container mt-3"></div>

    <button class="btn btn-success mt-3" onclick="createMenu()">Create Menu</button>
    
  </div>

</div>

                    
     
<script>

function loadMenuByKey() {

    const key = document.getElementById('menu-list-2-type').value;
    const container = document.getElementById('menu-list-2');

const payload={
	menu: key
	}

    // 🔥 clear current UI before loading
    container.innerHTML = '';

    fetchData( 'get-menu', payload, function(data, error, e){
       //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
          // 🔥 rebuild UI tree
            loadMenu(data.data, container);
            // re-init drag & drop after render
            initSortable('menu-list-2');
}	
    });
}


document.getElementById('menu-list-2-type').addEventListener('change', function () {
    loadMenuByKey();
});

// TEMP IDs for new items (negative to avoid DB collision)
let tempId = -1;

function createItemElement(item) {
 const title=item.title;
const itemType=item.type;
const menuId=item.id ?? tempId--;

   const div = document.createElement('div');
   
div.className = 'menu-item menu-item-' + menuId;

    // IMPORTANT: store ID + full data
  
    div.dataset.id = menuId
    div.dataset.title = title;
    div.dataset.icon = item.icon||'';
    div.dataset.url = item.url||item.page_slug||item.category_slug;
    div.dataset.type = itemType;

    div.innerHTML = `
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <strong>${title}</strong>
                <small class="text-muted">(${item.type})</small>
            </div>
            <div class="menu-actions">
                <button class="btn btn-sm btn-secondary menu-edit-btn ${itemType!=='custom'?'d-none':''}" onclick="editItemForm(this)">Edit</button>
                <button class="btn btn-sm btn-danger menu-delete-btn" onclick="deleteMenuItem(this, ${menuId})">Delete</button>
               <button class="btn btn-sm btn-danger menu-remove-btn" onclick="deleteMenuItem(this)">Remove</button>
            </div>
        </div>
        <div class="menu-children"></div>
    `;

    return div;
}

function addMenuItem() {
    const title = document.getElementById('new-menu-title').value;
    const url = document.getElementById('new-menu-url').value;
    const icon = document.getElementById('new-menu-icon').value;
    const type = document.getElementById('new-menu-type').value;

    if (!title) return alert('Title required');

    const item = {
        id: 0, // 🔥 NEW ITEM FLAG
        title,
        url,
        icon,
        type
    };

    const el = createItemElement(item);
    document.getElementById('menu-list').appendChild(el);

    initSortable('menu-list', {
    	draggable: false,
        childrenClass: false
        });

    document.getElementById('new-menu-title').value = '';
    document.getElementById('new-menu-url').value = '';
    document.getElementById('new-menu-icon').value = '';

}

function editItemForm(btn) {
    const item = btn.closest('.menu-item');

    const id=item.dataset.id;
 
  fetchData('get-menu', { id: id}, function(data, error,e){
  	//alert( JSON.stringify(data))
  	if( error){
  	return showToast(error); 
  }

 const menu=data.data[0];
 
    $('#edit-menu-id').val(id);
  $('#edit-menu-title').val(menu.title);
    $('#edit-menu-url').val(menu.slug);
    $('#edit-menu-icon').val(menu.icon || '');
   
    togglePage('sectionEditCustomMenu');
  
  });
}


function updateMenuItem() {
    const form = document.getElementById('editMenuForm');
    if (!form) return;

    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    // Normalize inputs
    const title = (payload.title || '').trim();
    const url   = (payload.url || '').trim();

    // Validation
    if (!title) {
        return showToast('Enter menu title');
    }

    if (!url) {
        return showToast('Enter menu URL');
    }

    // Optional: basic URL pattern (adjust for your routing system)
    if (!/^([a-z0-9\-\/#:?=&._]+)$/i.test(url)) {
        return showToast('Invalid URL format');
    }

    // Disable form to prevent double submit
    const submitBtn = form.querySelector('[type="submit"]');
    if (submitBtn) submitBtn.disabled = true;

    postData('update-custom-menu', { ...payload, title, url }, function (data, error, e) {
 //alert( JSON.stringify(e))
        if (submitBtn) submitBtn.disabled = false;

        if (error) {
            return showToast(error);
        }

        showToast(data.message || 'Menu updated', 'success');
    });
}

function deleteMenuItem(btn, menuId) {
	const el=btn.closest('.menu-item');
	
	if( !confirm(`${menuId?'Delete':'Remove'} ${el.dataset.title}?`)) return;
	
	if(!menuId){
      return el.remove();
    }
        
    const payload={
    	'id': menuId
    }
  fetchData('delete-menu', payload, function(data, error, e){
  if( error){
  	return showToast(error);
  }
  
  el.remove();
  $('.menu-item-' + menuId).remove();
  showToast(data.message, 'success');
});     

}

function initSortable(elem = 'menu-list', userOptions = {}) {

    const defaults = {
        group: {
            name: 'menuList',
            pull: true,
            put: true
        },
        animation: 150,
        fallbackOnBody: true,
        swapThreshold: 0.65,
        handle: null,              // e.g '.drag-handle'
        draggable: '.menu-item',   // your item selector
       childrenClass: '.menu-children',
       autoInitChildren: true,
        destroyExisting: true
    };

    const opts = $.extend(true, {}, defaults, userOptions);

    const $root = $('#' + elem);

    if (!$root.length) return;

    // destroy existing instance (important for SPA re-renders)
    if (opts.destroyExisting && $root[0]._sortable) {
        $root[0]._sortable.destroy();
    }

    // init root
    $root[0]._sortable = new Sortable($root[0], opts);

    // init children (delegated / dynamic safe)
    if (opts.autoInitChildren) {
        $root.find(opts.childrenClass).each(function () {

            if (opts.destroyExisting && this._sortable) {
                this._sortable.destroy();
            }

            this._sortable = new Sortable(this, {
                group: opts.group,
                animation: opts.animation,
                handle: opts.handle,
                draggable: opts.draggable
            });
        });
    }
}


function serialize(container) {
    let arr = [];

    container.querySelectorAll(':scope > .menu-item').forEach(item => {
      
        let obj = {
            id: parseInt(item.dataset.id) || 0,
            title: item.dataset.title,
            url: item.dataset.url,
            icon: item.dataset.icon,
            type: item.dataset.type,
            children: serialize(item.querySelector('.menu-children'))
        };        
         arr.push(obj);
    });

    return arr;
}

function createMenu() {

const menuList=document.getElementById('menu-list');

    const structure = serialize(menuList);
      
    const payload={
    	tree: structure
        }

    postData( 'create-menu', payload, function(data, error, e){
    //  alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
    $(menuList).empty();
    structure.forEach(item=>{
    	const el = createItemElement(item);
    document.getElementById(`menu-${item.type}-container`).appendChild(el);
    });
    
     showToast(data.message,'success');
}	
    });
}


function saveMenu(elem, edit='') {

const menuList=document.getElementById(elem);

    const structure = serialize(menuList);
    const menuType=document.getElementById(`${elem}-type`).value;
   
    const payload={
    	tree: structure,
        menu: menuType,
        edit: edit
        }

    postData( 'save-menu', payload, function(data, error, e){
    //  alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
   if(!edit) $(menuList).empty();
     showToast(data.message,'success');
}	
    });
}


function loadMenu(data, parent = document.getElementById('menu-list')) {
    data.forEach(item => {
        const el = createItemElement(item, false, 'Remove');
        parent.appendChild(el);

        if (item.children && item.children.length) {
            loadMenu(item.children, el.querySelector('.menu-children'));
        }
    });
}

initSortable();
</script>
</div>
</section>

<!--EDIT CUSTOM MENU-->
<section class="hidden-section"  id="sectionEditCustomMenu">
<div class="page-blur"></div>
<div class="section-data container pt-2 pb-5">

<div class="d-flex justify-content-between align-items-center gap-1 mb-2">

<div class="flex-shrink-0">
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>
</div>
<div class="w-100 text-end">
Edit Menu
</div>

</div>

<form id="editMenuForm">

<input type="text" name="id" id="edit-menu-id" class="d-none" value="">

<div class="mb-2">
<label for="edit-menu-title">Menu Title</label>
<input type="text" name="title" id="edit-menu-title" class="form-control" placeholder="Menu Title">
         </div>
         <div class="mb-2">
        <label for="edit-menu-url">Url</label>
                    <input type="url" name="url" id="edit-menu-url" class="form-control" placeholder="URL">
                </div>
         <div class="mb-2">
        <label for="edit-menu-icon">Menu Icon <i>(Font awesome Icon e.g fas fa-book)</i></label>
                    <input type="text" name="icon" id="edit-menu-icon" class="form-control" placeholder="Font awesome Icon e.g fas fa-book">
                </div>                           
                <div class="mt-2 mb-2">
                    <button type="button" class="btn btn-primary" onclick="updateMenuItem(true)">Update</button>
                </div>
               </form>
               </div>
         </section>
         
<!--LIST USERS-->
<section class="hidden-section"  id="sectionUsersList">
<div class="page-blur"></div>
<div class="section-data container py-5">

    <div class="row">
        <div class="col-12">

            <div class="card shadow-sm">
                <div class="card-body">

                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="mb-0">Staffs</h4>
                        <button class="btn btn-primary btn-sm" onclick="togglePage('sectionCreateUser');">
                            + New Staff
                        </button>
                    </div>

         <div class="table-responsive">
                        <table class="table table-bordered table-min-width table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Role</th>
                                    <th>Branch</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th width="100">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="usersListTable">
                                <tr>
                                    <td colspan="8" class="text-center text-muted">
                                        Loading Users...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div id="alertBox" class="alert d-none mt-3"></div>

                </div>
            </div>

        </div>
    </div>
 </div>
</section>

<!--CREATE USER-->
<section class="hidden-section" id="sectionCreateUser"> 
<div class="page-blur"></div>
<div class="section-data container py-5">

    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">

            <div class="card shadow-sm">
                <div class="card-body p-4">

                    <h4 class="mb-3 text-center">Create User</h4>

                    <form id="createUserForm" novalidate>

                        <!-- Role -->
                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select" id="role" required>
                                <option value="">Select role</option>
                                <option value="administrator">Admin</option>
                                <option value="manager">Manager</option>
                                <option value="staff">Staff</option>
                            </select>
                            <div class="invalid-feedback">Please select a role.</div>
                        </div>

<!-- Branch -->
                        <div class="mb-3">
                            <label class="form-label">Branch</label>
                            <select class="form-control branches-select" id="user-branch" required minlength="3"></select>
                            
          <div class="invalid-feedback">
                  Select branch.
                            </div>
                        </div>


                        <!-- Full Name -->
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="full_name" required minlength="3">
                            <div class="invalid-feedback">
                                Full name must be at least 3 characters.
                            </div>
                        </div>

<!-- User Name -->
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" required minlength="4">
                            <div class="invalid-feedback">
                                Username must be at least 4 characters.
                            </div>
                        </div>

<!-- Phone -->
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="number" class="form-control" id="phone">
                            <div class="invalid-feedback">
                                Enter a valid phone number.
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" id="email">
                            <div class="invalid-feedback">
                                Enter a valid email address.
                            </div>
                        </div>

                        <!-- Password -->
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" required minlength="5">
                            <div class="form-text">
                                Minimum 5 characters, include alphabets & number.
                            </div>
                            <div class="invalid-feedback">
                                Password does not meet requirements.
                            </div>
                        </div>

                        <!-- Submit -->
                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary">
                                Create User
                            </button>
                        </div>

                        <!-- Alert -->
                        <div id="alertBox" class="alert mt-3 d-none"></div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

</section>

<!--EDIT USER-->
<section class="hidden-section" id="sectionEditUser"> 

<div class="page-blur"></div>
<div class="section-data container py-5">

    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">

            <div class="card shadow-sm">
                <div class="card-body p-4">

                    <h4 class="mb-3 text-center">Update profile</h4>

                    <form id="editUserForm" autocomplete="off" novalidate>
                 <input type="hidden" value="" id="edit-user-id">
       <!-- Role -->
       
    
       <div class="<?php if( !$api->admin() ){ echo 'd-none';}?>">
      
                        <div class="mb-3">
                            <label class="form-label">Role</label>
                            <select class="form-select users-select" id="edit-user-role" required>
                                <option value="">Select role</option>
                                <option value="administrator">Admin</option>
                                <option value="manager">Manager</option>
                                <option value="staff">Staff</option>
                            </select>
                            <div class="invalid-feedback">Please select a role.</div>
                        </div>

<!-- Branch -->
                        <div class="mb-3">
                            <label class="form-label">Branch</label>
                            <select class="form-control branches-select" id="edit-user-branch" required minlength="3"></select>
                            
          <div class="invalid-feedback">
                  Select branch.
                            </div>
                        </div>
</div>

                        <!-- Full Name -->
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="edit-user-full_name" required minlength="3">
                            <div class="invalid-feedback">
                                Full name must be at least 3 characters.
                            </div>
                        </div>

<!-- User Name -->
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" id="edit-user-username" required minlength="4">
                            <div class="invalid-feedback">
                                Username must be at least 4 characters.
                            </div>
                        </div>

<!-- Phone -->
                        <div class="mb-3">
                            <label class="form-label">Phone</label>
                            <input type="number" class="form-control" id="edit-user-phone">
                            <div class="invalid-feedback">
                                Enter a valid phone.
                            </div>
                        </div>


                        <!-- Email -->
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit-user-email">
                            <div class="invalid-feedback">
                                Enter a valid email address.
                            </div>
                        </div>     

<details class="mb-3"><summary>Change Password</summary>      
          <!-- Old Password-->
      <div id="show-edit-old-password" class="mb-3 d-none">
                            <label class="form-label">Current Password</label>
                            <input type="text" class="form-control" id="edit-user-current-password" value="" autocomplete="off">
                            <div class="invalid-feedback">
   Enter current password
                            </div>
                        </div>

         <!-- New Password-->
      <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="text" class="form-control" id="edit-user-new-password" value="" autocomplete="off">
                            <div class="invalid-feedback">
   Enter New password
                            </div>
                        </div>
</details>

                        <!-- Submit -->
                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary">
                            <i class="fas fa-pen"></i>   Update
                            </button>
                        </div>
                        
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

</section>

<!--User profile-->

<section id="sectionUserProfile" class="hidden-section">
 <div class="page-blur"></div>
<div class="container py-5 section-data">

<div class="card shadow-sm">
<div class="card-header bg-secondary text-white">
<h5 class="mb-0">Profile</h5>
</div>

<div class="card-body">

<div class="row">

<div class="col-md-3 text-center">
<i class="fa fa-user-circle fa-6x text-secondary"></i>
<h5 class="mt-2" id="profile_name"></h5>
<button class="btn btn-sm btn-success mb-3" onclick="editUserForm(this, 1);"><i class="fas fa-pen"></i> Edit</button>
</div>

<div class="col-md-9">

<table class="table table-bordered">

<tr>
<th width="30%">Full Name</th>
<td id="profile_fullname"></td>
</tr>

<tr>
<th>Email</th>
<td id="profile_email"></td>
</tr>

<tr>
<th>Phone</th>
<td id="profile_phone"></td>
</tr>

<tr>
<th>Role</th>
<td id="profile_role"></td>
</tr>

<tr class="d-none">
<th>Account Created</th>
<td id="profile_created"></td>
</tr>
</table>

</div>

</div>

</div>
</div>

</div>

</section>

<!--SOFTWARE UPDATE-->
<section class="hidden-section"  id="sectionSoftwareUpdate">
<div class="page-blur"></div>
<div class="section-data container pt-0 pb-5">

<div class="py-2 section-sticky-header">

<div class="d-flex justify-content-between align-items-center">
<button class="btn btn-outline-secondary m-back-btn" onclick="goBack(this);"><i class="fas fa-arrow-left"></i> <span>Back</span></button>

</div>
</div>

<div class="card border-warning shadow-sm">
    <div class="card-body">
        
        <div class="d-flex align-items-center mb-3">
            <div class="me-3">
                <i class="fas fa-cloud-download-alt fa-3x text-warning"></i>
            </div>

            <div>
                <h4 class="mb-1">Software Update Information</h4>
                <p class="text-muted mb-0 software-version-title"></p>
            </div>
        </div>

        <div class="alert alert-info">
            <strong>Current Version:</strong> <?php echo APP_VERSION;?><br>
            <strong>Latest Version:</strong> <span class="new-software-version"></span>
        </div>

        <h6>What's New</h6>

        <ul class="mb-4" id="new-version-features"></ul>

        <div class="d-flex gap-2">
            <button class="btn btn-warning d-none" id="updateSoftwareBtn">
                <i class="fas fa-download me-1"></i>
                Update Now
            </button>

<div class="progress mt-3" style="height: 20px;">
    <div id="updateProgress" class="progress-bar" style="width:0%">
        0%
    </div>
</div>

<div id="updateStatus" class="mt-2"></div>

            <button class="btn btn-outline-secondary d-none">
                View Changelog
            </button>
        </div>

        <div class="mt-3">
            <small class="text-muted">
                Backup your files before updating.
            </small>
        </div>

    </div>
</div>
  
</div>

</section>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/global.js?i=<?php echo time();?>"></script>
<script src="assets/js/app.js?i=<?php echo time();?>"></script>
</body>
</html>
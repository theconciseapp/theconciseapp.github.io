<?php 
require_once '../ProjectClasses/bootstrap.php';
require "../ProjectClasses/main.php";
require "../ProjectClasses/main-frontend.php";

$api=new FrontendApi();


if( $_SERVER['REQUEST_METHOD']=='POST'){
	header('Content-Type: application/json');
	
	$api->json( $api->forgotPassword() );

exit;	
	}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Os Paystack - Forgot Password</title>

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7.2.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script>
const OsBaseUrl = '<?php echo $api->site_url();?>';
</script>
</head>
<body>

<style>
body {
    background: #f4f6f9;
}
</style>

<section class="py-5 bg-light min-vh-100 d-flex align-items-center">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-lg-5">

                <div class="card border-0 shadow-sm rounded-4">

                    <div class="card-body p-4 p-lg-5">

                        <div class="text-center mb-4">

                            <h2 class="fw-bold mb-2">
                                Forgot Password
                            </h2>

                            <p class="text-muted mb-0">
                                Enter your developer account email address to receive a password reset link.
                            </p>

                        </div>

                        <form id="forgot-password-form" novalidate>

                            <!-- Email -->
                            <div class="mb-4">

                                <label class="form-label fw-semibold">
                                    Email Address
                                </label>

                                <input
                                    type="email"
                                    class="form-control form-control-lg"
                                    id="forgot-email"
                                    name="email"
                                    placeholder="john@example.com"
                                    required
                                >

                                <div class="invalid-feedback">
                                    Enter a valid email address.
                                </div>

                            </div>

                            <!-- Submit -->
                            <button
                                type="submit"
                                class="btn btn-primary btn-lg w-100 rounded-3"
                                id="forgot-btn"
                            >
                                Send Reset Link
                            </button>

                        </form>

                        <div class="text-center mt-4">

                            <a href="login.php"
                               class="text-decoration-none">
                                Back to Login
                            </a>

                        </div>

                    </div>

                </div>

            </div>
        </div>

    </div>
</section>

<script src="<?php echo $api->assets('js','global.js');?>"></script>

<script>
$(function () {

    $('#forgot-password-form').on('submit', function (e) {

        e.preventDefault();

        let form = $(this);
        let valid = true;

        form.find('.is-invalid').removeClass('is-invalid');

        // Email
        const email = $('#forgot-email').val().trim();

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {

            $('#forgot-email').addClass('is-invalid');

            valid = false;
        }

        if (!valid) {
            return;
        }

        // Loading
        $('#forgot-btn')
            .prop('disabled', true)
            .html(`
                <span class="spinner-border spinner-border-sm me-2"></span>
                Sending...
            `);

const formData= new FormData(form[0]);
    const payload = Object.fromEntries(formData.entries());

postData( `${OsBaseUrl}/forgot-password.php`, payload, function(data, error, e){
	$('#forgot-btn').prop('disabled', false).text('Send Reset Link');
                    
	if( error) {
		showToast(error)
		return;
		}
  showToast(data.message, 'success');  
  setTimeout(()=>{
    location.href=data.redirect;
    }, 3000);
       });
   });
});

</script>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Os Ecomm. Admin</title>
<script>
const serverUrl="<?php echo $api->site_url();?>";
const apiServerUrl=serverUrl + "/api";
</script>

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7.2.0/css/all.min.css">
<link href="assets/css/style.css?i=<?php echo time();?>" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="assets/js/popstate.js?i=1"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<style>
.menu-item {
    background:#fff;
    border:1px solid #ddd;
    padding:10px;
    margin-bottom:8px;
    border-radius:6px;
    cursor:move;
}
.menu-children {
    margin-left:25px;
}
.menu-actions button {
    margin-left:5px;
}
</style>
</head>
<body>
<div id="loader-container">
  <div id=""><i class="fas fa-spin fa-spinner fa-3x"></i></div>
</div>
<div id="ajax-loader-container">
  <div id=""><i class="fas fa-spin fa-spinner fa-3x"></i></div>
</div>

<div id="page-blur"></div>
<!--DASHBOARD-->

 <header id="main-header">
<div id="header-menu-btn" onclick="toggleMenu(this);"><i class="fas fa-bars text-dark"></i>
</div>

<div>
<span class="d-inline-block" id="logo-container"></span>
</div>

  <div>
Admin
</div>
      <div class="text-end dropdown">
 <span class="dropdown-toggle" data-bs-toggle="dropdown"><i class="fas fa-user"></i> <span class="d-none d-md-inline">Account</span></span>

  <ul class="dropdown-menu dropdown-menu-end pb-2" id="user-menu-items">
  <li onclick="togglePage('sectionUserProfile','loadUserProfile');"><i class="fas fa-user-gear mx-2"></i> Profile</li>
  <li onclick="logOut();"><i class="fas fa-sign-out-alt mx-2"></i> Logout</li>
</ul>
</div>
 </header>

<div class="mt-2 d-flex gap-2">

<div id="header-menu-container" class="flex-shrink-0 mx-0">

<div id="header-menu-blur" onclick="toggleMenu(this,1);"></div>

 <div id="header-ul">
 
  <span class="menu-close-btn d-flex justify-content-end pe-0">
    <i class="px-4 py-3 fas fa-times text-dark d-md-none" onclick="toggleMenu(this,1);"></i>
    </span>
   
   <div class="container-fluid">
   <div class="accordion">
   
   <!--Products-->
   <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button no-arrow" onclick="togglePage('sectionProductsList','loadProducts');">
           <i class="fas fa-tags me-2"></i>      Products
            </button>
        </h2>
    </div>
   
   
   <!-- Orders -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingOrders">
                <button class="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapseOrders">
                    <i class="fas fa-shopping-cart me-2"></i> Orders
                </button>
            </h2>

          <div id="collapseOrders" class="accordion-collapse collapse"  data-bs-parent="#sidebarMenu">

                <div class="accordion-body ps-4 pe-0 p-0">
    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders();">All Orders</button>
                                 <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders('pending');">Pending Orders</button>
    </li>
    <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders('processing');">Processing Orders</button>
    </li>
   <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders('shipped');">Shipped Orders</button>
    </li>
       <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders('delivered');">Delivered Orders</button>
    </li>
    <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders('cancelled');">Cancelled Orders</button>
    </li>
   <li class="list-group-item">
                            <button type="button" class="accordion-button no-arrow" onclick="menuLoadOrders('expired');">Expired Orders</button>
    </li>
                    </ul>
                </div>
            </div>
        </div>


   <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button no-arrow" onclick="togglePage('sectionCategoriesList');">
           <i class="fas fa-tags me-2"></i>      Categories
            </button>
        </h2>
    </div>

   <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button no-arrow" onclick="togglePage('sectionPagesList');">
         <i class="fas fa-boxes me-2"></i>        Pages
            </button>
        </h2>
    </div>
<div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button no-arrow" onclick="togglePage('sectionMenuPage','loadMenuByKey');">
         <i class="fas fa-chart-bar me-2"></i>        Menu
            </button>
        </h2>
    </div>

   <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button no-arrow" onclick="togglePage('sectionUpload');">
           <i class="fas fa-photo-film me-2"></i>      Media Library
            </button>
        </h2>
    </div>

  
        <!-- Payments -->
        <div class="accordion-item">
            <h2 class="accordion-header" id="headingPayments">
                <button class="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#collapsePayments">
                    <i class="fas fa-credit-card me-2"></i> Payments
                </button>
            </h2>

            <div id="collapsePayments"
                 class="accordion-collapse collapse"
                 data-bs-parent="#sidebarMenu">

                <div class="accordion-body p-0">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <a href="#" class="text-decoration-none">Transactions</a>
                        </li>

                        <li class="list-group-item">
                            <a href="#" class="text-decoration-none">Refunds</a>
                        </li>

                        <li class="list-group-item">
                            <a href="#" class="text-decoration-none">Settlement</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>


   <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button  no-arrow" onclick="togglePage('sectionSettings');">
             <i class="fas fa-gear me-2"></i> Settings
            </button>
        </h2>
    </div>

<div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button  no-arrow" onclick="togglePage('sectionSoftwareUpdate');">
             <i class="fas fa-sync-alt me-2"></i> Update <span class="ms-1 text-danger" id="software-update-indicator"></span>
            </button>
        </h2>
    </div>




    </div>
</div>

  </div>
  </div>
<div class="leaderboard-items flex-fill">

<div id="hero-section"></div>
 </div>
</div>

</section>
const enableStockCentral=true;

let __users=[];
let __userId;
let __userRole;
let __categories=[];
let __products=[];
let __pages=[];
let __menus=[];


$(function(){

fetchData('dashboard', {},function(data, error){
 //  alert( JSON.stringify( data))
 if( error){
   showToast( error);
return;
}

populateSettings( data.settings);
__userId=data.userId;
__users=data.users||[];
__userRole=data.userRole;
__categories=data.categories||[];
//__products=data.products||[];

__pages=data.pages||[];
__menus=data.menus||[]; //Front end

//companyInfo();
populateCategories();
//renderProducts(__products);
renderOrders(data.orders||[]);
renderPages(__pages.data);
renderMenus(__menus.data);
renderMenuPages(__pages.data);
renderMenuCatz(__categories);


$('#loader-container').fadeOut();		
	});	
});

function companyInfo(){
	 let b={}
	b.companyName='Ayo-Ola Trading Stores';
	b.logo='logo.png';
	
	$('.company-name').text( escapeHtml( b.companyName) );
	$('.company-logo').text( escapeHtml(b.logo) );	
}
	
function central(){
	return __branchId==1;
}

function admin(){
	let role=localStorage.getItem("userRole")||""
	return (role=='administrator');
	}
	
function manager(){
	let role=localStorage.getItem("userRole")||""
	return (role=='manager');
	}
	
function canManage(){
	return admin()||manager();
}

function toggleMenu(t, close){
	let el=$('#header-menu-container');
    let menuBtn=$('#header-menu-btn');
    
 if(!close) _pushState({
    element: '#header-ul',
   close: 'toggleMenu',
   args: [false, true]
   });
   
if(el.hasClass('menuOpen') ){
	//Close
 	el.removeClass('menuOpen');
   $('body').removeClass('overflow-hidden');
   menuBtn.find("i").css('transform', 'rotate(0deg)')	
  
}else{
	//Open
	el.addClass('menuOpen');
	$('body').addClass('overflow-hidden');
	menuBtn.find("i").css('transform', 'rotate(50deg)')	
}

}
	
function togglePage(pageId, callback, onClose=''){
  let page=$('#' + pageId);

page.addClass('showSection');

 page.find('.page-blur').show();
  
  _pushState({
    element: '#' + pageId,
   close: 'closePage',
   args: [pageId, onClose]
   });
   if(callback) window[callback]();
	$('body').addClass('overflow-hidden');
}

function closePage(page, onClose){
	if(onClose) window[onClose]();
		$('#' + page).removeClass('showSection');
   $('body').removeClass('overflow-hidden');
}

function goBack(){
	history.go(-1);
}
	
	
function renderMenuPages(pages){
	try{
 pages.forEach(page=>{
		const item = {
        id: page.id,
        title: page.title,
        url: page.slug,
        type: 'page'
    };
		
	const el = createItemElement(item);
    document.getElementById('list-menu-pages').appendChild(el);
    
		initSortable('list-menu-pages', {
    group: {
        name: 'pages',
        pull: 'clone',
        put: false
    },
    sort: false,
    onAdd: function (evt) {
        const $item = $(evt.item);
        // remove original ID or assign new one
        $item.attr('data-id', 'new-' + Date.now());
        // optional: mark as cloned
        $item.addClass('is-clone');
    },
    autoInitChildren: false
});

	});
	
	}catch(e){
		alert(e);
		}
}	

function renderMenuCatz(catz){
	try{
 catz.forEach(c=>{
		const item = {
        id: c.id,
        title: c.name,
        url: c.slug,
        type: 'category'
    };
		
	const el = createItemElement(item);
    document.getElementById('list-menu-categories').appendChild(el);
    
		initSortable('list-menu-categories', {
    group: {
        name: 'categories',
        pull: 'clone',
        put: false
    },
    sort: false,
    onAdd: function (evt) {
        const $item = $(evt.item);
        // remove original ID or assign new one
        $item.attr('data-id', 'new-' + Date.now());
        // optional: mark as cloned
        $item.addClass('is-clone');
    },
    autoInitChildren: false
});

	});
	
	}catch(e){
		alert(e);
		}
}	
	
function renderMenus(menus){
	
	$('#list-menus').append(`<details class="mb-2" open><summary class="mb-2"><strong>Pages</strong></summary><div id="menu-page-container"></div></details>
<details class="mb-2"><summary class="mb-2"><strong>Categories</strong></summary><div id="menu-category-container"></div></details>
<details class="mb-2"><summary class="mb-2"><strong>Custom</strong></summary><div id="menu-custom-container"></div></details>`);
		
	try{
 menus.forEach(menu=>{
		
		const item = {
        id: menu.id,
        title: menu.title,
        url: menu.url||menu.page_slug||menu.category_slug,
        type: menu.type
    };

const elemId=`menu-${menu.type}-container`;

	const el = createItemElement(item);
    document.getElementById(elemId).appendChild(el);
    
		initSortable(elemId, {
    group: {
        name: 'sidebar',
        pull: 'clone',
        put: false,        
    },
    sort: false,
    onAdd: function (evt) {
        const $item = $(evt.item);

        // remove original ID or assign new one
        $item.attr('data-id', 'new-' + Date.now());
        // optional: mark as cloned
        $item.addClass('is-clone');
    },
    autoInitChildren: false
});

	});
	
	}catch(e){ alert(e); }
	
}
	
function resetCatForm(){
       $('#createCategoryForm')[0].reset(); 
        $('#catFormTitle').text('Add Category');
	}
	

function populateCategories(selected='', elem=$('.categories-select') ){

	let tableRows = '';
			
		let cats=`<option value="">-- Select Category --</option>`;
		 
         let map = {};
        __categories.forEach(cat => map[cat.id] = cat.name);
        
       __categories.forEach(cat => {
        	      cats+=`<option value="${cat.id}"${cat.id==selected?' selected':''}>${cat.name}</option>`;
        
            let parentName = map[cat.parent_id] || '<span class="text-muted">None</span>';

            tableRows += `
                <tr>
                    <td>${cat.name}</td>
                    <td>${cat.slug}</td>
                    <td>${parentName}</td>
                    <td style="min-width: 120px!important; text-align: center;">
                        <button class="btn btn-sm btn-warning" onclick='editCategoryForm(${JSON.stringify(cat)})'>
                            <i class="fas fa-edit"></i>
                        </button>
                       <button class="btn btn-sm btn-danger" onclick='deleteCategory(${JSON.stringify(cat)})'>
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

       elem.html( cats);
        $('#categoriesListTable').html(tableRows);	
    $('.total-categories').text( __categories.length);
 
 loadCategoryOptions(selected);
 }

const categoryId=0;

// Auto slug
$('#name').on('input', function () {
    let slug = $(this).val()
        .toLowerCase()
        .trim()
        .replace(/\s+/g, '-')
        .replace(/[^\w\-]+/g, '');

    $('#slug').val(slug);
});

// Load parent dropdown (tree)
function loadCategoryOptions(selectedId = null) {

data=__categories;

        let map = {};
        let roots = [];

        data.forEach(c => {
            c.children = [];
            map[c.id] = c;
        });

        data.forEach(c => {
            if (c.parent_id) {
                map[c.parent_id]?.children.push(c);
            } else {
                roots.push(c);
            }
        });

        let options = '<option value="">None (Top Level)</option>';

        function render(nodes, level = 0) {
            nodes.forEach(c => {
                let indent = '&nbsp;'.repeat(level * 4);

                // prevent selecting itself
                let disabled = (categoryId && c.id == categoryId) ? 'disabled' : '';

                options += `
                    <option value="${c.id}" ${selectedId == c.id ? 'selected' : ''} ${disabled}>
                        ${indent}— ${c.name}
                    </option>
                `;

                if (c.children.length) render(c.children, level + 1);
            });
        }

        render(roots);
        $('#parent_id, #product-categories, #product-filterCategory').html(options);
   // });
}

// Open Edit
function editCategoryForm(cat) {
	resetCatForm();
	
    $('#category_id').val(cat.id);
    $('#name').val(cat.name);
    $('#slug').val(cat.slug);
    $('#description').val(cat.description || '');
    $('#catz-icon').val(cat.icon || '');

    $('#catFormTitle').text('Edit Category');

    loadCategoryOptions(cat.parent_id);
    togglePage('sectionCreateCategory');
}

//CREATE CATEGORY

$('#createCategoryForm').on('submit', function (e) {
    e.preventDefault();

const form=this;

    if (!this.checkValidity()) {
        $(this).addClass('was-validated');
        return;
    }

    const payload = {
        id: $('#category_id').val(),
        name: $('#name').val().trim(),
        slug: $('#slug').val().trim(),
        parent_id: $('#parent_id').val(),
        description: $('#description').val(),
        icon: $('#catz-icon').val()
    };

    if (!payload.name) {
        alert('Category name is required');
        return;
    }

    let url = payload.id
        ? 'edit-category'
        : 'create-category';

let btn=$(form).find('button');
        btn.prop('disabled', true);
        
  postData(url, payload, function(data, error, e){
 //alert( JSON.stringify(e))
        btn.prop('disabled', false);
     if( error) {
            showToast( error);  
   return; 
   }
   
   showToast(data.message, 'success');
   
  if(payload.id) {	
 __categories=__categories.filter((data)=>data.id!=payload.id);  
 }else{
 	form.reset();
 }
   
   __categories.push( data.category);
   populateCategories(payload.parent_id);            
  $('#createCategoryForm').removeClass('was-validated');   
    });       
});

//DELETE CATEGORY

function deleteCategory(cat){ 
	
	const id=cat.id;
	const name=cat.name;

if(!confirm(`Delete category ${name}\n\nThis action is not reversible`)) return;	

fetchData(`delete-category?id=${id}`, {}, function(data, error){
	 	if( error){
	return	showToast(error);
		}
	
if(data.success){	
__categories=__categories.filter((data)=>data.id!=id);
populateCategories();
showToast( data.message, 'success');
}
	});
}


$(document).ready(function () {
    loadCategoriesFilter();
    try{
   // loadProducts();
}catch(e){ alert(e); }

    $('#search').on('keyup', debounce(loadProducts, 500));
});

function resetProductForm(){
		$('#productForm')[0].reset();
        $('#productFormTitle').text('Add Product'); 
        $('#product-images-selected').empty();
	}


// Load products
function loadProducts(t, id='') {
	
	let this_=$(t||this);
    let page=this_.attr('data-page')||1;
 
    let search = $('#product-search').val();
    let category = $('#product-filterCategory').val();

 const payload={
 	   id: id,
        p: page,
        s: search,
        category: category
    }

 fetchData(`products`, payload, function(data, error, e){
     //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
        renderProducts(data);
	 }
  });
}

function renderProducts(data){
	let rows = '';
  
        data.data.forEach((p, i) => {
     
    const image=p.product_images?p.product_images.split('||')[0].split('|')[1]:'';
    
            let price = p.sale_price
                ? `<span class="text-danger fw-bold">₦${p.sale_price}</span>
                   <small class="text-muted text-decoration-line-through">₦${p.price}</small>`
                : `₦${p.price}`;

        /*
    let stock = p.stock_quantity > 0
                ? `<span class="badge bg-success">In Stock (${p.stock_quantity})</span>`
                : `<span class="badge bg-danger">Out</span>`;
*/

let stock= `<span class="badge ${p.status =='active'?'bg-success': 'bg-danger'}">${p.status}</span>`;

            rows += `
                <tr>
                    <td>${i + 1}</td>
                    <td>
                        <img src="${productImage(image || 'https://dummyimage.com/50x50/999/fff&text=' + p.name[0])}"
                             width="50" height="50" class="rounded">
                    </td>
                    <td>${p.name}</td>
                   <!-- <td>${p.categories || '-'}</td>-->
                    <td>${price}</td>
                    <td>${stock}</td>
                    <td style="min-width: 120px;">
                        <button onclick="editProductForm(${p.id})" class="btn btn-sm btn-warning">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteProduct(${p.id}, '${p.name}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            `;
        });

        $('#productsTable').html(rows);
        $('#prevProducts,#nextProducts').addClass('d-none');
   
	if( data.next){
		$('#nextProducts').removeClass('d-none').attr('data-page', data.next);
		}
	if( data.prev){
		$('#prevProducts').removeClass('d-none').attr('data-page', data.prev);
	}
}
	
function editProductForm(id){
		resetProductForm();
	  const payload={
 	   id: id        
    }

   const btn=$('#save-product-btn');
   btn.prop('disabled', true);

 fetchData(`products`, payload, function(data, error, e){
    // alert(JSON.stringify(data))	         
	if( error){
      goBack();	
   setTimeout( ()=>{
	showToast(error);
   }, 500);

	return;
	}
	
	btn.prop('disabled', false);
	
  if( data.success){
	
        let p =data.data[0]
                
	 $('#product-product_id').val(p.id);
	$('#product-featured-rank').val(p.featured_rank||0);
	$('#product-status').val(p.status),
        $('#product-name').val(p.name);
        $('#product-slug').val(p.slug);
        $('#product-price').val(p.price);
        $('#product-sale_price').val(p.sale_price);
        $('#product-cost_price').val(p.cost_price);
        $('#product-stock_quantity').val(p.stock_quantity);
        $('#product-description').val(p.description);
        $('#product-description').val(p.description||'');
        $('#product-full-description').val(p.full_description||'');
        
       
const images = p.product_images
  ? p.product_images.split('||').map(item => {
      const [id, url] = item.split('|');
      return {
        id: Number(id),
        url: url || ''
      };
    })
  : [];
  
         showSelectedImages(images)
     setSelectedCategories(p.category_ids?.split(',') ); 
     togglePage('sectionProductForm');
$('#productFormTitle').text('Edit Product');
        }
});

	}
	
	
function setSelectedCategories(categoryIds) {
   if (!Array.isArray(categoryIds)) return;

    $('#product-categories option').each(function () {
    	const value=$(this).val();
    	
        $(this).prop('selected', categoryIds.includes(value) );
    });

    // Trigger change (important if using plugins later like Select2)
    $('#product-categories').trigger('change');
}
	
	
function deleteProduct(id, name){ 
	
if(!confirm(`Delete  ${name}\n\nThis action is not reversible`)) return;	

fetchData(`delete-product`, {id: id}, function(data, error){
	 	if( error){
	return showToast(error);
  }
	
  if( data.success){	
     showToast( data.message, 'success');
   }
  });
}

	
// Load category filter
function loadCategoriesFilter() {
    $.get('/api/categories', function (data) {

        let options = '<option value="">All Categories</option>';

        data.forEach(c => {
            options += `<option value="${c.id}">${c.name}</option>`;
        });

        $('#filterCategory').html(options);
    });
}


//Load Orders
function loadOrders(t, id='', status_='') {

	let this_=$(t||this);
    let p=this_.attr('data-page')||1;
 
  const s = document.getElementById('orders-search').value;
  const status = status_||document.getElementById('orders-status').value;
  const payment_status = document.getElementById('orders-payment-status').value;
  const from = document.getElementById('orders-from').value;
  const to = document.getElementById('orders-to').value;

   const payload={
    id: id,
    s,
    status,
    payment_status,
    from,
    to,
    p
    }

 fetchData(`get-orders`, payload, function(data, error, e){
   //  alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
        renderOrders(data);
	 }
  });
}

function menuLoadOrders(status) {
	goBack();
	$('#orders-status').val(status);
	 loadOrders(null,null, status);
	}
	
function renderOrders(data) {
	//alert( JSON.stringify(data))
  const tbody = document.getElementById('ordersTable');
  tbody.innerHTML = '';

  if (!data.data.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center">No orders found</td></tr>`;
    return;
  }

  data.data.forEach((o, index) => {
    tbody.innerHTML += `
      <tr>
        <td>${index + 1}</td>
        <td>₦${formatMoney(o.total_amount)}</td>
        <td>${statusBadge(o.payment_status)}</td>
        <td>${statusBadge(o.status)}</td>
        <td>${o.total_items}</td>
        <td>${timeAgo(o.created_at)}</td>
        <td class="text-center">
       <button class="btn btn-sm btn-outline-dark" onclick="viewOrder(this, ${o.id})">
            View
          </button>
       
       <div class="dropdown d-inline-block">
       <button class="btn btn-light border btn-sm" data-bs-toggle="dropdown">
        <i class="fas fa-ellipsis-v"></i>
    </button>
<ul class="dropdown-menu dropdown-menu-end">
      <li><button class="dropdown-item manage-app-btn" onclick="adjustOrder(this, ${o.id})"><i class="fas fa-edit"></i> Update/Adjust Order</button></li>

  <li><hr class="dropdown-divider"></li>
  
<li class="${o.status=='cancelled'?'d-none':''}"><button class="dropdown-item text-danger" onclick="cancelOrder('${o.id}','₦${formatMoney(o.total_amount)}');"><i class="fas fa-times"></i>  Cancel Order</button></li>
   <li class="${o.status!=='cancelled'?'d-none':''}"><button class="dropdown-item text-success" onclick="restoreOrder('${o.id}','₦${formatMoney(o.total_amount)}');"><i class="fas fa-refresh"></i>  Restore Order</button></li>
                        </ul>
                    </div>
        </td>
      </tr>
    `;
  });
  
  $('#prevOrders,#nextOrders').addClass('d-none');
   
	if( data.next){
		$('#nextOrders').removeClass('d-none').attr('data-page', data.next);
		}
	if( data.prev){
		$('#prevOrders').removeClass('d-none').attr('data-page', data.prev);
	}  
}


function viewOrder(t, id) {
  $this_=$(t);

  const payload={
    id: id }

 fetchData(`get-order-details`, payload, function(data, error, e){
  //  alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
        renderOrderDetails(data); 
      togglePage('sectionOrderItemsList');
	 }
  });  
}

function renderOrderDetails(data){
	
	const order = data.order;
    const items = data.items;

 // alert( JSON.stringify( data))

const custName=order.fullname.replace(/('|")/g,'');

  let html = `
    <div class="mb-3">
      <div><strong>Order UID:</strong> ${order.order_uid}</div>
      <div><strong>Status:</strong> ${statusBadge(order.status)}</div>
      <div><strong>Payment Status:</strong> ${statusBadge(order.payment_status)}</div>
      <div><strong>Payment Method:</strong> ${order.payment_method=='pod'?'Pay On Delivery':order.payment_method}</div>
      <div><strong>Total:</strong> ₦${formatMoney(order.total_amount)}</div>
      <div><strong>Order By:</strong> ${custName}</div>
      <div><strong>Phone:</strong> ${order.phone} <button class="btn btn-outline-success" onclick="sendToWhatsApp('Hello ${custName}', '${order.phone}');"><i class="fab fa-whatsapp fa-lg text-success"></i></button> <a class="btn btn-outline-dark" href="tel:${order.phone}">
<i class="fas fa-phone-volume"></i> </a></div>
      <div><strong>Email:</strong> ${order.email}</div>
      <div><strong>State:</strong> ${order.state||''}</div>
      <div><strong>Address:</strong> ${order.address}</div>
      
      <div><strong>Date:</strong> ${timeAgo(order.created_at, true)}</div>
    </div>

    <div class="table-responsive">
      <table class="table table-sm table-bordered" style="min-width: 500px;">
        <thead>
          <tr>
            <th>Product</th>
            <th width="80">Qty</th>
            <th width="120">Price</th>
            <th width="120">Total</th>
          </tr>
        </thead>
        <tbody>
  `;

  items.forEach(item => {
  	const imgSrc = item.images?.[0]?.url 
    || `https://dummyimage.com/50x50/999/fff&text=${encodeURIComponent(item.name?.slice(0,2).toUpperCase() || '?')}`;
  
    html += `
      <tr>
        <td>
          <div class="d-flex align-items-center gap-2">
            <img src="${productImage(imgSrc)}" class="img-fluid rounded border" width="40" height="40">
            ${item.name}
          </div>
        </td>
        <td>${item.quantity}</td>
        <td>₦${formatMoney(item.price)}</td>
        <td>₦${formatMoney(item.total)}</td>
      </tr>
    `;
  });

  html += `
        </tbody>
      </table>
    </div>
    <div class="my-2">
<button class="btn btn-light btn-outline-dark" onclick="adjustOrder(this, '${order.id}')">Update/Adjust order</button>
</div>
  `;

  $('#orderDetails').html(html);
}

function productImage(url) {
    if (!url) return '';

    const currentOrigin = window.location.origin;

    try {
        const imageOrigin = new URL(url, currentOrigin).origin;

if (/:8000$/.test(imageOrigin) && !/:8000$/.test(currentOrigin) ){
		const img=url.replace( new RegExp( imageOrigin + '(/ecommerce)?'), serverUrl);
	return img;
	}
	
    } catch (e) {
        // Invalid URL, return as-is
    }
    return url;
}
 
function statusBadge(status, onlyColor) {
  const map = {
    pending: 'warning',
    paid: 'success',
    failed: 'danger',
    delivered: 'success',
    processing: 'info',
    shipped: 'primary',
    cancelled: 'danger',
    expired: 'dark',
    refunded: 'primary',
    pertially_refunded: 'info'
  };
if( onlyColor) return status;
  return `<span class="badge bg-${map[status] || 'secondary'}" style="text-transform: capitalize;">${status}</span>`;
}



function adjustOrder(t, id) {
  $this_=$(t);

  const payload={
    id: id 
}

 fetchData(`get-order-details`, payload, function(data, error, e){
   //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}

try{
		
  if( data.success){  	
        renderOrderForAdjustment(data); 
        calculateTotals();
     togglePage('sectionAdjustOrder');
	 }
}catch(e){
alert(e)
}	
	
	
  }); 
}



function renderOrderForAdjustment(data){

if(!data || !data.success){
return;
}

let order=data.order || {};
let items=data.items || [];


/*
|--------------------------------------------------------------------------
| ORDER DETAILS
|--------------------------------------------------------------------------
*/

const statuses = {
    pending: 'Pending',
    processing: 'Processing',
    shipped: 'Shipped',
    delivered: 'Delivered',
    cancelled: 'Cancelled',
    expired: 'Expired'
};

let statusBtns = '';

Object.entries(statuses).forEach(([key, value]) => {
    statusBtns+=`<button class="upd-order-status-buttons btn btn-${key==order.status?'success btn-md':'light btn-sm'} mt-1" data-old-status="${order.status}" onclick="changeOrderStatus(this,'${order.id}','${key}');">${statusBadge(key)}</button> `;
    //order.payment_status
});

let orderHtml=`
<input
type="text"
id="adjusted-order-id"
class="d-none"
value="${order.id || ''}">
<div class="mb-3">
<label class="form-label fw-bold">
Order UID
</label>

<input
type="text"
class="form-control" id="adjusted-order-uid" value="${order.order_uid || ''}" readonly disabled>
</div>

<details class="mb-3"><summary>Customer Info</summary>
<div class="mb-3">

<label class="form-label fw-bold">
Customer Name
</label>

<input
type="text"
class="form-control" id="adjusted-order-fullname"
value="${order.fullname || ''}"></div>

<div class="mb-3">
<label class="form-label fw-bold">
Email
</label>

<input
type="email"
class="form-control" id="adjusted-order-email"
value="${order.email || ''}"></div>


<div class="mb-3">
<label class="form-label fw-bold">
Phone
</label>

<input type="text" class="form-control" id="adjusted-order-phone" value="${order.phone || ''}">

</div>


<div class="mb-3">

<label class="form-label fw-bold">
State
</label>

<select class="form-select" id="adjusted-order-state"></select>

<div class="mb-3">

<label class="form-label fw-bold">
Address
</label>

<textarea
class="form-control" id="adjusted-order-address"
rows="3">${order.address || ''}</textarea>
</div>
<hr>
</details>
<div class="row">

<div class="col-md-6 mb-3">

<b class="form-label fw-bold">Update order status</b>

<div>
  ${statusBtns}
</div>

</div>


<div class="col-md-6 mb-3">

<label class="form-label fw-bold">
Payment Status
</label>

<select class="form-select" id="adjusted-order-payment-status">

<option value="unpaid">Unpaid</option>
<option value="pending">pending</option>
<option value="paid">Paid</option>
<option value="failed">Failed</option>
<option value="refunded">Refunded</option>
<option value="partially_refunded">Partially Refunded</option>

</select>

</div>

</div>


<div class="mb-3">

<label class="form-label fw-bold">
Payment Method
</label>

<select class="form-select" id="adjusted-order-payment-method">
<option value="online">Online</option>
<option value="transfer">Transfer</option>
<option value="pod">Pay On Delivery</option>
<option value="wallet" class="d-none">E-Wallet</option>
</select>

</div>


<div>

<label class="form-label fw-bold">
Created At
</label>

<input
type="text"
class="form-control"
value="${timeAgo(order.created_at || '', true)}"
readonly disabled>

</div>`;

$('#orderAdjustDetails').html(orderHtml);

$('#adjusted-order-payment-status').val(order.payment_status || '');
$('#adjusted-order-payment-method').val(order.payment_method || '');

nigeriaStates().forEach(state=>{
	$('#adjusted-order-state').append(`<option>${state}</option>`);
});
$('#adjusted-order-state').val(order.state || '');

/*
|--------------------------------------------------------------------------
| ORDER ITEMS
|--------------------------------------------------------------------------
*/

let rows='';

items.forEach(function(item){

let image='';

if(item.images && item.images.length > 0){
image=item.images[0].url;
}

rows+=`

<tr class="adjusted-order-item" data-product-id="${item.product_id || ''}">

<td>

<img
src="${productImage(image)}"
class="img-fluid rounded border">
</td>

<td>

<input
type="text"
class="form-control product-name"
value="${item.name || ''}"
readonly disabled>

</td>

<td>

<input
type="number"
class="form-control price"
value="${item.price || 0}"
>

</td>

<td>

<input
type="number"
class="form-control qty"
value="${item.quantity || 1}"
min="1"
>

</td>

<td>

₦<span class="row-total">
0
</span>

</td>

<td>

<button class="btn btn-danger btn-sm remove-item" onclick="removeOrderItem(this, '${order.id}','${item.id}','${item.product_id || ''}');">
×
</button>

</td>

</tr>

`;
});

$('#adjustOrderTable tbody').html(rows);

calculateTotals();
}



function calculateTotals(){

let grandTotal=0;

$('#adjustOrderTable tbody tr').each(function(){

let price=parseFloat(
$(this).find('.price').val()
) || 0;

let qty=parseInt(
$(this).find('.qty').val()
) || 0;

let total=price * qty;

grandTotal+=total;

$(this).find('.row-total').text(
total.toLocaleString()
);

});

$('#grandTotal').text(
grandTotal.toLocaleString()
);

}


/*
|--------------------------------------------------------------------------
| EVENTS
|--------------------------------------------------------------------------
*/

$(document).on(
'keyup change',
'.price,.qty',
function(){

calculateTotals();

}
);



//SAVE ADJUSTED ORDER
function collectOrderData(){

let items=[];
let total=0;

$('.adjusted-order-item').each(function(){

const row=$(this);

const productId=parseInt(row.data('product-id'))||0;

const name=$.trim(
row.find('.product-name').val()
);

const quantity=parseInt(
row.find('.qty').val()
)||0;

const price=parseFloat(
row.find('.price').val()
)||0;

const itemTotal=quantity*price;

total+=itemTotal;

items.push({
product_id:productId,
name:name,
quantity:quantity,
price:price,
total:itemTotal
});

});

return{
order_id:$('#adjusted-order-id').val(),
payment_status:$('#adjusted-order-payment-status').val(),
payment_method:$('#adjusted-order-payment-method').val(),
fullname:$('#adjusted-order-fullname').val(),
email:$('#adjusted-order-email').val(),
phone:$('#adjusted-order-phone').val(),
state:$('#adjusted-order-state').val(),
address:$('#adjusted-order-address').val(),
total_amount:total,
items:items
   };
}


function saveAdjustedOrder(t) {
  const this_=$(t);

 if( $('#adjustOrderTable').find('tbody tr').length<1 ){
 	  return showToast('No item in this order. Change order status to "Cancelled" instead');
 }
  
  const payload=collectOrderData();
  
 postData(`adjust-order`, payload, function(data, error, e){
 	
    //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
         showToast( data.message||'Saved successful', 'success');
	 }
  }); 
}

function removeOrderItem(t, order_id, item_id, product_id){
	const el=$(t).closest('tr');

if( $('#adjustOrderTable').find('tbody tr').length<2 ){
   return showToast('If you remove, there will be no item in the order. Cancel this order instead');
  }
 const item=el.find('.product-name').val();
if(!confirm(`Remove ${item}?`)) return;

 const payload={
   item_id: item_id
}
	
	postData(`remove-order-item`, payload, function(data, error, e){
 	//alert(JSON.stringify(e))	 
	if( error){
	return showToast(error);
	}
		
  if( data.success){  
	el.remove();
	calculateTotals();
         showToast( data.message||'Removed', 'info');
	 }
  }); 
}


function changeOrderStatus(t, orderId, newStatus){
	const this_=$(t);
	
 const oldStatus=this_.attr('data-old-status');	

	if( newStatus.toLowerCase()==oldStatus.toLowerCase() )  return;
	
if(!confirm(`Confirm you want to change order status from ${oldStatus} to ${newStatus}`) ) return;

const btns=$('.upd-order-status-buttons');


const payload={
   orderId: orderId,
   newStatus: newStatus
}

btns.prop('disabled', true);
	
	postData(`change-order-status`, payload, function(data, error, e){
 	  //alert(JSON.stringify(data))
 btns.prop('disabled', false);
	if( error){
	return showToast(error);
	}
	
  if( data.success){  

btns.removeClass('btn-success btn-md').addClass('btn-light btn-sm').attr('data-old-status', newStatus);
     $(t).removeClass('btn-light btn-sm').addClass('btn-success btn-md');
     
         showToast( data.message||'Changed successfully', 'info');
	 }
  }); 
}
	
function cancelOrder( orderId, amount){
	
	if(!confirm(`Cancel order?\nTotal Amount: ${amount}`) ) return;

const payload={
   id: orderId
}
	
	postData(`cancel-order`, payload, function(data, error, e){
 	//  alert(JSON.stringify(e))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
         showToast( data.message||'Cancelled', 'info');
	 }
  });
}
	
function renderPages(filtered=__pages.data) {
	
	try{
  const tbody = $('#pageTableBody');
  
  if (!filtered) {
    tbody.html( `<tr><td colspan="6" class="text-center">No pages found</td></tr>`);
    return;
  }

  let html = '';

    filtered.forEach(p => {
    	
        html += `
        <tr id="page-tr-${p.id}">
            <td><a href="${serverUrl}/page/${p.slug}" class="text-decoration-none" target="_blank">${p.title}</a></td>
            <td>${p.slug}</td>
            <td>
              <span class="badge bg-${p.status==='published'?'success':'secondary'}">
                ${p.status}
              </span>
            </td>
            <td>
              <button class="btn btn-sm btn-warning editBtn" data-id="${p.id}" onclick='editPage(${p.id});'>
                Edit
              </button>
              <button class="btn btn-sm btn-danger deleteBtn" data-id="${p.id}" onclick="deletePage(${p.id});">
                <i class="fas fa-trash"></i>
              </button>
            </td>
        </tr>`;
    });


    tbody.html(html);
    }catch(e){
    	alert(e);
    }
}


function createPageForm() {
  $('#createPageForm')[0].reset();
togglePage('sectionCreatePage');
}


function filterPages(t, status){
	const tbody = $('#pageTableBody');
  
   const pages=status?__pages.data.filter(x=>x.status==status): __pages.data;
   $('.filter-page-btn').removeClass('btn-success').addClass('btn-secondary');
   $(t).removeClass('btn-secondary').addClass('btn-success');
   renderPages(pages);
	}
	
function savePage(t) {

  const id=$('#pageId').val();
  const pageTitle=$('#pageTitle').val().trim();
  const slug=$('#pageSlug').val().trim();
  const content=$('#pageContent').val().trim();
  const description=$('#pageDescription').val().trim();
  const status=$('#pageStatus').val().trim();

const form=document.getElementById("createPageForm");

const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

postData( 'save-page', payload, function(data, error, e){
  	//alert( JSON.stringify( data))
	if( error) {
		showToast(error)
		return;
		}


if(!id) {
	payload['id']=data.id;
	__pages.data.push( payload);
	renderPages();
 $('#createPageForm')[0].reset(); 
}
else{
		const page=__pages.data.find(x=>x.id==id);

	page.status=status||'draft';
renderPages();
   $('.filter-page-btn').removeClass('btn-success').addClass('btn-secondary');
   $('#all-pages-filter-btn').removeClass('btn-secondary').addClass('btn-success');

	}
 return showToast(data.message, 'success');
  
  });
}

// Edit

function editPage(id) {
   const payload={
    id: id
    }

 fetchData(`get-page`, payload, function(data, error, e){
   //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
   const p=data.data;
    
  $('#pageId').val(p.id);
  $('#pageTitle').val(p.title);
  $('#pageSlug').val(p.slug);
  $('#pageContent').val(p.content);
  $('#pageContent').val(p.content);
  $('#pageDescription').val(p.description);
  $('#pageStatus').val(p.status);

  togglePage('sectionCreatePage');
      }
  });
}

function deletePage(id) {

const page=__pages.data.find(x=>x.id==id);
const title=page.title;
const status=page.status;

if(!confirm(`Delete page ${title}${status=='deleted'?' permanently':''}?`)) return;
	
   const payload={
    id: id,
    status: status
    }

 fetchData(`delete-page`, payload, function(data, error, e){
   //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){ 
  if( status=='deleted'){
  $(`#page-tr-${id}`).remove();
  __pages.data=__pages.data.filter(x=>x.id!=id);
  
  }else{
   page.status='deleted';
renderPages();
 
   $('.filter-page-btn').removeClass('btn-success').addClass('btn-secondary');
   $('#all-pages-filter-btn').removeClass('btn-secondary').addClass('btn-success');
}
    showToast(data.message, 'success');
      }
  });
}


function formatMoney(amount, deci=2) {
  return Number(amount).toLocaleString('en-US', {
    minimumFractionDigits: deci,
    maximumFractionDigits: deci
  });
}


// Debounce
function debounce(func, delay) {
    let timer;
    return function () {
        clearTimeout(timer);
        timer = setTimeout(func, delay);
    };
}


// Save product
$('#productForm').on('submit', function (e) {
    e.preventDefault();

const form=this;

    if (!this.checkValidity()) {
        $(this).addClass('was-validated');
        return;
    }

  let productImages=[];
      $('.prod-img-item').each(function(){
      	productImages.push($(this).data('id'));
      });
      
    let payload = {
        id: $('#product-product_id').val(),
        featured_rank: $('#product-featured-rank').val(),
        status: $('#product-status').val(),
        name: $('#product-name').val().trim(),
        slug: $('#product-slug').val().trim(),
        price: parseFloat($('#product-price').val()),
        sale_price: parseFloat($('#product-sale_price').val()) || null,
        cost_price: parseFloat($('#product-cost_price').val()) || null,
        stock_quantity: parseInt($('#product-stock_quantity').val()) || 0,
        image: $('#product-image').val(),
        description: $('#product-description').val(),
        full_description: $('#product-full-description').val(),
        categories: $('#product-categories').val() || [],
        images: productImages||[]// 👈 ARRAY
        
    };


   if (!payload.name) {
        alert('Product name is required');
        return;
    }
    
    let btn=$(form).find('button');
        btn.prop('disabled', true);
       
    postData('save-product', payload, function(data, error, e){
  //  alert( JSON.stringify(data))
  
        btn.prop('disabled', false);
     if( error) {
          showToast( error);         
   return; 
   }

   showToast(data.message, 'success');
   
  if(payload.id) {	
 
 }else{
 	resetProductForm();
 }
  
  $(form).removeClass('was-validated');   
    });       
});

async function loadFullDoc(url) {
    try {
        const res = await fetch(url);
        const html = await res.text();

        document.open();
        document.write(html);
        document.close();

        history.pushState({}, '', url);

    } catch (err) {
        console.error('Page load failed:', err);
    }
}

 //LOAD USERS

 function populateUsers(){
  
  let tableRows = '';
  
    __users.forEach((data,i)=>{
        tableRows += `
                    <tr data-id="${data.id}" class="${data.branch_id==1?'d-none':''}">
                        <td>${i + 1}</td>                       
                        <td>${escapeHtml( data.full_name)}</td>
                        <td>${escapeHtml( data.role) }</td>
                        <td>${escapeHtml( data.branch_name || '')}</td>              
                        <td>${escapeHtml( data.phone || '')}</td>
                        <td>${escapeHtml( data.email || '')}</td>
                       <td>
         <button class="btn btn-sm btn-outline-primary me-1" data-id="${data.id}" onclick="editUserForm(this);"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-sm btn-outline-danger" data-id="${data.id}" onclick="deleteUser(this);"><i class="fas fa-trash"></i></button>
</td>
                    </tr>`;      
   });
   
$('#usersListTable').html(tableRows);	
}

function loadUserProfile(){
	let data=__users.find((data)=>data.id==__userId);
	$('#profile_fullname').text( escapeHtml( data.full_name ) );
	$('#profile_phone').text( escapeHtml( data.phone) );
	$('#profile_email').text( escapeHtml( data.email) );
	$('#profile_role').text( escapeHtml( data.role) );	
	}

function editUserForm(t, owner){
		const this_=$(t);
		
	const id=owner?__userId:this_.data('id');

if( owner){
	$('#show-edit-old-password').removeClass('d-none');
	}else {
	$('#show-edit-old-password').addClass('d-none');
}

let data=__users.find((b)=>b.id==id);

$('#edit-user-id').val( data.id);
$('#edit-user-full_name').val( data.full_name);
$('#edit-user-role').val( data.role);
$('#edit-user-phone').val( data.phone);
$('#edit-user-email').val( data.email);
$('#edit-user-username').val( data.username);
$('#edit-user-branch').val( data.branch_id);

$('#edit-user-current-password,#edit-user-new-password').val('');

togglePage('sectionEditUser');
}


function deleteUser(t){ 
	const this_=$(t);
	const id=this_.data('id');
	const name=__users.find((data)=>data.id==id).full_name;

if(!confirm(`Delete user: ${name}\n\nThis action is not reversible`)) return;	

fetchData(`delete-user?id=${id}`, {}, function(data, error){
	 	if( error){
	return	showToast(error);
		}
	
if(data.success){	
__users=__users.filter((data)=>data.id!=id);
 populateUsers();
showToast( data.message, 'success');
}
	});	
}
	

/* ================================
   HELPER FUNCTION TO SEND TOKEN
================================ */

function fetchData(page, data={}, callback){
    let token=osStorage.get("token")||""

$('#ajax-loader-container').fadeIn();

$.ajax({
        url: apiServerUrl + "/" +page,
        method: 'GET',
        contentType: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
       data: data
       }).done(function(data) {             	
       //	alert( JSON.stringify( data))
    
$('#ajax-loader-container').fadeOut();
 
	if( data.loginRequired ){
 	   location.href=serverUrl + '/admin/login.php';
 return;
 }
        if( data.success)   callback(data)
else callback('', data.message);
	
   }).fail( function(e, txt, xhr) {
   	//alert( JSON.stringify( e))
   $('#ajax-loader-container').fadeOut();
   const errorJson	= e.responseJSON?.error||'';
   const errorText	= e.responseText||'';
   const errorMsg=errorJson||errorText||"Check your internet connection";

        	callback("", errorMsg, e);
       });
}


function postData(page, postData, callback){
    let token=osStorage.get("token")||""

  $('#ajax-loader-container').fadeIn();

$.ajax({
        url: apiServerUrl + "/" +page,
        method: 'POST',
        contentType: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
        data: JSON.stringify(postData)
       }).done(function(data) {      
       //	alert( JSON.stringify( data))
       $('#ajax-loader-container').fadeOut();
 	if( data.loginRequired ){
 	   location.href=serverUrl + '/admin/login.php';
 return;
 }
        if( data.success)   callback(data)
else callback('', data.message||'Check your internet connection');
	
   }).fail( function(e, txt, xhr) {
   	$('#ajax-loader-container').fadeOut();
   	//alert( JSON.stringify( e))
   const errorJson	= e.responseJSON?.error||'';
   const errorText	= e.responseText||'';
   const errorMsg=errorJson||errorText||"Check your internet connection";

        	callback("", errorMsg,e);
        })
}


$(function(){
	
$('body').on('click','.page-blur', function(e){
 	history.go(-1);
 });

$('#createUserForm').on('submit', function (e) {

    e.preventDefault();
const alertBox = $('#alertBox');

let form = this;


   if (!$(this)[0].checkValidity()) {
        $(this).addClass('was-validated');
        return;
    }

    const payload = {
        role: document.getElementById('role').value,
        full_name: document.getElementById('full_name').value.trim(),
        username: document.getElementById('username').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        email: document.getElementById('email').value.trim(),
        password: document.getElementById('password').value
    };

  let btn=$(form).find('button');
        btn.prop('disabled', true);
   
  postData('create-user', payload, function(data, error){
  	btn.prop('disabled', false);
       alertBox.removeClass('d-none, alert-success, alert-danger');
        
if( error){
            showToast( error, 'error');  
            alertBox.addClass('alert-danger');
            alertBox.text(error || 'Failed to create user');
            return;
        }

  showToast(data.message || 'User created successfully', 'success');
            alertBox.addClass('alert-success');
            alertBox.text(data.message || 'User created successfully');
            form.reset();
            $(this).removeClass('was-validated');         
            return;      
  });
  
});

$('#editUserForm').on('submit', function (e) {
    e.preventDefault();
const alertBox = $('#alertBox');

const form=this;

   if (!$(this)[0].checkValidity()) {
        $(this).addClass('was-validated');
        return;
    }

let id=document.getElementById('edit-user-id').value;
let role=document.getElementById('edit-user-role').value;
let branch=+(document.getElementById('edit-user-branch').value.trim());

let data=__users.find((b)=>b.id==id);

let userRole=data.role;
let userBranch=+data.branch_id;

if( __userId==id && userRole!==role){
	return showToast("You cannot change your own role");
	}
	
if( __userId==id ){
	return showToast("You cannot change your own branch");
	}

    const payload = {
    	id: id, 
        role: role,
        full_name: document.getElementById('edit-user-full_name').value.trim(),
        username: document.getElementById('edit-user-username').value.trim(),
        phone: document.getElementById('edit-user-phone').value.trim(),        
        email: document.getElementById('edit-user-email').value.trim(),
        oldPassword: document.getElementById('edit-user-current-password').value.trim(),
        newPassword: document.getElementById('edit-user-new-password').value.trim()      
    };

  	let btn=$(form).find('button');
        btn.prop('disabled', true);
        
  postData('edit-user', payload, function(data, error){
        btn.prop('disabled', false);
        
       alertBox.removeClass('d-none, alert-success, alert-danger');
        
if( error){
            showToast( error, 'error');  
            return;
        }

$('#edit-user-current-password,#edit-user-new-password').val('');

  showToast(data.message || 'User updateda successfully', 'success');
           // form.reset();
            $(this).removeClass('was-validated');         
            return;      
  });
  
});

});

function showToast(message, type = "error") {
    var bg = "#d32f2f"; // error (red)

    if (type === "success") bg = "#2e7d32";
    if (type === "info")    bg = "#1976d2";
    if (type === "warning")    bg = "#f57c00";

    var toast = $('<div class="custom-toast"></div>').text(message);

    toast.css({
        position: "fixed",
        bottom: "20vh",
        left: "50%",
        width: "90%",
        maxWidth: "280px",
        transform: "translateX(-50%)",
        background: bg,
        color: "#fff",
        padding: "10px 18px",
        borderRadius: "6px",
        zIndex: 9999,
        display: "none",
        fontSize: "14px",
        boxShadow: "0 4px 10px rgba(0,0,0,.2)"
    });

    $("body").append(toast);

    toast.fadeIn(200).delay(3000).fadeOut(300, function () {
        $(this).remove();
    });
}

function escapeHtml(text) {
    return $('<div>').text(text).html();
}

function logOut(){
	if(!confirm('Confirm you want to logout')) return;
	
	try{
const token=localStorage.getItem('token')||''
	fetchData(`logout?token=${token}`, {} , function(data, error){
   
 if( error){
   showToast( error);
return;
}

localStorage.removeItem('token');
localStorage.removeItem('token_expiry');
localStorage.removeItem('userRole');
location.href=serverUrl + '/admin/login.php';
});
}catch(e){ alert(e);
}
}


/*ANIMATION & CHARTS*/

function animateValue(id, start, end, duration, isAmount=false) {

const el=$("#"+id);


  if( end==0) {
    el.text(isAmount?end.toFixed(2):end)
 return;
}
  
let range = end - start
let current = start
let increment = end > start ? 1 : -1
let stepTime = Math.abs(Math.floor(duration / range));

let timer = setInterval(function(){

current += increment

if( current==200) increment=increment*5000;

if(current >= end){
	current=end;
clearInterval(timer)
}

if( isAmount) {
	 if( current<1000 )
el.text( current.toFixed(2));
 else el.text(current.toLocaleString('en-US') );
 return;
}else{
	el.text(current);
	}

}, stepTime)

}

function salesChart( labels, sales){
const ctx = document.getElementById('salesChart')

new Chart(ctx, {

type:'line',

data:{
labels:labels,
datasets:[{
label:'Sales',
data:sales,
borderWidth:3,
fill:true
}]
},

options:{
responsive:true,
plugins:{
legend:{
display:true
}
}
}

})

}


function timeAgo(dateString, noFormat){

    let date = new Date(dateString);
    let now = new Date();

    let diff = now - date;
    let oneDay = 1000 * 60 * 60 * 24;

    let days = Math.floor(diff / oneDay);

    let time = date.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

    let fullDate = date.toLocaleDateString('en-US', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    }) + " " + time;

if( noFormat)  return fullDate;

    if(days === 0){
        return "Today, " + time;
    }
    else if(days === 1){
        return "1 day ago, " + time;
    }
    else if(days === 2){
        return "2 days ago, " + time;
    }
    else{
        return fullDate;
    }
}


//UPLOAD

let uploadedFiles = [];
let uploadFiles=[];

$('#imageInput').on('change', function(e) {
	uploadFiles=[];
    handleFiles(e.target.files);
});

// Drag & drop
$('#uploadArea').on('dragover', function(e) {
    e.preventDefault();
    $(this).addClass('border-primary');
});

$('#uploadArea').on('dragleave', function() {
    $(this).removeClass('border-primary');
});

$('#uploadArea').on('drop', function(e) {
    e.preventDefault();
    $(this).removeClass('border-primary');
    uploadFiles=[];
    handleFiles(e.originalEvent.dataTransfer.files);
});

$('#image-upload-btn').on('click', function(){
  if( uploadFiles.length<1 ){
  	showToast('Select an image');
 }
	$.each(uploadFiles, function(i, file) {
        uploadFile(file);      
	});

});

// Handle files
function handleFiles(files) {

    if ((uploadedFiles.length + files.length) > 4) {
        alert("Maximum 4 images allowed");
        return;
    }

    const uploadBtn=$('#image-upload-btn');

   let showUploadBtn=false;
    uploadBtn.hide();


    $.each(files, function(i, file) {
        if (!file.type.startsWith('image/')) return;
        const id=Date.now() + '-' + i;
        file.imgId=id;
        file.index=i;
        previewImage(file, id);
        uploadFiles.push(file);
        showUploadBtn=true;
        
        //uploadFile(file);
    });
    
    if( showUploadBtn){
    	uploadBtn.show();
   }
}

// Upload single file
function previewImage(file) {
  const imgId=file.imgId;
 
    let col = $(`
        <div class="col-6 col-md-3" id="col-${imgId}">
            <div class="card position-relative">
                <img class="card-img-top preview-img" style="height:120px; object-fit:cover;">
               <div class="mt-2" style="max-width: 90%; margin-left: auto; margin-right: auto;">
               <label for="image-upload-desc">Description</label>
<input type="text" class="form-control image-upload-desc">
             </div>
                <div class="p-2">
                    <div class="progress" style="height:6px;">
                        <div class="progress-bar" style="width:0%"></div>
                    </div>
                </div>

                <button class="btn btn-danger btn-sm position-absolute top-0 end-0 m-1 remove-btn">&times;</button>
            </div>
        </div>
    `);

    $('#previewContainer').append(col);

    let img = col.find('.preview-img');    

    // preview
    let reader = new FileReader();
    reader.onload = e => img.attr('src', e.target.result);
    reader.readAsDataURL(file);
}

function uploadFile(file) {
	let token=osStorage.get("token")||""

	const fileIndex=file.index;
	const imgId=file.imgId;
	
	const col=$(`#col-${imgId}`);
	
	let progressBar = col.find('.progress-bar');
	let imgDesc = col.find('.image-upload-desc');
	
    let formData = new FormData();
    formData.append('image', file);
   // formData.append('token', token);
    
formData.append('meta', JSON.stringify({
    description: imgDesc.val()
}));

if (uploadedFiles.length >= 4) {
    showToast("Max 4 images reached");
    $('#imageInput').prop('disabled', true);
    return;
}

    $.ajax({
        url: apiServerUrl + '/upload',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
        xhr: function() {
            let xhr = new window.XMLHttpRequest();

            xhr.upload.addEventListener("progress", function(e) {
                if (e.lengthComputable) {
                    let percent = (e.loaded / e.total) * 100;
                    progressBar.css('width', percent + '%');
                }
            });

            return xhr;
        }
}).done(function(res) {
   alert( JSON.stringify(res))
   
            let response = (typeof res === 'string') ? JSON.parse(res) : res;

            if (response.success) {
            	
            uploadFiles.splice(fileIndex, 1);
             const result=response.result;
             
    result.forEach(resp=>{ 
      uploadedFiles.push(resp.links.direct);
      });
            
    updateHiddenInput();
                progressBar.addClass('bg-success');
             
      let input = document.getElementById('imageInput');
input.type = '';
input.type = 'file';

                return;
            } 
            
                col.remove();
              showToast(response.message||'Upload failed');
        }).fail(function(e, txt, xhr) {
        //	alert( JSON.stringify(e))
            col.remove();
            $('#imageInput').prop('disabled', false);
            showToast("Upload error");
        });
        
    // remove image
    col.find('.remove-btn').on('click', function() {
        
        let index = $('#previewContainer .col-6').index(col);
        uploadedFiles.splice(index, 1);
        col.remove();
        updateHiddenInput();
    });
}

// Sync hidden input
function updateHiddenInput() {
    $('#uploadedImages').val(JSON.stringify(uploadedFiles));
}


// Load products
let selectedImages = new Map();

function loadGallery(t, id='') {
	
	let this_=$(t||this);
    let page=this_.attr('data-page')||1;
 
    let search = $('#gallery-search').val()||'';
    
 const payload={
 	   id: id,
        p: page,
        s: search,
        view: 1
    }

 fetchData(`gallery`, payload, function(data, error, e){
    // alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
        renderGallery(data);
       //togglePage('sectionGallery');
	 }
  });
}

function renderGallery(data){
	let html = '';

        $('#galleryGrid').empty();

        data.data.forEach(item => {

 html+= `<div class="col-6 col-md-3" id="gallery-image-${item.id}">
                <div class="card gallery-item" id="gallery-item-${item.id}" data-id="${item.id}" data-url="${item.url}">
                    
                    <img src="${productImage(item.url)}" class="card-img-top"
                         style="height:150px; object-fit:cover;">

                    <div class="p-2 small text-truncate">
                        ${item.description || 'No description'}
                    </div>

                    <div class="gallery-overlay">
                        <button class="btn btn-light btn-sm edit-btn">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-danger btn-sm delete-btn">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>

                </div>
            </div>
            `;
});

  
$('#galleryGrid').html(html);
        bindGalleryEvents();    
        
     //Select already selected images
    let items = Array.from(selectedImages, ([id, url]) => ({ id, url }));
    
   items.forEach(img=>{
   	$(`#gallery-item-${img.id}`).addClass('product-image-selected');
   });
    
    
        $('#prevGallery,#nextGallery').addClass('d-none');
   
	if( data.next){
		$('#nextGallery').removeClass('d-none').attr('data-page', data.next);
		}
	
	if( data.prev){
		$('#prevGallery').removeClass('d-none').attr('data-page', data.prev);
	}

}



$(document).ready(function () {
    $('#refreshGallery').click(loadGallery);
});

function showSelectedImages(items){
	//Display in add/Edit product form
// get all items
// array of {id, url}

if(!items) items = Array.from(selectedImages, ([id, url]) => ({ id, url }));

let html='<div class="d-flex justify-content-start gap-2 wrap bg-light rounded">';

	if( items.length <1) return;
	items.forEach(item=>{		
html+= `<div class="prod-img-item" id="prod-img-item-${item.id}" data-id="${item.id}" data-url="${item.url}" style="width: 60px; height: 60px; position: relative; border-radius: 8px; overflow: hidden;">
<button class="position-absolute btn btn-sm btn-danger" onclick="removeProductImg(${item.id})" style="right: 0;"><i class="fas fa-times"></i></i></button>
   <img src="${productImage(item.url)}" class="card-img-top" style="height: 100%; width: 100%; object-fit:cover;">
</div>`;
	});	
html+='</div>';

  $('#product-images-selected').html(html);
}
	
function removeProductImg(id){
	selectedImages.delete(id);	
	$(`#prod-img-item-${id}`).remove();
}

function bindGalleryEvents() {

    // SELECT
    
$('.gallery-item').off('click').on('click', function (e) {

    if ($(e.target).closest('button').length) return;

    let id = $(this).data('id');
    let imgUrl = $(this).data('url');

    if (selectedImages.has(id)) {
        selectedImages.delete(id);
        $(this).removeClass('product-image-selected');
    } else {
        selectedImages.set(id, imgUrl);
        $(this).addClass('product-image-selected');
        showToast('Selected', 'info');
    }
});

    // EDIT
    $('.edit-btn').off('click').on('click', function (e) {
        e.stopPropagation();

        let parent = $(this).closest('.gallery-item');
        let id = parent.data('id');

        let currentDesc = parent.find('.p-2').text();

        let newDesc = prompt("Edit description:", currentDesc);

        if (newDesc === null) return;

        $.post('gallery_update.php', {
            id: id,
            description: newDesc
        }, function () {
            loadGallery();
        });
    });

    // DELETE
    $('.delete-btn').off('click').on('click', function (e) {
        e.stopPropagation();

        let parent = $(this).closest('.gallery-item');
        let id = parent.data('id');

        if (!confirm("Delete this image?")) return;

        const payload={
 	   id: id,
        delete: 1
    }

 fetchData(`gallery`, payload, function(data, error, e){
   //alert(JSON.stringify(data))	 
	if( error){
	return showToast(error);
	}
	
  if( data.success){  	
           // loadGallery();
           $(`#gallery-image-${id}`).remove();
           showToast(data.message, 'success');
           }
        });
    });
}


function sendToWhatsApp(message, phone) {
  phone=(phone||config.contact.whatsapp).replace(/\+/g, "");

  const encodedMessage = encodeURIComponent(message);
  
  const url = `https://api.whatsapp.com/send/?phone=${phone}&text=${encodedMessage}`;
  window.open(url, "_blank");
}

//SETTINGS

function populateSettings(config){
	//alert( JSON.stringify(config))
  Object.keys(config).forEach(section => {
  
  Object.keys(config[section]).forEach(key => {

      let input = $(`[name="${section}.${key}"]`);

      if(!input.length) return;

      if(input.attr("type") === "checkbox"){
        input.prop("checked", !!config[section][key]);
      } else {
        input.val(config[section][key]);
      }

    });
  });
}


function getSectionData(form){
  let data = {};
  let formArray = form.serializeArray();

  form.find('input[type=checkbox]').each(function(){
    formArray.push({
      name: this.name,
      value: this.checked
    });
  });

  formArray.forEach(item => {
    let key = item.name.split('.')[1];

    data[key] =
      item.value === true || item.value === "true" ? true :
      item.value === false || item.value === "false" ? false :
      isNaN(item.value) ? item.value : Number(item.value);
  });

  return data;
}

$(document).on("click", ".save-section", function(){

  let btn = $(this);
  let section = btn.data("section");
  let form = $(`form[data-section="${section}"]`);
  let data = getSectionData(form);

  btn.prop("disabled", true)
     .html('<i class="fa fa-spinner fa-spin"></i>');
     
     
  postData("save-settings",   { section, data }, function(data, error, e){
  	//alert( JSON.stringify( error))
  	btn.prop("disabled", false)
         .html('<i class="fa fa-save"></i> Save');
   if( error){
    return showToast(error)
}      
      showToast( section + " saved",  "success");
      
  });

});


function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
        return navigator.clipboard.writeText(text);
    }

    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();

    try {
        document.execCommand('copy');
    } finally {
        document.body.removeChild(textarea);
    }

    return Promise.resolve();
}


function runCron(key, intervalMs, callback) {
  const now = Date.now();
  const lastRun = parseInt(localStorage.getItem(key) || 0);
  
  if (now - lastRun >= ( intervalMs * 60 *1000)) {
    callback(); // run your function
    localStorage.setItem(key, now); // update last run time
  }
}

function applyUpdateInfo(data){
	try{
	if( !data) return;
	if( typeof data==='string'){
		//alert( data)
		data=JSON.parse(data);
	}
	$('#software-update-indicator').text( data.version);
	$('.new-software-version').text( data.version);
	
	let newFeatures='';
data.newFeatures.forEach(v=>{ 
	newFeatures+=`<li>${v}</li>`;
	});
	$('#new-version-features').html(newFeatures);
	
	if( data.new_update){
		$('.software-version-title').html(`Version <strong>${data.version}</strong> is now available.`);
		$('#updateSoftwareBtn').removeClass('d-none').attr('data-url', data.download_url);
		return;
		}
	
	$('.software-version-title').html(`<i class="fas fa-check-circle text-success"></i> Hurray! You have the latest version.`);
	}catch(e){
		alert(e)
		}
}

// Usage - put this in $(document).ready()
$(document).ready(function() {
  
$('#updateSoftwareBtn').click(function(){
  const this_=$(this);
  const softUrl=this_.attr('data-url');

    if (!confirm('Run software update?')) return;

    const btn = $(this);
    const bar = $('#updateProgress');
    const status = $('#updateStatus');

    btn.prop('disabled', true);
    bar.css('width', '0%').text('0%');
    status.text('Starting update...');


fetchData("update-software",   { url: softUrl}, function(data, error, e){
  	//alert( JSON.stringify( error))
  	btn.prop("disabled", false)
         .html('<i class="fa fa-save"></i> Save');
   if( error){
   	status.text('Update failed: ' +error);
    return 
}      
      bar.css('width', '100%').text('100%');
      status.text(res.message);
      
  });

/*
    $.ajax({
        url: `${serverUrl}/api/update-software`,
        type: 'POST',
        dataType: 'json'
    })
    .done(function (res) {

alert( JSON.stringify(res))

        if (res.success) {
            bar.css('width', '100%').text('100%');
            status.text(res.message);
        } else {
            status.text(res.message);
        }

    })
    .fail(function (xhr) {
        status.text('Update failed: server error');
    })
    .always(function () {
        btn.prop('disabled', false);
    });
    
    */
    
 });
  
 
  applyUpdateInfo( localStorage.getItem('software-update-info'));
  
  // 1. Check every 1 minute
  runCron('update-check', 1 , function() {
  	
       $.getJSON(`${serverUrl}/api/check-for-update`, function(data) {
       	//alert( JSON.stringify(data))
      localStorage.setItem('software-update-info',  JSON.stringify(data ) );
      applyUpdateInfo(data);
    });
  });
  
});

// Optional: detect changes
window.addEventListener('resize', () => {
    //console.log('Updated viewport width:', window.innerWidth);
    
    let el=$('#header-menu-container');
   
if(el.hasClass('menuOpen') ){
	//toggleMenu(false, true);
}
    
});
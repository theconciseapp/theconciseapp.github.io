if( typeof osLandingUrl==='undefined'){

	let url___params=location.href.split('?');
		  var osLandingUrl= url___params[0] +(url___params[1] ? '?' + url___params[1]:'');
		 var osPageTitle=document.title||'';
  }

	//Initiate custom history
var myHistory=[{URL: osLandingUrl, pageTitle: document.title }];

function pushState_(data, pageUrl, pageTitle, replaceState){
   let ind=zIndex();

   pageTitle=pageTitle||data.pageTitle||data.title||osPageTitle;
   pageUrl=pageUrl||location.href;
   
   data['URL']=pageUrl;
   data['zIndex']= ind;
   data['pageTitle']=pageTitle;
  
 if( data['element'] ) {
$(data['element']).css('z-index', ind);
}

if( replaceState){
	window.history.replaceState(data, pageTitle, pageUrl);
	}else{
window.history.pushState(data, pageTitle, pageUrl);
myHistory.push(data);
}

document.title=pageTitle;
//Push to custom history
}


function _pushState(data, pageUrl, pageTitle){
  pushState_( data, pageUrl, pageTitle);
}

function _replaceState(data, pageUrl, pageTitle){
  pushState_( data, pageUrl, pageTitle, true);
}

let backPressed=0;
let popstateData={};
let currentState={};
let osPopstateFuncs={};

window.addEventListener("popstate", function (event) {
	
 let totalHistory=myHistory.length;
  
  if( totalHistory==0){
  	//Exit browser
  	history.back();
  
  history.pushState({}, null, window.location.pathname);
  return;
 }  

if( backPressed) {
	
	osOnBackPressed( popstateData, currentState);
  if(	popstateData.pageTitle) document.title=popstateData.pageTitle;

	window.history.replaceState(popstateData,  popstateData.pageTitle||document.title,  popstateData.URL );
	backPressed=0;
	return;
}

 if(  totalHistory){
  	
     currentState=myHistory[myHistory.length-1];
     myHistory.pop();
     popstateData=myHistory[myHistory.length-1];
  }
  
  backPressed++;
   window.history.replaceState({}, document.title,  location.pathname );
   
  window.history.forward();
});

function zIndex(){
  var zindex=$("#z-index");
  if(!zindex.length ){
  	$("body").append('<input type="hidden" id="z-index" value="60">');
  }
  var zi=+zindex.val()||40;
 
  zindex.val( zi+20);
   return zi;
 }

 
 function osOnBackPressed(estate, currentState){
		$.each( osPopstateFuncs, function(key, func){
		func(estate, currentState);
		});
	
 if( !estate){
		let title=document.title||'';
		history.replaceState({}, title, osLandingUrl);
		}
		
	if( currentState.no_cancel ){
pushState_({no_cancel:1});
	return;	
}

	if( currentState.close ){
	OsRunFunction(currentState.close, currentState.args);
	}

}
	
function OsRunFunction(name, args)
{
	
    var fn = window[name];
   
    if(typeof fn !== 'function')
        return;
    fn.apply(window, args);
}
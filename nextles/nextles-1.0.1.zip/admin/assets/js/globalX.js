const OsUrlObj = new URL(window.location.href);
const OsBaseUrl = OsUrlObj.origin + OsUrlObj.pathname.replace(/\/$/, '');

class OsStorageManager {
  constructor(appName, instanceId = '') {
  	
//const appName=`Os_${window.btoa(OsBaseUrl)}`

    this.prefix = `${appName}${instanceId ? '_' + instanceId : ''}_`;
  }

  _getKey(key) {
    return this.prefix + key;
  }

  set(key, value) {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(this._getKey(key), serialized);
    } catch (e) {
      console.error('Storage set error:', e);
    }
  }

  get(key, defaultValue = null) {
    try {
      const item = localStorage.getItem(this._getKey(key));
      return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
      console.error('Storage get error:', e);
      return defaultValue;
    }
  }

  remove(key) {
    try {
      localStorage.removeItem(this._getKey(key));
    } catch (e) {
      console.error('Storage remove error:', e);
    }
  }

  clearAppData() {
    try {
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k.startsWith(this.prefix)) keysToRemove.push(k);
      }
      keysToRemove.forEach(k => localStorage.removeItem(k));
    } catch (e) {
      console.error('Storage clearAppData error:', e);
    }
  }
}


// Suppose your app is called "ShopX" and installed in folder "store1"
const osStorage = new OsStorageManager('Os-shop','store1');

// Save token
//osStorage.set('token', 'USER_TOKEN_HERE');
// Retrieve token
//const token = osStorage.get('token');

// Remove token
//osStorage.remove('token');
// Clear all data for this app instance
//osStorage.clearAppData();


class OsNetwork {
	
	fetch(options){

	 const page=options.page;
     const GetData=options.data||{};
     const siteId=options.siteId||'abcde';
     const url= options.url||`${OsBaseUrl}/api/${page}`
     const token=options.token||osStorage.get("token")||"";

     //sessionStorage.getItem('OsPaystackLocal')||"https://www.oshobby.com.ng/ecommerce/api";

  GetData['token']=token;
  GetData['site_id']=siteId;

   options.init && options.init();
 
$.ajax({
        url: url,
        method: 'GET',
        contentType: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
       data: GetData
       }).done(function(data) {             	
       
      options.always && options.always();
 
	if( data.loginRequired ){
		if( options.login && options.login(data) ){
			return;
		}
		
 	   location.href=OsBaseUrl + '/login.php';
 return;
 }
 
        if( data.success|| data.status){
   options.done && options.done(data);
   return;
 }
 options.error && options.error( data, data.message||data.error);
	
   }).fail( function(e, txt, xhr) {
   const errorJson	= e.responseJSON?.error||'';
   const errorText	= e.responseText||'';
   const errorMsg=errorJson||errorText||"Error occured";
  
   options.fail && options.fail(e, errorMsg);
   options.always && options.always();
       });
}


	post(options){

     const page=options.page;
     const PostData=options.data||{};
     const isUpload= options.isUpload;
     const siteId=options.siteId||'abcde';
     const url= options.url||`${OsBaseUrl}/api/${page}`
     const token=options.token||osStorage.get("token")||"";    
 
  //sessionStorage.getItem('OsPaystackLocal')||"https://www.oshobby.com.ng/ecommerce/api";

  PostData['token']=token;
  PostData['site_id']=siteId;
  
   options.init && options.init();
  
const p_options={
        url: url,
        method: 'POST',
        contentType: isUpload?false: 'application/json',
        headers: {
            'Authorization': 'Bearer ' + token,
            'X-Auth-Token': token
        },
        data: isUpload?PostData:JSON.stringify(PostData)
       };

if( isUpload){
	p_options['processData']= false;
	}

$.ajax(p_options).done(function(data) {      
       options.always && options.always(data);
      
if( data.loginRequired ){
		if( options.login && options.login(data) ){
			return;
		}
		
 	   location.href=OsBaseUrl + '/login.php';
 return;
 }
	
	if( data.success|| data.status){
   options.done && options.done(data);
   return;
 }
 options.error && options.error( data, data.message||data.error||'An error occured');
 
   }).fail( function(e, txt, xhr) {  	
   
   const errorJson	= e.responseJSON?.error||'';
   const errorText	= e.responseText||'';
   const errorMsg=errorJson||errorText||"Error occured";
      
        options.fail && options.fail(e, errorMsg, txt, xhr);
   options.always && options.always();

       })
  }
  
  
}

	
const Os=new OsNetwork();
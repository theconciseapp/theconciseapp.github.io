//LOGIN
	const loginForm = document.getElementById('loginForm');
const alertBox = document.getElementById('alertBox');

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!loginForm.checkValidity()) {
        loginForm.classList.add('was-validated');
        return;
    }

  const redirect= document.getElementById('redirect').value.trim();
  
    const payload = {
        login: document.getElementById('login').value.trim(),
        password: document.getElementById('password').value
    };

alertBox.classList.add('d-none');

let btn=$(loginForm).find('button');
        btn.prop('disabled', true);
      btn.find('i').removeClass('d-none');


    try {
    
        const res = await fetch(apiServerUrl + "/login", {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
  
setTimeout(()=>{
btn.prop('disabled', false);
btn.find('i').addClass('d-none');
  },1000);   	     
 
        const data = await res.json();

        alertBox.classList.remove('d-none','alert-success','alert-danger');

        if (data.success) { 
     
        	try{
        // ✅ Store token in localStorage
            osStorage.set('token', data.token);
            osStorage.set('token_expiry', data.token_expiry);
            osStorage.set('userRole', data.user.role);
            alertBox.classList.add('alert-success');
            
            }catch(e){
    alert(e);
            }
            alertBox.textContent = 'Login successful!';
            loginForm.reset();
            loginForm.classList.remove('was-validated');
        
    location.href=redirect||serverUrl + '/admin';
                  } else {
            alertBox.classList.add('alert-danger');
            alertBox.textContent = data.message || 'Login failed';
        }

    } catch (err) {
    	alert( JSON.stringify( err))
        alertBox.classList.remove('d-none');
        alertBox.classList.add('alert-danger');
        alertBox.textContent = 'Network error. Please try again.';
    }
});
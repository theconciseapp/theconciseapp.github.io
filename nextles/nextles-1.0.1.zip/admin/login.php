<?php 
require "../ProjectClasses/bootstrap.php";
require "../ProjectClasses/main.php";

$api=new ProjectAPI();
$redirectTo=htmlspecialchars($_GET['redirect']??'');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>
<script>
const serverUrl="<?php echo $api->site_url();?>";
const apiServerUrl=serverUrl + "/api";
</script>

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7.2.0/css/all.min.css">
<link rel="stylesheet" href="assets/css/login.css?i=0">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
</head>
<body>

<!--LOGIN-->

<section id="loginSection">

<div class="container pt-4 pb-2">
    <div id="logo-container">
    <img src="logo.png?i=0">
</div>
</div>
<div class="container pt-3 pb-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">

            <div class="card shadow-sm">
                <div class="card-body p-4">

                    <h4 class="mb-3 text-center">Login</h4>

                    <form id="loginForm" novalidate>

<input type="hidden" id="redirect" value="<?php echo $redirectTo;?>">
                        <!-- Email or Username -->
                        <div class="mb-3">
                            <label class="form-label">Email or Username</label>
                            <input type="text" class="form-control" id="login" required>
                            <div class="invalid-feedback">Please enter your email or username.</div>
                        </div>

                        <!-- Password -->
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" required>
                            <div class="invalid-feedback">Please enter your password.</div>
                        </div>
            <!-- Remember -->
                            <div class="d-flex justify-content-between align-items-center mb-4">

                                <div class="form-check">

  <input class="form-check-input" type="checkbox" id="remember-me" name="remember">
                                    <label class="form-check-label" for="remember-me">Remember me</label>
                                </div>

<a href="forgot-password.php" class="text-decoration-none">Forgot password?</a>
                            </div>

                        <!-- Submit -->
                        <div class="d-grid mt-4">
                            <button type="submit" class="btn btn-primary">Login <i class="fas fa-spin fa-spinner d-none"></i></button>
                        </div>

                        <!-- Alert -->
                        <div id="alertBox" class="alert mt-3 d-none"></div>

                    </form>

                </div>
            </div>

        </div>
    </div>
</div>
</section>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $api->site_url();?>/admin/assets/js/global.js?i=<?php echo time();?>"></script>
<script src="<?php echo $api->site_url();?>//admin/assets/js/login.js?i=<?php echo time();?>"></script>

</body>
</html>
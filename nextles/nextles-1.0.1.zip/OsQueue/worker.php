<?php // worker.php

require '../ProjectClasses/bootstrap.php';
require '../ProjectClasses/main.php';

$api = new ProjectApi();
$worker = new Worker();

$settings=$api->AppSettings;

/**
 * Register job handlers
 */
 
$worker->register('email', function($data) use ($settings) {

$e = $settings['email'];

 // Use native PHP mail()
    if ($e['channel'] !== 'phpmailer') {

        if ( !mail(
            $data['to'],
            $data['subject'] ?? 'No subject',
            $data['body']
        )) {
            throw new Exception('Email failed to send');
        }
        return true;
    }


    // SMTP configurations
    $smtpConfigs = [

 //MailTrap SMTP
    [
            "email_host"       => 'live.smtp.mailtrap.io',
            "email_auth"       => true,
            "email_username"   => 'smtp@mailtrap.io',
            "email_password"   => '8d2307fa520e7ea71ab62a30e8ee72ac',
            "email_port"       => 465,
            "email_encryption" => 'ssl',
            "email_from"       => 'support@oshobby.com.ng',
            "email_alias"      => "Os Hobby",
            "timeout"=>15,
            "provider" =>'MT',
             "debug"=>2,
            "allow_self_signed"=>true
        ],
  
    // Gmail SMTP
           [
            "email_host"       => 'smtp.gmail.com',
            "email_auth"       => true,
            "email_username"   => 'oshobbyenterprise@gmail.com',
            "email_password"   => 'bcyvgxgjpnicpojk',
            "email_port"       => 465,
            "email_encryption" => 'ssl',
            "email_from"       => 'oshobbyenterprise@gmail.com',
            "email_alias"      => "Os Hobby",
            "timeout"=>15,
            "provider" =>'GM',
            "debug"=>2,
            "allow_self_signed"=>true
        ],
             
       // Local SMTP
        [
            "email_host"       => $e['host'],
            "email_auth"       => $e['authentication'],
            "email_username"   => $e['username'],
            "email_password"   => $e['password'],
            "email_port"       => $e['port'],
            "email_encryption" => $e['encryption'],
            "email_from"       => 'support@oshobby.com.ng',
            "email_alias"      => $e['alias'],
            "reply_to"      => $e['reply_to'],
            "timeout"=>15,
            "provider" =>'OS',
            "debug"=>2,
            "allow_self_signed"=>true
        ],
        
     //AhaSend SMTP
   [
            "email_host"       => 'send.ahasend.com',
            "email_auth"       => true,
            "email_username"   => '06FQFKjhIZ',
            "email_password"   => 'NZ96LiLD2tyuiFv7kQj0vWT1',
            "email_port"       => 587,
            "email_encryption" => 'tls',
            "email_from"       => 'support@email.oshobby.com.ng',
            "email_alias"      => "Os Hobby",
            "timeout"=>15,
            "provider" =>'AS',
            "debug"=>2,
            "allow_self_signed"=>true
        ],
       //Amazon SES  SMTP
    [
            "email_host"       => 'email-smtp.us-east-1.amazonaws.com',
            "email_auth"       => true,
            "email_username"   => 'AKIAZKOBO6YHFZU7CLL7',
            "email_password"   => 'BIoWxUGuY/wtvcr8HvtyoWCIoerF7ah/3uqPz+2LMQBb',
            "email_port"       => 465,
            "email_encryption" => 'ssl',
            "email_from"       => 'support@oshobby.com.ng',
            "email_alias"      => "Os Hobby",
            "timeout"=>15,
            "provider" =>'AZ',
            "debug"=>2,
            "allow_self_signed"=>true
        ]
    ];

    $lastError = 'Unknown error';

    // Try all SMTP configs
    foreach ($smtpConfigs as $config) {

   $body=$data['body'] . '<br><i>(PVDR: ' . $config['provider'] . ')';

        $sent = emailer(
            $config,
            $data['to'],
            $data['subject'] ?? 'No subject',
            $body
        );

        if (!empty($sent['success'])) {
            return true;
        }

        $lastError = $sent['message'] ?? $lastError;
        error_log( $lastError . '. Provider: ' . $config['provider']);
    }

    // All failed
    throw new Exception('All SMTP servers failed: ' . $lastError);
  
});

$worker->register('log', function($data) {

    file_put_contents(
        'queue.log',
        json_encode($data) . PHP_EOL,
        FILE_APPEND
    );

    return true;
});

/**
 * Mode selection
 *
 * php worker.php once
 * php worker.php loop
 */

$mode = $argv[1] ?? 'once';

if ($mode === 'once') {

    $worker->work([
        'mode'  => 'once',
        'limit' => 3
    ]);

} else {

    $worker->work([
        'mode'  => 'loop',
        'sleep' => 2,
        'limit' => 1
    ]);
}
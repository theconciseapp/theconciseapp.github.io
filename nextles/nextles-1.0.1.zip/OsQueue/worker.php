<?php // worker.php

require '../ProjectClasses/bootstrap.php';
require '../ProjectClasses/main.php';

$api = new ProjectApi();
$worker = new Worker();

$settings=$api->AppSettings['email'];

// SMTP configurations
$stmpConfigs=[
         // Local SMTP
        [
            "email_host"       => $settings['host'],
            "email_auth"       => $settings['authentication'],
            "email_username"   => $settings['username'],
            "email_password"   => $settings['password'],
            "email_port"       => $settings['port'],
            "email_encryption" => $settings['encryption'],
            "email_from"       => 'support@oshobby.com.ng',
            "email_alias"      => $settings['alias'],
            "reply_to"      => $settings['reply_to'],
            "timeout"=>15,
            "provider" =>'OS',
            "debug"=>2,
            "allow_self_signed"=>true
        ]
    ];

if( file_exists(ENV_DIR . '/stmp.configs.php') ){

$envConfig = require ENV_DIR . '/stmp.configs.php';

$stmpConfigs=array_merge( $stmpConfigs, $envConfig);

}

/**
 * Register job handlers
 */
 
$worker->register('email', function($data) use ($settings, $stmpConfigs) {

 // Use native PHP mail()
    if ($settings['channel'] !== 'phpmailer') {

        if ( !mail(
            $data['to'],
            $data['subject'] ?? 'No subject',
            $data['body']
        )) {
            throw new Exception('Email failed to send');
        }
        return true;
    } 

    $lastError = 'Unknown error';

    // Try all SMTP configs
    foreach ($smtpConfigs as $config) {

   $body=$data['body'] . '<br><i>(PVDR: ' . $config['provider'] . ')';

        $sent = emailer(
            $config,
            $data['to'],
            $data['subject'] ?? 'No subject',
            $body
        );

        if (!empty($sent['success'])) {
            return true;
        }

        $lastError = $sent['message'] ?? $lastError;
        error_log( $lastError . '. Provider: ' . $config['provider']);
    }

    // All failed
    throw new Exception('All SMTP servers failed: ' . $lastError);
  
});

$worker->register('log', function($data) {

    file_put_contents(
        'queue.log',
        json_encode($data) . PHP_EOL,
        FILE_APPEND
    );

    return true;
});

/**
 * Mode selection
 *
 * php worker.php once
 * php worker.php loop
 */

$mode = $argv[1] ?? 'once';

if ($mode === 'once') {

    $worker->work([
        'mode'  => 'once',
        'limit' => 3
    ]);

} else {

    $worker->work([
        'mode'  => 'loop',
        'sleep' => 2,
        'limit' => 1
    ]);
}
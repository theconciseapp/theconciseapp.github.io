<?php

 class OsQueue {

    protected $db;

    public function __construct() {
        global $conn;
        $this->db = $conn;
    }

public function push(
        string $type,
        array $payload,
        array $opt=[] ) {
        	
 $defaults=[
       'delay' => 0, //In seconds
       'max_attempts' => 3,
       'priority' => 0
       ];

 $options=array_merge( $defaults, $opt);
 
    $delaySeconds = (int)$options['delay'];
    $maxAttempts = (int)$options['max_attempts'];
    $priority = (int)$options['priority'];

        $stmt = $this->db->prepare("
            INSERT INTO job_queue (type, payload, priority, max_attempts, available_at)
            VALUES (?, ?, ?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND))
        ");

        $added= $stmt->execute([
            $type,
            json_encode($payload),
            $priority,
            $maxAttempts,
            $delaySeconds
        ]);
    }
}


//Usage:
//$queue->push('email', $data, 0, 3, 10); // high priority
//$queue->push('log', $data, 0, 3, 1);    // low priority

class Worker {

    protected $db;
    protected $handlers = [];
    protected $workerId;

    public function __construct() {
        global $conn;

        $this->db = $conn;
        $this->workerId = uniqid('worker_', true);
    }

    public function register(string $type, callable $handler) {
        $this->handlers[$type] = $handler;
    }

    /**
     * Unified runner
     * $options = [
     *   'mode' => 'once' | 'loop',
     *   'limit' => 10,
     *   'sleep' => 2
     * ]
     */
    public function work(array $options = []) {

        $mode  = $options['mode'] ?? 'loop';
        $limit = $options['limit'] ?? 10;
        $sleep = $options['sleep'] ?? 2;

        if ($mode === 'once') {
            return $this->runOnce($limit);
        }

        // default: loop mode
        while (true) {

            $processed = $this->runOnce($limit);

            if ($processed === 0) {
                sleep($sleep);
            }
        }
    }

    public function runOnce(int $limit = 5): int {
    $this->recoverStuckJobs();
    $count = 0;

    for ($i = 0; $i < $limit; $i++) {
        $job = $this->reserveJob();
        if (!$job) break;

        $this->process($job);

        $count++;

        sleep(1);
    }

    return $count;
}

    protected function reserveJob() {

        $this->db->beginTransaction();

        $stmt = $this->db->prepare("
            SELECT * FROM job_queue
            WHERE status = 'pending'
              AND available_at <= NOW()
            ORDER BY priority DESC, id ASC
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->execute();
        $job = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$job) {
            $this->db->commit();
            return null;
        }

        $update = $this->db->prepare("
            UPDATE job_queue
            SET status = 'processing',
                locked_at = NOW(),
                reserved_by = ?
            WHERE id = ?
        ");

        $update->execute([$this->workerId, $job['id']]);

        $this->db->commit();

        return $job;
    }

    protected function process($job) {

        try {

            $payload = json_decode($job['payload'], true);

            if (!isset($this->handlers[$job['type']])) {
                throw new Exception("No handler for type: {$job['type']}");
            }

            call_user_func($this->handlers[$job['type']], $payload);

            $this->markDone($job['id']);

        } catch (Exception $e) {

            $this->fail($job, $e->getMessage());
        }
    }

    protected function markDone($id) {

    $stmt = $this->db->prepare("
        UPDATE job_queue
        SET status = 'done',
            locked_at = NULL,
            reserved_by = NULL
        WHERE id = ?
    ");

    $stmt->execute([$id]);
}

    protected function fail($job, $error) {

    $attempts = $job['attempts'] + 1;

    // permanently failed
    if ($attempts >= $job['max_attempts']) {

        $stmt = $this->db->prepare("
            UPDATE job_queue
            SET status = 'failed',
                attempts = ?,
                last_error = ?,
                locked_at = NULL,
                reserved_by = NULL
            WHERE id = ?
        ");

        $stmt->execute([
            $attempts,
            $error,
            $job['id']
        ]);

    } else {

        // retry later
        $stmt = $this->db->prepare("
            UPDATE job_queue
            SET status = 'pending',
                attempts = ?,
                last_error = ?,
                locked_at = NULL,
                reserved_by = NULL,
                available_at = DATE_ADD(NOW(), INTERVAL 30 SECOND)
            WHERE id = ?
        ");

        $stmt->execute([
            $attempts,
            $error,
            $job['id']
        ]);
    }
}
    
  protected function recoverStuckJobs() {

$stmt = $this->db->prepare("
        UPDATE job_queue
        SET status = 'pending',
            locked_at = NULL,
            reserved_by = NULL
        WHERE status = 'processing'
        AND locked_at < NOW() - INTERVAL 5 MINUTE
    ");

    $stmt->execute();
}  
    
}

//Usage in worker.php
/*
Cron mode
$worker->work([
    'mode' => 'once',
    'limit' => 10
]);

Long running mode( best)
$worker->work([
    'mode' => 'loop',
    'sleep' => 2,
    'limit' => 5
]);
*/

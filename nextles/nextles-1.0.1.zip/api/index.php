<?php
require "../ProjectClasses/bootstrap.php";
require_once 'app/Controllers/Site.php';
require_once 'app/Controllers/PageController.php';

$segments=$Site->segments;

$folder = dirname(__DIR__ ).  '/ProjectViews/Rest'; // folder path

$restfulPages = [];
$files = scandir($folder);

foreach ($files as $file) {
    if ($file === '.' || $file === '..') continue;
    if (is_file($folder . '/' . $file)) {
        $restfulPages[] = pathinfo($file, PATHINFO_FILENAME);
    }
}


$controller = new PageController();

if ( count($segments)>0 ) {

 if(  in_array($segments[0], $restfulPages)) {
	$controller->renderRest($segments[0]);
	exit;
}

$controller->render($segments[0]);
}
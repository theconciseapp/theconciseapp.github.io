<?php

class Product
{
    private $conn;
    private $table = "products";

    public function __construct($db)
    {
        $this->conn = $db;
        header("Content-Type: application/json");
    }

    /* =====================================
       RESPONSE HELPER
    ===================================== */
    private function response($status, $message, $data = null, $code = 200)
    {
        http_response_code($code);
        echo json_encode([
            "status" => $status,
            "message" => $message,
            "data" => $data
        ]);
        exit;
    }

    /* =====================================
       CREATE PRODUCT
    ===================================== */
    public function createProduct($data)
    {
        try {

            if (empty($data['sku']) || empty($data['name'])) {
                $this->response(false, "SKU and Name required", null, 400);
            }

            // Duplicate SKU check
            $check = $this->conn->prepare(
                "SELECT id FROM {$this->table} WHERE sku = :sku"
            );
            $check->execute([":sku" => $data['sku']]);

            if ($check->rowCount() > 0) {
                $this->response(false, "SKU already exists", null, 409);
            }

            $query = "INSERT INTO {$this->table}
                        (sku, name, category_id, branch_id, cost_price, selling_price, stock)
                      VALUES
                        (:sku, :name, :category_id, :branch_id, :cost_price, :selling_price, :stock)";

            $stmt = $this->conn->prepare($query);

            $stmt->execute([
                ":sku" => $data['sku'],
                ":name" => $data['name'],
                ":category_id" => $data['category_id'] ?? null,
                ":branch_id" => $data['branch_id'] ?? null,
                ":cost_price" => $data['cost_price'] ?? 0,
                ":selling_price" => $data['selling_price'] ?? 0,
                ":stock" => $data['stock'] ?? 0
            ]);

            $this->response(true, "Product created", [
                "id" => $this->conn->lastInsertId()
            ], 201);

        } catch (PDOException $e) {
            $this->response(false, $e->getMessage(), null, 500);
        }
    }

    /* =====================================
       GET ALL PRODUCTS
    ===================================== */
    public function getProducts($page = 1, $limit = 10, $search = "")
    {
        $offset = ($page - 1) * $limit;
        $searchTerm = "%$search%";

        $query = "SELECT * FROM {$this->table}
                  WHERE name LIKE :search OR sku LIKE :search
                  ORDER BY id DESC
                  LIMIT :limit OFFSET :offset";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":search", $searchTerm);
        $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
        $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);
        $stmt->execute();

        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $this->response(true, "Products fetched", $products);
    }

    /* =====================================
       GET SINGLE PRODUCT
    ===================================== */
    public function getProduct($id)
    {
        $stmt = $this->conn->prepare(
            "SELECT * FROM {$this->table} WHERE id = :id"
        );
        $stmt->execute([":id" => $id]);

        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) {
            $this->response(false, "Product not found", null, 404);
        }

        $this->response(true, "Product fetched", $product);
    }

    /* =====================================
       UPDATE PRODUCT
    ===================================== */
    public function updateProduct($id, $data)
    {
        try {

            $query = "UPDATE {$this->table}
                      SET name = :name,
                          category_id = :category_id,
                          branch_id = :branch_id,
                          cost_price = :cost_price,
                          selling_price = :selling_price,
                          stock = :stock
                      WHERE id = :id";

            $stmt = $this->conn->prepare($query);

            $stmt->execute([
                ":name" => $data['name'],
                ":category_id" => $data['category_id'],
                ":branch_id" => $data['branch_id'],
                ":cost_price" => $data['cost_price'],
                ":selling_price" => $data['selling_price'],
                ":stock" => $data['stock'],
                ":id" => $id
            ]);

            $this->response(true, "Product updated");

        } catch (PDOException $e) {
            $this->response(false, $e->getMessage(), null, 500);
        }
    }

    /* =====================================
       DELETE PRODUCT
    ===================================== */
    public function deleteProduct($id)
    {
        $stmt = $this->conn->prepare(
            "DELETE FROM {$this->table} WHERE id = :id"
        );
        $stmt->execute([":id" => $id]);

        $this->response(true, "Product deleted");
    }

    /* =====================================
       ADJUST STOCK
    ===================================== */
    public function adjustStock($id, $qty)
    {
        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare(
                "UPDATE {$this->table}
                 SET stock = stock + :qty
                 WHERE id = :id"
            );

            $stmt->execute([
                ":qty" => $qty,
                ":id" => $id
            ]);

            $this->conn->commit();

            $this->response(true, "Stock updated");

        } catch (PDOException $e) {
            $this->conn->rollBack();
            $this->response(false, $e->getMessage(), null, 500);
        }
    }
}
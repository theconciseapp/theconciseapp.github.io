<?php 
class SiteLogic{
   public $url='';
   public $dir='';
   public $error=false;
   public $segments=array();
   
 public function __construct(){
   $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
    $path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
  $this->url=$protocol . "://" . $_SERVER['HTTP_HOST'] . ($path ? $path : '');
 
  $page = $_GET['page'] ?? '';

$this->segments = array_values(array_filter(explode('/', $page)));
  }
  
 public function get($pos){
 	return $this->segments[$pos]??null;
 }
 
}

$Site= new SiteLogic();



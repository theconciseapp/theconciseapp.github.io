<?php 

class PageController {
	public function header(){
		global  $Site;
		require "app/Views/layout/header.php";
	}
public function footer(){
	global  $Site;
		require "app/Views/layout/footer.php";
	}
	
   public function render($page) {
   	  global $conn, $Site;
   if( !file_exists("../ProjectViews/$page.php") ){
   	$page="error_page";
       $Site->error=true;
   }       
        require "../ProjectViews/$page.php";
    }
	
public function renderRest($page) {
	
   header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: Content-Type, x_auth_token");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Content-type: application/json; charset=utf-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
       exit;
    }
    global $conn, $Site;  
    require "../ProjectViews/Rest/$page.php";
 }
}
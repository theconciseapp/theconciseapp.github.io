<?php

class StockAPI
{
   private $db;

    /* =========================
       TABLE NAMES (PUBLIC)
    ========================== */
  
  public $products        = 'products';
    public $categories      = 'categories';
    public $branches        = 'branches';
    public $stock           = 'stock';
    public $stock_movements = 'stock_movements';
    public $suppliers       = 'suppliers';
    public $purchases       = 'purchases';
    public $purchase_items  = 'purchase_items';
    public $sales           = 'sales';
    public $sale_items      = 'sale_items';
    public $users           = 'users';

    public function __construct(PDO $pdo)
    {
        $this->db = $pdo;
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    /* =========================
       PRODUCTS
    ========================== */


// CREATE PRODUCT
public function createProduct($data)
{
    $sql = "INSERT INTO {$this->products}
            (sku, name, category_id, cost_price, selling_price)
            VALUES (?, ?, ?, ?, ?)";

    $this->db->prepare($sql)->execute([
        $data['sku'],
        $data['name'],
        $data['category_id'],
        $data['cost_price'],
        $data['selling_price']
    ]);

    return $this->db->lastInsertId();
}

// UPDATE PRODUCT
public function updateProduct($id, $data)
{
    $sql = "UPDATE {$this->products}
            SET sku=?, name=?, category_id=?, cost_price=?, selling_price=?
            WHERE id=?";

    return $this->db->prepare($sql)->execute([
        $data['sku'],
        $data['name'],
        $data['category_id'],
        $data['cost_price'],
        $data['selling_price'],
        $id
    ]);
}

// GET SINGLE PRODUCT
public function getProduct($id)
{
    $stmt = $this->db->prepare(
        "SELECT * FROM {$this->products} WHERE id=?"
    );
    $stmt->execute([$id]);
   
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

    public function getProducts()
    {
        return $this->db->query("SELECT * FROM {$this->products}")
                        ->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addProduct($sku, $name, $categoryId, $cost, $price)
    {
        $sql = "INSERT INTO {$this->products}
                (sku, name, category_id, cost_price, selling_price)
                VALUES (?, ?, ?, ?, ?)";
        return $this->db->prepare($sql)
                        ->execute([$sku, $name, $categoryId, $cost, $price]);
    }


    /* =========================
       STOCK HELPERS
    ========================== */

    private function upsertStock($productId, $branchId, $qty)
    {
        $sql = "
        INSERT INTO {$this->stock} (product_id, branch_id, quantity)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE quantity = quantity + VALUES(quantity)
        ";
        $this->db->prepare($sql)
                 ->execute([$productId, $branchId, $qty]);
    }

    private function logStockMovement($productId, $branchId, $type, $qty, $ref)
    {
        $sql = "
        INSERT INTO {$this->stock_movements}
        (product_id, branch_id, type, quantity, reference)
        VALUES (?, ?, ?, ?, ?)";
        $this->db->prepare($sql)
                 ->execute([$productId, $branchId, $type, $qty, $ref]);
    }


    /* =========================
       PURCHASE (STOCK IN)
    ========================== */

  public function createPurchase($supplierId, $branchId, array $items)
    {
        try {
            $this->db->beginTransaction();

            $this->db->prepare(
                "INSERT INTO {$this->purchases} (supplier_id, branch_id, total_amount)
                 VALUES (?, ?, 0)"
            )->execute([$supplierId, $branchId]);

            $purchaseId = $this->db->lastInsertId();
            $total = 0;

            foreach ($items as $item) {
                $lineTotal = $item['qty'] * $item['cost'];
                $total += $lineTotal;

                $this->db->prepare(
                    "INSERT INTO {$this->purchase_items}
                     (purchase_id, product_id, quantity, unit_cost)
                     VALUES (?, ?, ?, ?)"
                )->execute([$purchaseId, $item['product_id'], $item['qty'], $item['cost']]);

                $this->upsertStock($item['product_id'], $branchId, $item['qty']);
                $this->logStockMovement($item['product_id'], $branchId, 'IN', $item['qty'], "PUR-$purchaseId");
            }

            $this->db->prepare(
                "UPDATE {$this->purchases} SET total_amount=? WHERE id=?"
            )->execute([$total, $purchaseId]);

            $this->db->commit();
            return $purchaseId;

        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }


    /* =========================
       SALE (STOCK OUT)
    ========================== */

   public function createSale($branchId, array $items, $paymentMethod)
    {
        try {
            $this->db->beginTransaction();

            $this->db->prepare(
                "INSERT INTO {$this->sales} (branch_id, total_amount, payment_method)
                 VALUES (?, 0, ?)"
            )->execute([$branchId, $paymentMethod]);

            $saleId = $this->db->lastInsertId();
            $total = 0;

            foreach ($items as $item) {
                $stmt = $this->db->prepare(
                    "SELECT quantity FROM {$this->stock} WHERE product_id=? AND branch_id=?"
                );
                $stmt->execute([$item['product_id'], $branchId]);
                $stock = (int)$stmt->fetchColumn();

                if ($stock < $item['qty']) {
                    throw new Exception("Insufficient stock for product {$item['product_id']}");
                }

                $total += $item['qty'] * $item['price'];

                $this->db->prepare(
                    "INSERT INTO {$this->sale_items}
                     (sale_id, product_id, quantity, unit_price)
                     VALUES (?, ?, ?, ?)"
                )->execute([$saleId, $item['product_id'], $item['qty'], $item['price']]);

                $this->db->prepare(
                    "UPDATE {$this->stock} SET quantity = quantity - ?
                     WHERE product_id=? AND branch_id=?"
                )->execute([$item['qty'], $item['product_id'], $branchId]);

                $this->logStockMovement($item['product_id'], $branchId, 'OUT', $item['qty'], "SAL-$saleId");
            }

            $this->db->prepare(
                "UPDATE {$this->sales} SET total_amount=? WHERE id=?"
            )->execute([$total, $saleId]);

            $this->db->commit();
            return $saleId;

        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }


    /* =========================
       REPORTS
    ========================== */

    public function getStockByBranch($branchId)
    {
        $stmt = $this->db->prepare(
            "SELECT p.name, s.quantity
             FROM {$this->stock} s
             JOIN {$this->products} p ON p.id = s.product_id
             WHERE s.branch_id=?"
        );
        $stmt->execute([$branchId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
}
<?php $this->header();?>

<h2>About Us</h2>
<p>Grace Church is a place of love, faith, and worship.</p>

<?php $this->footer();?>
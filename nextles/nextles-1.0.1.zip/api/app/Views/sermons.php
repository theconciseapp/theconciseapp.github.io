<h2>Sermons</h2>

<iframe width="100%" height="315"
src="https://www.youtube.com/embed/videoseries?list=YOUR_PLAYLIST_ID"
allowfullscreen></iframe>
<h2>Contact Us</h2>

<form method="post">
    <input type="text" placeholder="Your Name" required><br><br>
    <input type="email" placeholder="Your Email" required><br><br>
    <textarea placeholder="Message"></textarea><br><br>
    <button>Send</button>
</form>
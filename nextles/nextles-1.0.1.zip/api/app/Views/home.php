<?php $this->header();?>
<h2>Welcome to Grace Church</h2>
<p>We are glad to have you worship with us.</p>
<?php $this->footer();?>
<h2>Upcoming Events</h2>
<ul>
    <li>Sunday Service – 9AM</li>
    <li>Bible Study – Wednesday 6PM</li>
</ul>
<?php 
   $method   = $_SERVER['REQUEST_METHOD'];

try{

if ($method !== 'POST') throw new Exception('Method not allowed');

            $input = json_decode(file_get_contents('php://input'), true);

            if (!isset($input['branch_id'],$input['items'],$input['payment_method'])) {
                throw new Exception('Missing parameters');
            }

            $saleId = $api->createSale(
                $input['branch_id'],
                $input['items'],
                $input['payment_method']
            );

            echo json_encode(['success'=>true,'sale_id'=>$saleId]);
            
            }catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
<?php 
   $method   = $_SERVER['REQUEST_METHOD'];

try{
	
if ($method !== 'GET') throw new Exception('Method not allowed');
            if (!isset($_GET['branch_id'])) throw new Exception('branch_id required');

            $stock = $api->getStockByBranch($_GET['branch_id']);
            echo json_encode(['success'=>true,'data'=>$stock]);
            
	
	}catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
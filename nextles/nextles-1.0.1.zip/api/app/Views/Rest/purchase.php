<?php 
   $method   = $_SERVER['REQUEST_METHOD'];

try{
	
if ($method !== 'POST') throw new Exception('Method not allowed');

            $input = json_decode(file_get_contents('php://input'), true);

            if (!isset($input['supplier_id'],$input['branch_id'],$input['items'])) {
                throw new Exception('Missing parameters');
            }

            $purchaseId = $api->createPurchase(
                $input['supplier_id'],
                $input['branch_id'],
                $input['items']
            );

            echo json_encode(['success'=>true,'purchase_id'=>$purchaseId]);
            
	
	}catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
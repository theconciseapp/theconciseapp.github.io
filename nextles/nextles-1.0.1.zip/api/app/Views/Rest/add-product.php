<?php
exit;
require "../../../ProjectClasses/stock.php";

 $api=new  StockAPI($conn);
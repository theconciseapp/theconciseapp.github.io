<?php 
   $method   = $_SERVER['REQUEST_METHOD'];

try{
	
	$id=$Site->get(1); //or null
	
	 if ($method == 'GET') {

	if( $id) {
		echo json_encode([
                'success'=>true,
                'data'=>$api->getProduct($id)
            ]);
		}else{
            $products = $api->getProducts();
            echo json_encode(['success'=>true,'data'=>$products]);
            }
         }elseif ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $newId = $api->createProduct($input);
        echo json_encode(['success'=>true,'id'=>$newId]);
    }
    elseif ($method === 'PUT') {
        if (!$id) throw new Exception('Product ID required');
        $input = json_decode(file_get_contents('php://input'), true);
        $api->updateProduct($id, $input);
        echo json_encode(['success'=>true]);
    }else {
        throw new Exception('Method not allowed');
        }
	
	}catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
</main>

<footer>
    <p>&copy; <?= date('Y') ?> Grace Church</p>
</footer>

</body>
</html>
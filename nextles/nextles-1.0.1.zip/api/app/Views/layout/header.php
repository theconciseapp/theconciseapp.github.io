<!DOCTYPE html>
<html>
<head>
    <title>Church Website</title>
    <link rel="stylesheet" href="<?php echo $Site->url;?>/assets/css/style.css">
</head>
<body>
<header>
    <h1>Grace Church</h1>
    <nav>
        <a href="<?php echo $Site->url;?>/">Home</a>
        <a href="about">About</a>
        <a href="events">Events</a>
        <a href="sermons">Sermons</a>
        <a href="live">Live</a>
        <a href="contact">Contact</a>
    </nav>
</header>

<main>
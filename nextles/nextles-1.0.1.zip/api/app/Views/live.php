<h2>🔴 Live Service</h2>

<div class="video-container">
<iframe 
    src="https://www.youtube.com/embed/live_stream?channel=YOUR_CHANNEL_ID"
    frameborder="0"
    allowfullscreen>
</iframe>
</div>
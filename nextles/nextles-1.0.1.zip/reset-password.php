<?php 
require_once 'ProjectClasses/bootstrap.php';
require "ProjectClasses/main.php";
require "ProjectClasses/main-frontend.php";

$api=new FrontendApi();


if( $_SERVER['REQUEST_METHOD']=='POST'){
	header('Content-Type: application/json');
	
	$api->json( $api->resetPassword() );

exit;	
	}
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Os Paystack - Reset Password</title>

<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@7.2.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script>
const OsBaseUrl = '<?php echo $api->site_url();?>';
</script>
</head>
<body>

<style>
body {
    background: #f4f6f9;
}
</style>

<section class="py-5 bg-light min-vh-100 d-flex align-items-center">
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-lg-5">

                <div class="card border-0 shadow-sm rounded-4">

                    <div class="card-body p-4 p-lg-5">

                        <div class="text-center mb-4">

                            <h2 class="fw-bold mb-2">
                                Reset Password
                            </h2>

                            <p class="text-muted mb-0">
                                Create a new password for your developer account.
                            </p>

                        </div>

                        <form id="reset-password-form" novalidate>

                            <!-- Hidden Token -->
                            <input type="hidden" name="reset_token" id="reset-token" value="">

                            <!-- New Password -->
                            <div class="mb-3">

                                <label class="form-label fw-semibold">New Password</label>

                        <input type="password" class="form-control form-control-lg" id="new-password" name="password" placeholder="Minimum 8 characters" required>

                                <div class="invalid-feedback">Password must be at least 8 characters.</div>
     </div>

                            <!-- Confirm Password -->
         <div class="mb-4">
             <label class="form-label fw-semibold">Confirm Password</label>

                                <input type="password" class="form-control form-control-lg" id="confirm-password" name="confirm_password" placeholder="Repeat password" required>

                                <div class="invalid-feedback">Passwords do not match.</div>
                            </div>

                            <!-- Submit -->
                            <button type="submit" class="btn btn-primary btn-lg w-100 rounded-3" id="reset-btn">Reset Password</button>
   </form>

                        <div class="text-center mt-4">
                            <a href="login.php" class="text-decoration-none">Back to Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

<script src="<?php echo $api->assets('js','global.js');?>"></script>

<script>

$(function () {

    // Get token from URL
    const urlParams =
        new URLSearchParams(window.location.search);

    const token = urlParams.get('token');

    // Set token
    $('#reset-token').val(token);

    $('#reset-password-form').on('submit', function (e) {

        e.preventDefault();

        let form = $(this);

        let valid = true;

        form.find('.is-invalid')
            .removeClass('is-invalid');

        // Token
        if (!token || token.length < 20) {

            alert('Invalid reset token');

            return;
        }

        // Password
        const password =
            $('#new-password').val();

        if (password.length < 8) {

            $('#new-password')
                .addClass('is-invalid');

            valid = false;
        }

        // Confirm Password
        const confirmPassword =
            $('#confirm-password').val();

        if (password !== confirmPassword) {

            $('#confirm-password')
                .addClass('is-invalid');

            valid = false;
        }

        if (!valid) {
            return;
        }

        // Loading State
        $('#reset-btn')
            .prop('disabled', true)
            .html(`
                <span class="spinner-border spinner-border-sm me-2"></span>
                Resetting...
            `);

        const formData= new FormData(form[0]);
    const payload = Object.fromEntries(formData.entries());

postData( OsBaseUrl + '/reset-password.php', payload, function(data, error, e){
	$('#reset-btn').prop('disabled', false).text('Reset Password');

  //	alert( JSON.stringify( e))
	if( error) {
		showToast(error)
		return;
		}
  showToast(data.message, 'success');  
 setTimeout(()=>{
    location.href=data.redirect;
    }, 1500);
});



    });
});
</script>
<?php 
require_once 'ProjectClasses/bootstrap.php';
require "ProjectClasses/main.php";
require "ProjectClasses/main-frontend.php";

$api = new FrontendApi();
$result = $api->verifyDeveloperEmail();

$success = $result['success'];
$message = $result['message'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <!-- Mobile Responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Email Verification</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <style>
        body{
            background:#ffffff;
            min-height:100vh;
            display:flex;
            flex-direction:column;
            color:#111111;
            font-family:Arial, sans-serif;
        }

        .card-box{
            max-width:480px;
            width:100%;
        }

        .card{
            background:#ffffff;
            border:1px solid #e5e5e5;
            border-radius:14px;
            color:#111111;
        }

        .status-icon{
            font-size:58px;
        }

        .success-color{
            color:#111111;
        }

        .error-color{
            color:#000000;
        }

        .message-text{
            color:#444444;
            line-height:1.6;
        }

        .btn-theme{
            background:#0079c6;
            color:#ffffff;
            border:none;
            height:48px;
            font-weight:600;
            border-radius:10px;
            transition:0.2s ease;
        }

        .btn-theme:hover{
            background:#222222;
            color:#ffffff;
        }

        .footer-text{
            color:#666666;
            font-size:13px;
        }

        footer{
            margin-top:auto;
            text-align:center;
            padding:20px 10px;
        }

        .sub-text{
            color:#777777;
            font-size:14px;
        }

        @media (max-width:576px){

            .card{
                margin:15px;
                padding:22px !important;
            }

            .status-icon{
                font-size:48px;
            }

            h3{
                font-size:1.35rem;
            }
        }
    </style>
</head>
<body>
<div class="container d-flex justify-content-center align-items-center flex-grow-1 py-4">

    <div class="card card-box shadow-sm text-center p-4">

        <?php if($success): ?>
            <div class="success-color">
                <i class="fa-solid fa-circle-check status-icon"></i>
            </div>

            <h3 class="mt-3 fw-bold success-color">
                Email Verified
            </h3>

        <?php else: ?>

            <div class="text-danger">
                <i class="fa-solid fa-circle-xmark status-icon"></i>
            </div>

            <h3 class="mt-3 fw-bold error-color">
                Verification Failed
            </h3>

        <?php endif; ?>

        <p class="mt-3 px-2 message-text">
            <?php echo htmlspecialchars($message); ?>
        </p>

        <div class="d-grid mt-4">
            <a 
                href="<?php echo $api->site_url();?>" 
                class="btn btn-theme"
            >
                <i class="fa-solid fa-right-to-bracket me-2"></i>
                Go home
            </a>
        </div>

        <small class="sub-text mt-4 d-block px-2">
            If you did not request this verification, you can safely ignore this page.
        </small>

    </div>

</div>

<footer>
    <div class="footer-text">
        &copy; <?php echo date("Y"); ?> <?php echo $api->siteName; ?>. All rights reserved.
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
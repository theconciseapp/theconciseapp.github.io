<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maintenance</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<style>
    body {
        background: #fff;
        color: #000;
        height: 100vh;
    }

    .maintenance-box {
        max-width: 520px;
        margin: auto;
        padding: 45px;
        border-radius: 16px;
        background: #f5f5f5;
        border: 1px solid rgba(255,255,255,0.08);
        box-shadow: 0 10px 30px rgba(0,0,0,0.6);
        text-align: center;
    }

    .icon {
        font-size: 64px;
        color: #ff7a00;
        margin-bottom: 20px;
    }

    h1 {
        font-weight: 700;
    }

    .btn-orange {
        background: #ff7a00;
        border: none;
        color: #fff;
    }

    .btn-orange:hover {
        background: #e66d00;
        color: #fff;
    }

    .btn-outline-orange {
        border: 1px solid #ff7a00;
        color: #ff7a00;
    }

    .btn-outline-orange:hover {
        background: #ff7a00;
        color: #fff;
    }

    .footer-text {
        opacity: 0.6;
        font-size: 13px;
    }
</style>
</head>
<body class="d-flex align-items-center justify-content-center">

<div class="maintenance-box">
    
    <div class="icon">
        <i class="fas fa-tools"></i>
    </div>

    <h1 class="mb-3">Under Maintenance</h1>

    <p class="mb-4">
        We’re currently performing scheduled maintenance.<br>
        Please check back shortly.
    </p>

    <div class="d-flex justify-content-center gap-3">
        <a href="javascript: history.go(-1);" class="btn btn-orange">
            <i class="fas fa-home me-1"></i> Back
        </a>

        <button onclick="location.reload()" class="btn btn-outline-orange">
            <i class="fas fa-rotate-right me-1"></i> Refresh
        </button>
    </div>

    <div class="mt-4 footer-text">
        &copy; <?php echo date('Y'); ?> Your Company
    </div>

</div>

</body>
</html>
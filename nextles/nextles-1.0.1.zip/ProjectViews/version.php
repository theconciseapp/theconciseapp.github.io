<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // public = anyone can read
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Block non-GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    exit(json_encode(['error' => 'Method not allowed']));
}

http_response_code(200);
echo json_encode([
  "version"=>"1.0.1",
  "release_date"=>"2026-06-13",
  "mandatory"=> false,
  "download_url"=>"update.zip",
  "newFeatures" =>["Added order tracking","Fixed payment bug"]
]);
exit;
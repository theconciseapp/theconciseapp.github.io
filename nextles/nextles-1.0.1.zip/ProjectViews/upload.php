<?php header('Content-Type: application/json');

require "../ProjectClasses/main.php";

$api=new ProjectAPI($conn);

$api->verifyToken();

if ( !isset($_FILES['image'])) {
	$api->json([
        'success'=>false,
        'message'=>'No file selected'
        ]);	
	}
   
   
 $storageLoc=$api->AppSettings['media']['storage'];  
   
  if( $storageLoc==='local'){
 	
   $results=$api->uploadToServer($_FILES['image'], $folder = "uploads", 2); //Max: 2mb
   
   }else if( $storageLoc==='cloudflare'){
  	
 $results= $api->uploadToCloudflare($_FILES['image']);
 
 } else if( $storageLoc==='dropbox'){

$results = $api->uploadToDropbox(
    $_FILES['image']
);

}
else{
	 $results=[
	  "success"=>false,
	  "message"=>"Storage location not found"
];
	}
	
$api->json( $results);
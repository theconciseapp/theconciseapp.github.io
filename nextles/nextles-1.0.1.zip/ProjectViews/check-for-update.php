<?php

header('Content-Type: application/json');

$api = 'http://localhost:8000/ecommerce/api/version';

try {

    $response = @file_get_contents($api);

    if ($response === false) {
        throw new Exception('Unable to connect to update server');
    }

    $data = json_decode($response, true);

    if (!is_array($data) || empty($data['version'])) {
        throw new Exception('Invalid update response');
    }

    $data['new_update'] = version_compare(
        $data['version'],
        APP_VERSION,
        '>'
    );

    echo json_encode($data);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => $e->getMessage(),
        'new_update' => false
    ]);
}

exit;
<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
   $api=new  ProjectAPI($conn);
  
  $api->verifyToken();
  
  if( isset($_GET['view'] ) ){
      $api->gallery();
  }else if( isset($_GET['delete'] ) ){
      $api->deleteImage();
  }
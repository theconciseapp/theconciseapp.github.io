<?php session_start();
 require "../ProjectClasses/main.php";
require "../ProjectClasses/GoogleOAuth.php";

$api = new ProjectAPI();

$clientId=$api->AppSettings['google']['clientid'];
$secret=$api->AppSettings['google']['secret'];
$redirectUri=$api->AppSettings['google']['redirect'];

$google = new GoogleOAuth(['client_id'=>$clientId, 'client_secret'=>$secret, 'redirect_uri'=>$redirectUri] );

$state = bin2hex(random_bytes(16));
$_SESSION['oauth_state'] = $state;

$login_url = $google->getAuthUrl($state);

header("Location: $login_url");
exit;
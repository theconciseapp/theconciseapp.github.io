<?php 
header('Content-Type: application/json');

require "../ProjectClasses/main.php";

$api = new ProjectAPI();
 $api->verifyToken();
  
$input=$api->input();

$section = $input['section']; // e.g. "payment"
$data = $input['data'];

$current = $api->AppSettings;

$current[$section] = array_replace_recursive(
    $current[$section] ?? [],
    $data );

$api->saveSettings($current);
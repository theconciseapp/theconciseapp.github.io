<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
 require "../ProjectClasses/main-frontend.php";
 
   $api=new  FrontendAPI($conn);

     $data=$api->input();
   
  $type=$data['type']??'';
  
  if( empty($type) ){
  	$api->json([
         "success"=>false,
         "message"=>"Type missing"
         ]);
  }
  

  switch($type){
  	case 'profile': $api->updateUserProfile();
  break;
  case 'register': $api->addNewUser();
  break;
  default: $api->json(['success'=>false, 'message'=>'Type is missing']);
  }
<?php session_start();
 header('Content-Type: application/json');
require "../ProjectClasses/main.php";
 require "../ProjectClasses/main-frontend.php";
 
   $api=new  FrontendAPI($conn);

 $api->json( $api->getProducts());
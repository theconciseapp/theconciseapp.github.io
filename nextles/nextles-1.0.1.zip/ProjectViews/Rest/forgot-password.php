<?php header('Content-Type: application/json');

require_once '../ProjectClasses/bootstrap.php';
require "../ProjectClasses/main.php";
require "../ProjectClasses/main-frontend.php";

$api=new FrontendApi();
$api->json( $api->forgotPassword() );
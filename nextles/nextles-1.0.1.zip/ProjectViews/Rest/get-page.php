<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
   $api=new  ProjectAPI($conn);
    
 $api->verifyToken();
 $api->json($api->listPages() );
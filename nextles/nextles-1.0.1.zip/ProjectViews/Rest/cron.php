<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
 
   $api=new  ProjectAPI($conn);
   //Update product popularity
   //This is used for trending products
   $api->updatePopularity();
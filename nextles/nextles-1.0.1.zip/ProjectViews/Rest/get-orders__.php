<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
   $api=new  ProjectAPI();
    
  $api->verifyToken();
  $api->json($api->getOrders(['frontend'=>true] ));
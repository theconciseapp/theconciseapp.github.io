<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
 require "../ProjectClasses/main-frontend.php";
 
   $api=new  FrontendAPI($conn);
//   $api->verifyToken();
  
  $section=$_GET['section']??'';
  
  if( empty($section) ){
  	$api->json([
         "success"=>false,
         "message"=>"Section missing"
         ]);
  }
  
   $result=[];
   
  switch($section){
  	case 'new-arrivals': $result=$api->getNewArrivals();
  break;
  case 'trending': $result=$api->getTrendingProducts();
  break;
  case 'top-deals': $result=$api->getTopDeals();
  break;
  case 'best-sellers': $result=$api->getBestSellers();
  break; 
  default: $result=['success'=>false, 'message'=>'Section is missing'];
  }
  
  $api->json($result);
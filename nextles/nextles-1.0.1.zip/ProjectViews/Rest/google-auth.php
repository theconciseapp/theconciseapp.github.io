<?php

require "../ProjectClasses/main.php";
require "../ProjectClasses/GoogleOAuth.php";

session_start();

$api = new ProjectAPI();

$clientId=$api->AppSettings['google']['clientid'];
$secret=$api->AppSettings['google']['secret'];
$redirectUri=$api->AppSettings['google']['redirect'];

$google = new GoogleOAuth(['client_id'=>$clientId, 'client_secret'=>$secret, 'redirect_uri'=>$redirectUri] );


/**
 * 1. Validate OAuth state (IMPORTANT anti-CSRF)
 */
$state = $_GET['state'] ?? null;

if (!$state || !isset($_SESSION['oauth_state']) || $state !== $_SESSION['oauth_state']) {
    exit("Invalid OAuth state");
}


/**
 * 2. Validate code
 */
$code = filter_input(INPUT_GET, 'code', FILTER_SANITIZE_STRING);

if (!$code) {
    exit("Missing authorization code");
}

/**
 * 3. Exchange code for token
 */
$tokenRes = $google->fetchAccessToken($code);

if (!$tokenRes['success'] || empty($tokenRes['data']['access_token'])) {
    exit("Token exchange failed");
}

$accessToken = $tokenRes['data']['access_token'];

/**
 * 4. Fetch user info
 */
$userRes = $google->fetchUser($accessToken);

if (!$userRes['success']) {
    exit("Failed to fetch user info");
}

$user = $userRes['data'] ?? [];

$email = filter_var($user['email'] ?? '', FILTER_SANITIZE_EMAIL);
$name = htmlspecialchars($user['name'] ?? '', ENT_QUOTES, 'UTF-8');
$google_id = $user['id'] ?? null;
$picture = $user['picture'] ?? null;

if (!$email || !$google_id) {
    exit("Invalid user data");
}

/**
 * 5. App login/register
 */
$res = $api->googleSignIn($google_id, $email, $name, $picture);

if (!$res['success']) {
    exit("Login failed");
}

/**
 * 6. Redirect user
 */
 
$home = $api->site_url();

$payload = [
    "token"  => $res['token'],
 ];

// Convert to JSON first
$json = json_encode($payload);

// Then Base64 encode
$encoded = rtrim(strtr(base64_encode($json), '+/', '-_'), '=');

// Send as single param. rtr= retrieve
header("Location: " . $home . "?rtr=" . urlencode($encoded));
exit;
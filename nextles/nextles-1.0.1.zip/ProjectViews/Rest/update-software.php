<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
 require "../ProjectClasses/main-frontend.php";
   $api=new  FrontendAPI();
    
$api->verifyToken();
$api->updateSoftware();
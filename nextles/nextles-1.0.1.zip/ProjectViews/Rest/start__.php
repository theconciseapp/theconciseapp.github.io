<?php header('Content-Type: application/json');

require "../ProjectClasses/main.php";
require "../ProjectClasses/main-frontend.php";

$api = new FrontendAPI($conn);
$user = $api->verifyToken(null, true);

$results = [];

$results["success"] = true;
$results["user"] = $user;
$results["featured"] = $api->getFeaturedProducts();
$results["categories"] = $api->listCategories();
$results["newProducts"] = $api->getNewArrivals();
$results["bestSellers"] = $api->getBestSellers();
$results["topDeals"] = $api->getTopDeals();
$results["trending"] = $api->getTrendingProducts();

echo json_encode($results);
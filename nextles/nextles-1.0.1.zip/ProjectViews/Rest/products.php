<?php header('Content-Type: application/json');

 require "../ProjectClasses/main.php";
   $api=new  ProjectAPI($conn);
    
  $api->verifyToken();
  
   exit( json_encode($api->products() ));
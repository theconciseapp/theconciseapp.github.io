<footer class="bg-dark text-light pt-5 pb-3 mt-5">

  <div class="container">
    <div class="row">

      <!-- Brand -->
      <div class="col-md-3 mb-4">
        <h5 class="fw-bold text-warning"><?php echo $siteName;?></h5>
        <p class="small">
<?php echo $api->AppSettings['app']['description']??'';?>
        </p>
      </div>

      <div class="col-md-6 mb-4">
<div class="ps-0 container-fluid">
<?php echo $api->footerMenu($footerMenu['data'],  ['column_class'=>'col-md-6', 'custom_link_class'=>'page-link'] );?>
</div>

</div>
      <!-- Newsletter -->
      <div class="col-md-3 mb-4">
        <h6 class="fw-bold">Newsletter</h6>
        <p class="small">Subscribe to get updates on new arrivals & deals</p>
        <form class="d-flex">
          <input type="email" class="form-control me-2" placeholder="Email">
          <button class="btn btn-warning">Subscribe</button>
        </form>
      </div>

    </div>

    <hr class="border-secondary">

    <!-- Bottom -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center small">

      <p class="mb-2 mb-md-0">© 2026 <?php echo $siteName; ?>. All rights reserved.</p>

      <!-- Payment Icons -->
      <div class="d-flex align-items-center gap-3 my-2 my-md-0">
        <i class="fa-brands fa-cc-visa fa-2x"></i>
<i class="fa-brands fa-cc-mastercard fa-2x"></i>
<i class="fa-solid fa-credit-card fa-2x"></i>
      </div>

      <!-- Policies -->
      <div>
        <a href="<?php echo $api->site_url();?>/page/privacy-policy" class="text-light me-3 footer-link text-decoration-none ajax-page-link">Privacy</a>
        <a href="<?php echo $api->site_url();?>/page/terms" class="text-light me-3 footer-link text-decoration-none ajax-page-link">Terms</a>
      </div>

    </div>
  </div>
</footer>

<script src="<?php echo $api->assets('js','app.js');?>"></script>

<script>
// Source - https://stackoverflow.com/a/59678694

// Posted by Amit Dwivedi

// Retrieved 2026-04-01, License - CC BY-SA 4.0

//add simple support for background images:
document.addEventListener('lazybeforeunveil', function(e){
    var bg = e.target.getAttribute('data-bg');
    if(bg){
        e.target.style.backgroundImage = 'url(' + bg + ')';
    }
});

</script>